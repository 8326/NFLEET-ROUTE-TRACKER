import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { FleetProvider, useFleet } from './context/FleetContext';
import { LoginPage } from './pages/LoginPage';
import { AppLayout } from './components/layout/AppLayout';
import { NavPage } from './components/layout/Sidebar';
import { DashboardPage } from './pages/DashboardPage';
import { LiveMapPage } from './pages/LiveMapPage';
import { VehiclesPage } from './pages/VehiclesPage';
import { HistoryPage } from './pages/HistoryPage';
import { AlertsPage } from './pages/AlertsPage';
import { GeofencesPage } from './pages/GeofencesPage';
import { ReportsPage } from './pages/ReportsPage';
import { DriversPage } from './pages/DriversPage';
import { DevicesPage } from './pages/DevicesPage';
import { SettingsPage } from './pages/SettingsPage';

const AppContent: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const { setSelectedVehicle, vehicles, flyToVehicle } = useFleet();

  const [currentPage, setCurrentPage] = useState<NavPage>('dashboard');
  const [historyTargetVehicleId, setHistoryTargetVehicleId] = useState<string>('veh-1');

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white space-y-4">
        <div className="w-10 h-10 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin" />
        <p className="text-xs font-mono uppercase tracking-widest text-slate-400">
          Initializing NFLEET Telematics Engine...
        </p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const handleNavigateMap = (vehicleId: string) => {
    const target = vehicles.find((v) => v.id === vehicleId);
    if (target) {
      flyToVehicle(target);
    }
    setCurrentPage('live-map');
  };

  const handleNavigateHistory = (vehicleId: string) => {
    setHistoryTargetVehicleId(vehicleId);
    setCurrentPage('history');
  };

  return (
    <AppLayout currentPage={currentPage} onNavigate={setCurrentPage}>
      {currentPage === 'dashboard' && (
        <DashboardPage
          onNavigate={setCurrentPage}
          onSelectVehicle={handleNavigateMap}
        />
      )}
      {currentPage === 'live-map' && (
        <LiveMapPage onNavigateHistory={handleNavigateHistory} />
      )}
      {currentPage === 'vehicles' && (
        <VehiclesPage
          onNavigateMap={handleNavigateMap}
          onNavigateHistory={handleNavigateHistory}
        />
      )}
      {currentPage === 'history' && (
        <HistoryPage initialVehicleId={historyTargetVehicleId} />
      )}
      {currentPage === 'alerts' && (
        <AlertsPage onNavigateMap={handleNavigateMap} />
      )}
      {currentPage === 'geofences' && <GeofencesPage />}
      {currentPage === 'reports' && <ReportsPage />}
      {currentPage === 'drivers' && <DriversPage />}
      {currentPage === 'devices' && <DevicesPage />}
      {currentPage === 'settings' && <SettingsPage />}
    </AppLayout>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <FleetProvider>
          <AppContent />
        </FleetProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
