import { UserProfile } from '../types';
import { getApiBaseUrl } from './apiConfig';

const AUTH_USER_KEY = 'nfleet_auth_user';
const AUTH_TOKEN_KEY = 'nfleet_auth_token';
const REMEMBER_ME_KEY = 'nfleet_remember_email';

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export const DEMO_USERS: UserProfile[] = [
  {
    id: 'usr-admin-1',
    name: 'Alexander Sterling',
    email: 'admin@nfleet.io',
    role: 'super_admin',
    organization: 'Global Logistics Operations',
    timezone: 'America/Los_Angeles (PST - UTC-8)',
  },
  {
    id: 'usr-dispatch-1',
    name: 'Sarah Hall',
    email: 'dispatch@nfleet.io',
    role: 'dispatcher',
    organization: 'West Coast Dispatch Division',
    timezone: 'America/Los_Angeles (PST - UTC-8)',
  },
];

export const authService = {
  async login(credentials: LoginCredentials): Promise<{ user: UserProfile; token: string }> {
    const apiBase = getApiBaseUrl();

    // If live API is connected, attempt REST request
    if (apiBase) {
      try {
        const response = await fetch(`${apiBase}/api/v1/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(credentials),
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw new Error(errData.message || 'Invalid email or password');
        }

        const data = await response.json();
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(data.user));
        localStorage.setItem(AUTH_TOKEN_KEY, data.token);
        if (credentials.rememberMe) {
          localStorage.setItem(REMEMBER_ME_KEY, credentials.email);
        } else {
          localStorage.removeItem(REMEMBER_ME_KEY);
        }
        return data;
      } catch (err: any) {
        console.warn('Backend login failed, checking demo credentials fallback:', err.message);
        // If server connection fails, fallback or rethrow
      }
    }

    // High fidelity DEMO authentication
    await new Promise((resolve) => setTimeout(resolve, 600));

    if (!credentials.email || !credentials.password) {
      throw new Error('Please provide both email and password.');
    }

    if (credentials.password.length < 5) {
      throw new Error('Password must be at least 5 characters long.');
    }

    // Match against demo users or accept standard fleet logins
    const foundUser = DEMO_USERS.find(
      (u) => u.email.toLowerCase() === credentials.email.toLowerCase()
    ) || {
      id: 'usr-custom',
      name: credentials.email.split('@')[0].replace('.', ' ').toUpperCase(),
      email: credentials.email,
      role: 'fleet_manager' as const,
      organization: 'Enterprise Fleet Holdings',
      timezone: 'America/New_York (EST - UTC-5)',
    };

    const dummyToken = `demo_jwt_${Date.now()}`;
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(foundUser));
    localStorage.setItem(AUTH_TOKEN_KEY, dummyToken);
    
    if (credentials.rememberMe) {
      localStorage.setItem(REMEMBER_ME_KEY, credentials.email);
    } else {
      localStorage.removeItem(REMEMBER_ME_KEY);
    }

    return { user: foundUser, token: dummyToken };
  },

  getCurrentUser(): UserProfile | null {
    try {
      const stored = localStorage.getItem(AUTH_USER_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  },

  getToken(): string | null {
    return localStorage.getItem(AUTH_TOKEN_KEY);
  },

  getRememberedEmail(): string {
    return localStorage.getItem(REMEMBER_ME_KEY) || '';
  },

  logout(): void {
    localStorage.removeItem(AUTH_USER_KEY);
    localStorage.removeItem(AUTH_TOKEN_KEY);
  },
};
