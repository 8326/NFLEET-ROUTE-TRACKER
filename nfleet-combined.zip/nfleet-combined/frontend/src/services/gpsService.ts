import { Vehicle, Coordinates, TelemetryData } from '../types';
import { getWsUrl } from './apiConfig';

export type TelemetryUpdateCallback = (updatedVehicles: Vehicle[], latestPacket?: any) => void;
export type ConnectionStatusCallback = (status: 'connected' | 'connecting' | 'demo_simulated' | 'disconnected') => void;

class GpsTelematicsService {
  private ws: WebSocket | null = null;
  private isSimulationRunning: boolean = false;
  private simulationInterval: any = null;
  private telemetryListeners: Set<TelemetryUpdateCallback> = new Set();
  private statusListeners: Set<ConnectionStatusCallback> = new Set();
  private currentStatus: 'connected' | 'connecting' | 'demo_simulated' | 'disconnected' = 'demo_simulated';
  private currentVehicles: Vehicle[] = [];

  constructor() {
    // Will be initialized when subscribed or started
  }

  public init(vehicles: Vehicle[]) {
    this.currentVehicles = [...vehicles];
    const wsUrl = getWsUrl();

    if (wsUrl) {
      this.connectWebSocket(wsUrl);
    } else {
      this.startDemoSimulation();
    }
  }

  public getStatus(): 'connected' | 'connecting' | 'demo_simulated' | 'disconnected' {
    return this.currentStatus;
  }

  public isDemoMode(): boolean {
    return this.currentStatus === 'demo_simulated';
  }

  public subscribe(callback: TelemetryUpdateCallback): () => void {
    this.telemetryListeners.add(callback);
    // Send immediate snapshot
    callback(this.currentVehicles);

    return () => {
      this.telemetryListeners.delete(callback);
    };
  }

  public subscribeStatus(callback: ConnectionStatusCallback): () => void {
    this.statusListeners.add(callback);
    callback(this.currentStatus);

    return () => {
      this.statusListeners.delete(callback);
    };
  }

  private notifyStatus(status: 'connected' | 'connecting' | 'demo_simulated' | 'disconnected') {
    this.currentStatus = status;
    this.statusListeners.forEach((cb) => cb(status));
  }

  private notifyTelemetry(latestPacket?: any) {
    this.telemetryListeners.forEach((cb) => cb(this.currentVehicles, latestPacket));
  }

  public connectWebSocket(url: string) {
    this.stopDemoSimulation();
    this.notifyStatus('connecting');

    try {
      this.ws = new WebSocket(url);

      this.ws.onopen = () => {
        console.log('[NFLEET GPS] WebSocket connected to real tracker broker:', url);
        this.notifyStatus('connected');
      };

      this.ws.onmessage = (event) => {
        try {
          const packet = JSON.parse(event.data);
          this.handleLiveGpsPacket(packet);
        } catch (err) {
          console.error('[NFLEET GPS] Malformed telematics packet:', err);
        }
      };

      this.ws.onclose = () => {
        console.warn('[NFLEET GPS] WebSocket closed, falling back to simulated telematics');
        this.notifyStatus('disconnected');
        // Auto fallback to demo simulation so user experience isn't blank
        setTimeout(() => this.startDemoSimulation(), 2000);
      };

      this.ws.onerror = (err) => {
        console.error('[NFLEET GPS] WebSocket error:', err);
        this.notifyStatus('disconnected');
      };
    } catch (e) {
      console.error('[NFLEET GPS] Failed to open WebSocket:', e);
      this.startDemoSimulation();
    }
  }

  private handleLiveGpsPacket(packet: {
    imei?: string;
    vehicleId?: string;
    lat: number;
    lng: number;
    speed: number;
    heading: number;
    ignition: boolean;
    satellites?: number;
    batteryVoltage?: number;
    fuelLevel?: number;
    address?: string;
    timestamp?: string;
  }) {
    const vIndex = this.currentVehicles.findIndex(
      (v) => v.id === packet.vehicleId || v.imei === packet.imei
    );

    if (vIndex !== -1) {
      const v = this.currentVehicles[vIndex];
      const updated: Vehicle = {
        ...v,
        currentPosition: { lat: packet.lat, lng: packet.lng },
        status: packet.speed > 5 ? 'moving' : packet.ignition ? 'idle' : 'stopped',
        telemetry: {
          ...v.telemetry,
          speed: packet.speed,
          heading: packet.heading,
          ignition: packet.ignition,
          satellites: packet.satellites ?? v.telemetry.satellites,
          batteryVoltage: packet.batteryVoltage ?? v.telemetry.batteryVoltage,
          fuelLevel: packet.fuelLevel ?? v.telemetry.fuelLevel,
          address: packet.address ?? v.telemetry.address,
          timestamp: packet.timestamp || new Date().toISOString(),
        },
        lastHeartbeat: new Date().toISOString(),
      };
      this.currentVehicles[vIndex] = updated;
      this.notifyTelemetry(packet);
    }
  }

  public startDemoSimulation() {
    if (this.isSimulationRunning) return;
    this.isSimulationRunning = true;
    this.notifyStatus('demo_simulated');

    // Highway delta vectors for simulated moving vehicles
    const trajectories: Record<string, { dLat: number; dLng: number; turnStep: number }> = {
      'veh-1': { dLat: 0.00045, dLng: 0.00065, turnStep: 0 },
      'veh-2': { dLat: -0.00035, dLng: 0.00025, turnStep: 0 },
      'veh-4': { dLat: 0.00055, dLng: -0.00045, turnStep: 0 },
      'veh-7': { dLat: -0.00040, dLng: -0.00030, turnStep: 0 },
    };

    this.simulationInterval = setInterval(() => {
      let hasUpdates = false;

      this.currentVehicles = this.currentVehicles.map((vehicle) => {
        // Only update moving or alert vehicles
        if (vehicle.status !== 'moving' && vehicle.status !== 'alert') {
          return vehicle;
        }

        const traj = trajectories[vehicle.id] || { dLat: 0.0002, dLng: 0.0002, turnStep: 0 };
        traj.turnStep++;

        // Smooth subtle oscillation like a real highway curve
        const drift = Math.sin(traj.turnStep * 0.1) * 0.00015;
        const newLat = vehicle.currentPosition.lat + traj.dLat + drift;
        const newLng = vehicle.currentPosition.lng + traj.dLng;

        // Calculate heading in degrees
        const angleRad = Math.atan2(traj.dLng, traj.dLat + drift);
        let angleDeg = Math.round((angleRad * 180) / Math.PI);
        if (angleDeg < 0) angleDeg += 360;

        // Speed fluctuation ± 3 km/h
        const speedNoise = Math.floor(Math.random() * 7) - 3;
        const newSpeed = Math.max(20, Math.min(110, vehicle.telemetry.speed + speedNoise));

        // Soft fuel level depletion over time
        const newFuel = Math.max(5, +(vehicle.telemetry.fuelLevel - 0.01).toFixed(2));
        const newOdo = +(vehicle.telemetry.odometer + 0.02).toFixed(2);

        hasUpdates = true;

        return {
          ...vehicle,
          currentPosition: { lat: newLat, lng: newLng },
          telemetry: {
            ...vehicle.telemetry,
            speed: newSpeed,
            heading: angleDeg,
            fuelLevel: newFuel,
            odometer: newOdo,
            timestamp: new Date().toISOString(),
          },
          lastHeartbeat: new Date().toISOString(),
        };
      });

      if (hasUpdates) {
        this.notifyTelemetry();
      }
    }, 2500); // 2.5 second realistic GPS beacon rate
  }

  public stopDemoSimulation() {
    if (this.simulationInterval) {
      clearInterval(this.simulationInterval);
      this.simulationInterval = null;
    }
    this.isSimulationRunning = false;
  }
}

export const gpsService = new GpsTelematicsService();
