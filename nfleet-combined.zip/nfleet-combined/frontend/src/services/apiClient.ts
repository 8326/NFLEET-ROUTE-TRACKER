import { getApiBaseUrl } from './apiConfig';
import { authService } from './authService';

/**
 * Wraps fetch for calls to the NFLEET backend: prefixes the configured API
 * base URL and attaches the logged-in user's JWT as a Bearer token, so
 * every protected route (vehicles, alerts, history, ...) authenticates
 * correctly. Falls through to a plain relative fetch if no API base is
 * configured (callers already guard on `getApiBaseUrl()` before using this,
 * matching the existing demo-mode fallback pattern in each service).
 */
export async function apiFetch(path: string, options: RequestInit = {}): Promise<Response> {
  const apiBase = getApiBaseUrl();
  const token = authService.getToken();

  const headers = new Headers(options.headers || {});
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  return fetch(`${apiBase}${path}`, { ...options, headers });
}
