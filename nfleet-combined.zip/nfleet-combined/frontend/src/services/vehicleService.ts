import { Vehicle } from '../types';
import { INITIAL_VEHICLES } from '../data/mockFleetData';
import { getApiBaseUrl } from './apiConfig';
import { apiFetch } from './apiClient';

const LOCAL_VEHICLES_KEY = 'nfleet_vehicles_cache';

export const vehicleService = {
  async getVehicles(): Promise<Vehicle[]> {
    const apiBase = getApiBaseUrl();
    if (apiBase) {
      try {
        const res = await apiFetch('/api/v1/vehicles');
        if (res.ok) {
          return await res.json();
        }
      } catch (err) {
        console.warn('Live API unreachable, using local telematics state:', err);
      }
    }

    // Local / Demo persistence
    const saved = localStorage.getItem(LOCAL_VEHICLES_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return INITIAL_VEHICLES;
  },

  async saveVehicles(vehicles: Vehicle[]): Promise<void> {
    localStorage.setItem(LOCAL_VEHICLES_KEY, JSON.stringify(vehicles));
  },

  async addVehicle(vehicle: Omit<Vehicle, 'id' | 'currentPosition' | 'telemetry' | 'status' | 'lastHeartbeat'>): Promise<Vehicle> {
    const apiBase = getApiBaseUrl();
    const newId = `veh-${Date.now().toString(36)}`;
    
    const fullVehicle: Vehicle = {
      ...vehicle,
      id: newId,
      status: 'stopped',
      currentPosition: { lat: 37.7749 + (Math.random() - 0.5) * 0.08, lng: -122.4194 + (Math.random() - 0.5) * 0.08 },
      telemetry: {
        speed: 0,
        heading: 0,
        altitude: 20,
        accuracy: 1.0,
        satellites: 12,
        ignition: false,
        engineRpm: 0,
        fuelLevel: 90,
        batteryVoltage: 12.6,
        odometer: 10500,
        engineTemp: 25,
        relayCutoff: false,
        address: 'NFLEET Depot Staging Bay 3, San Francisco',
        timestamp: new Date().toISOString(),
      },
      lastHeartbeat: new Date().toISOString(),
    };

    if (apiBase) {
      try {
        const res = await apiFetch('/api/v1/vehicles', {
          method: 'POST',
          body: JSON.stringify(fullVehicle),
        });
        if (res.ok) return await res.json();
      } catch (err) {
        console.warn('API post failed, saving locally:', err);
      }
    }

    return fullVehicle;
  },

  async toggleRemoteRelay(vehicleId: string, currentCutoff: boolean): Promise<boolean> {
    const apiBase = getApiBaseUrl();
    const desiredCutoff = !currentCutoff;

    if (apiBase) {
      try {
        const res = await apiFetch(`/api/v1/vehicles/${vehicleId}/relay`, {
          method: 'POST',
          body: JSON.stringify({ cutoff: desiredCutoff }),
        });
        if (res.ok) {
          const data = await res.json();
          return data.cutoff;
        }
      } catch (err) {
        console.warn('Remote command failed on live API:', err);
      }
    }

    // Demo relay cutoff simulation: delay 500ms to simulate satellite downlink
    await new Promise((r) => setTimeout(r, 500));
    return desiredCutoff;
  },
};
