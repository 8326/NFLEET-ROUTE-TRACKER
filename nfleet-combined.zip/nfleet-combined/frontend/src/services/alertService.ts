import { AlertIncident } from '../types';
import { INITIAL_ALERTS } from '../data/mockFleetData';
import { getApiBaseUrl } from './apiConfig';
import { apiFetch } from './apiClient';

const LOCAL_ALERTS_KEY = 'nfleet_alerts_cache';

export const alertService = {
  async getAlerts(): Promise<AlertIncident[]> {
    const apiBase = getApiBaseUrl();
    if (apiBase) {
      try {
        const res = await apiFetch('/api/v1/alerts');
        if (res.ok) return await res.json();
      } catch (err) {
        console.warn('Alert API offline, using local incident cache:', err);
      }
    }

    const saved = localStorage.getItem(LOCAL_ALERTS_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return INITIAL_ALERTS;
  },

  async acknowledgeAlert(alertId: string, acknowledgedBy: string, notes?: string): Promise<AlertIncident | null> {
    const apiBase = getApiBaseUrl();
    if (apiBase) {
      try {
        const res = await apiFetch(`/api/v1/alerts/${alertId}/acknowledge`, {
          method: 'POST',
          body: JSON.stringify({ acknowledgedBy, notes }),
        });
        if (res.ok) return await res.json();
      } catch (err) {
        console.warn('Acknowledge API call failed, updating local cache:', err);
      }
    }

    const alerts = await this.getAlerts();
    const index = alerts.findIndex((a) => a.id === alertId);
    if (index === -1) return null;

    const updated = {
      ...alerts[index],
      acknowledged: true,
      acknowledgedBy,
      acknowledgedAt: new Date().toISOString(),
      resolutionNotes: notes || 'Incident acknowledged and logged by operator.',
    };

    alerts[index] = updated;
    localStorage.setItem(LOCAL_ALERTS_KEY, JSON.stringify(alerts));
    return updated;
  },

  async resolveAlert(alertId: string): Promise<boolean> {
    const apiBase = getApiBaseUrl();
    if (apiBase) {
      try {
        const res = await apiFetch(`/api/v1/alerts/${alertId}/resolve`, { method: 'POST' });
        if (res.ok) return true;
      } catch (err) {
        console.warn('Resolve API call failed, updating local cache:', err);
      }
    }

    const alerts = await this.getAlerts();
    const filtered = alerts.filter((a) => a.id !== alertId);
    localStorage.setItem(LOCAL_ALERTS_KEY, JSON.stringify(filtered));
    return true;
  },
};
