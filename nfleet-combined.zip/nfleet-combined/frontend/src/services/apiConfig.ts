// Configuration for REST API and WebSocket endpoints
// Seamlessly switches between live backend server and high-fidelity DEMO mode

const STORAGE_API_KEY = 'nfleet_api_base_url';
const STORAGE_WS_KEY = 'nfleet_ws_url';

export const getApiBaseUrl = (): string => {
  const env = (import.meta as unknown as { env?: Record<string, string> }).env;
  return localStorage.getItem(STORAGE_API_KEY) || env?.VITE_API_BASE_URL || '';
};

export const getWsUrl = (): string => {
  const env = (import.meta as unknown as { env?: Record<string, string> }).env;
  return localStorage.getItem(STORAGE_WS_KEY) || env?.VITE_WS_URL || '';
};

export const setApiEndpoints = (apiUrl: string, wsUrl: string): void => {
  if (apiUrl) {
    localStorage.setItem(STORAGE_API_KEY, apiUrl);
  } else {
    localStorage.removeItem(STORAGE_API_KEY);
  }

  if (wsUrl) {
    localStorage.setItem(STORAGE_WS_KEY, wsUrl);
  } else {
    localStorage.removeItem(STORAGE_WS_KEY);
  }
};

export const isLiveBackendConfigured = (): boolean => {
  return Boolean(getApiBaseUrl() || getWsUrl());
};
