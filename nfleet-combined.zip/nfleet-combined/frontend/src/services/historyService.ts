import { TripHistory, RoutePoint } from '../types';
import { SAMPLE_TRIP_HISTORY } from '../data/mockFleetData';
import { getApiBaseUrl } from './apiConfig';
import { apiFetch } from './apiClient';

export const historyService = {
  async getTripHistory(vehicleId: string, date: string): Promise<TripHistory> {
    const apiBase = getApiBaseUrl();
    if (apiBase) {
      try {
        const res = await apiFetch(`/api/v1/history?vehicleId=${vehicleId}&date=${date}`);
        if (res.ok) {
          return await res.json();
        }
      } catch (err) {
        console.warn('Live history API unavailable, generating telemetry playback route:', err);
      }
    }

    // Return sample trip with vehicle customization
    if (vehicleId === 'veh-1') {
      return SAMPLE_TRIP_HISTORY;
    }

    // Dynamic procedural route for other vehicles based on their coordinates
    const baseCoords: Record<string, { lat: number; lng: number; name: string; plate: string }> = {
      'veh-2': { lat: 37.8044, lng: -122.2712, name: 'Mercedes Sprinter - Metro 04', plate: 'NF-3184-CA' },
      'veh-3': { lat: 37.7249, lng: -122.1561, name: 'Scania R500 - ColdChain Reefer', plate: 'NF-6590-CL' },
      'veh-4': { lat: 37.8651, lng: -122.2585, name: 'Ford F-550 - Heavy Recovery', plate: 'NF-1129-SV' },
      'veh-5': { lat: 37.6879, lng: -122.4702, name: 'Isuzu NPR - FreshSupply 09', plate: 'NF-7204-FD' },
      'veh-6': { lat: 37.5585, lng: -122.2711, name: 'Kenworth W990 - LongHaul 03', plate: 'NF-9021-KW' },
      'veh-7': { lat: 37.8272, lng: -122.2913, name: 'Toyota Proace - QuickCourier 02', plate: 'NF-4491-QC' },
    };

    const info = baseCoords[vehicleId] || { lat: 37.7749, lng: -122.4194, name: 'Fleet Vehicle', plate: 'NF-1001-XX' };
    const points: RoutePoint[] = [];
    const count = 18;
    let currLat = info.lat - 0.08;
    let currLng = info.lng - 0.09;
    let currFuel = 92;

    for (let i = 0; i < count; i++) {
      currLat += 0.009 + (Math.sin(i) * 0.002);
      currLng += 0.010 + (Math.cos(i) * 0.002);
      currFuel = Math.max(20, +(currFuel - 1.2).toFixed(1));

      let event: RoutePoint['event'] = undefined;
      let speed = 45 + Math.floor(Math.sin(i) * 25);
      let stopDuration: number | undefined = undefined;

      if (i === 0) {
        event = 'start';
        speed = 0;
      } else if (i === count - 1) {
        event = 'end';
        speed = 0;
      } else if (i === 6) {
        event = 'stop';
        stopDuration = 32;
        speed = 0;
      } else if (i === 12 && speed > 68) {
        event = 'speed_violation';
      }

      points.push({
        lat: currLat,
        lng: currLng,
        speed,
        heading: (i * 20) % 360,
        ignition: speed > 0 || event !== 'stop',
        timestamp: `${String(7 + Math.floor(i / 3)).padStart(2, '0')}:${String((i * 18) % 60).padStart(2, '0')} AM`,
        fuelLevel: currFuel,
        event,
        stopDuration,
        address: `Corridor Sector ${i + 1}, Metro Transit Route`,
      });
    }

    return {
      id: `trip-${vehicleId}-${date}`,
      vehicleId,
      vehicleName: info.name,
      plateNumber: info.plate,
      startTime: '07:00 AM',
      endTime: '12:30 PM',
      startAddress: 'Metro Staging Yard 4',
      endAddress: 'Bay Commercial District',
      totalDistanceKm: 64.5,
      movingDurationMinutes: 185,
      idleDurationMinutes: 45,
      avgSpeedKmH: 48.2,
      maxSpeedKmH: 82.0,
      fuelConsumedLiters: 22.4,
      stopCount: 2,
      alertCount: 1,
      points,
    };
  },
};
