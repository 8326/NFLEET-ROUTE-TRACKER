export type VehicleStatus = 'moving' | 'stopped' | 'idle' | 'offline' | 'alert';

export type AlertSeverity = 'critical' | 'warning' | 'info';

export type AlertType = 
  | 'overspeed'
  | 'geofence_breach'
  | 'geofence_enter'
  | 'geofence_exit'
  | 'ignition_unauthorized'
  | 'ignition_on'
  | 'ignition_off'
  | 'offline'
  | 'gps_lost'
  | 'battery_low'
  | 'harsh_braking'
  | 'harsh_acceleration'
  | 'tamper'
  | 'sos_panic';

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface TelemetryData {
  speed: number; // km/h
  heading: number; // degrees 0-360
  altitude?: number; // meters
  accuracy?: number; // meters
  satellites: number;
  ignition: boolean;
  engineRpm: number;
  fuelLevel: number; // 0-100%
  batteryVoltage: number; // Volts, e.g. 12.6 or 24.2
  odometer: number; // km
  engineTemp?: number; // °C
  relayCutoff: boolean; // Remote immobilizer state
  address: string;
  timestamp: string;
}

export interface Vehicle {
  id: string;
  name: string;
  plateNumber: string;
  imei: string;
  deviceModel: string;
  simNumber: string;
  driverId: string;
  driverName: string;
  driverPhone: string;
  group: string;
  type: 'truck' | 'van' | 'car' | 'trailer' | 'heavy';
  status: VehicleStatus;
  currentPosition: Coordinates;
  telemetry: TelemetryData;
  speedLimit: number; // km/h limit
  iconType?: string;
  assignedGeofences?: string[];
  lastHeartbeat: string;
}

export interface RoutePoint extends Coordinates {
  timestamp: string;
  speed: number;
  heading: number;
  ignition: boolean;
  altitude?: number;
  fuelLevel?: number;
  event?: 'stop' | 'speed_violation' | 'refuel' | 'start' | 'end';
  stopDuration?: number; // minutes
  address?: string;
}

export interface TripHistory {
  id: string;
  vehicleId: string;
  vehicleName: string;
  plateNumber: string;
  startTime: string;
  endTime: string;
  startAddress: string;
  endAddress: string;
  totalDistanceKm: number;
  movingDurationMinutes: number;
  idleDurationMinutes: number;
  avgSpeedKmH: number;
  maxSpeedKmH: number;
  fuelConsumedLiters: number;
  stopCount: number;
  alertCount: number;
  points: RoutePoint[];
}

export interface AlertIncident {
  id: string;
  vehicleId: string;
  vehicleName: string;
  plateNumber: string;
  driverName: string;
  type: AlertType;
  severity: AlertSeverity;
  title: string;
  description: string;
  location: Coordinates;
  address: string;
  speed?: number;
  speedLimit?: number;
  timestamp: string;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  resolutionNotes?: string;
}

export interface GeofenceZone {
  id: string;
  name: string;
  description: string;
  type: 'circle' | 'polygon';
  category?: 'depot' | 'customer' | 'restricted' | 'service_center';
  center?: Coordinates;
  radiusMeters?: number;
  polygonCoordinates?: Coordinates[];
  color: string;
  speedLimitKmH?: number;
  activeVehiclesCount?: number;
  activeVehicleCount?: number;
  alertOnEntry?: boolean;
  alertOnExit?: boolean;
  triggers?: {
    onEnter: boolean;
    onExit: boolean;
    onOverspeed: boolean;
  };
  assignedVehicleIds?: string[];
  createdAt?: string;
}

export interface Driver {
  id: string;
  name: string;
  licenseNumber: string;
  phone: string;
  email: string;
  avatarUrl?: string;
  status: 'active' | 'on_break' | 'off_duty';
  assignedVehicleId?: string;
  assignedVehiclePlate?: string;
  assignedVehicleName?: string;
  safetyScore: number; // 0 - 100
  rating?: number; // 1.0 - 5.0
  totalTrips: number;
  totalDistanceKm?: number;
  totalHours?: number;
  shiftHoursToday?: number;
  violationsCount?: number;
}

export interface DeviceTracker {
  id: string;
  imei: string;
  model: string;
  protocol: string;
  firmwareVersion: string;
  simNumber?: string;
  simIccid?: string;
  operator?: string;
  batteryStatus?: number; // percentage
  backupBatteryVoltage?: number;
  gsmSignalDbm?: number;
  gsmSignalPercent?: number;
  satelliteCount?: number;
  status: 'online' | 'offline' | 'unregistered';
  vehicleAssigned?: string;
  lastCommunication?: string;
  lastPingTimestamp?: string;
}

export interface FleetStats {
  totalVehicles: number;
  onlineVehicles: number;
  movingVehicles: number;
  idleVehicles: number;
  stoppedVehicles: number;
  offlineVehicles: number;
  activeAlerts: number;
  totalDistanceTodayKm: number;
  fleetUtilizationPercent: number;
  avgFleetSpeedKmH: number;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'super_admin' | 'fleet_manager' | 'dispatcher' | 'viewer';
  avatarUrl?: string;
  organization: string;
  timezone: string;
}

export type ThemeMode = 'light' | 'dark' | 'system';
