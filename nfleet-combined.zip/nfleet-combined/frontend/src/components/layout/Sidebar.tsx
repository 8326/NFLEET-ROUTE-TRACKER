import React from 'react';
import {
  LayoutDashboard,
  MapPin,
  Truck,
  History,
  AlertTriangle,
  ShieldAlert,
  BarChart3,
  Users,
  Radio,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { NfleetLogo } from '../common/NfleetLogo';
import { useAuth } from '../../context/AuthContext';
import { useFleet } from '../../context/FleetContext';

export type NavPage =
  | 'dashboard'
  | 'live-map'
  | 'vehicles'
  | 'history'
  | 'alerts'
  | 'geofences'
  | 'reports'
  | 'drivers'
  | 'devices'
  | 'settings';

interface SidebarProps {
  currentPage: NavPage;
  onSelectPage: (page: NavPage) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onSelectPage,
  isCollapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
}) => {
  const { logout, user } = useAuth();
  const { stats, alerts } = useFleet();

  const unreadAlerts = alerts.filter((a) => !a.acknowledged).length;

  const navItems = [
    { id: 'dashboard' as NavPage, label: 'Dashboard', icon: LayoutDashboard, badge: null },
    { id: 'live-map' as NavPage, label: 'Live Map', icon: MapPin, badge: `${stats.movingVehicles} live` },
    { id: 'vehicles' as NavPage, label: 'Vehicles', icon: Truck, badge: `${stats.totalVehicles}` },
    { id: 'history' as NavPage, label: 'History', icon: History, badge: null },
    { id: 'alerts' as NavPage, label: 'Alerts', icon: AlertTriangle, badge: unreadAlerts > 0 ? `${unreadAlerts}` : null, alertColor: true },
    { id: 'geofences' as NavPage, label: 'Geofences', icon: ShieldAlert, badge: null },
    { id: 'reports' as NavPage, label: 'Reports', icon: BarChart3, badge: null },
    { id: 'drivers' as NavPage, label: 'Drivers', icon: Users, badge: null },
    { id: 'devices' as NavPage, label: 'Devices', icon: Radio, badge: null },
    { id: 'settings' as NavPage, label: 'Settings', icon: Settings, badge: null },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs lg:hidden"
        />
      )}

      {/* Main Sidebar */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 flex flex-col bg-slate-900 border-r border-slate-800 transition-all duration-300 ease-in-out ${
          isCollapsed ? 'w-20' : 'w-64'
        } ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800/80 bg-slate-900/50">
          <div
            onClick={() => {
              onSelectPage('dashboard');
              onCloseMobile();
            }}
            className="cursor-pointer overflow-hidden flex items-center"
          >
            <NfleetLogo
              size="md"
              showText={!isCollapsed}
              showTagline={false}
              lightText={true}
            />
          </div>

          <button
            type="button"
            onClick={onToggleCollapse}
            className="hidden lg:flex items-center justify-center w-7 h-7 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
            title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectPage(item.id);
                  onCloseMobile();
                }}
                className={`group relative flex items-center w-full px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25 font-semibold'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70'
                }`}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon
                  className={`w-5 h-5 shrink-0 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-blue-400'
                  }`}
                />

                {!isCollapsed && (
                  <span className="ml-3 truncate flex-1 text-left">{item.label}</span>
                )}

                {!isCollapsed && item.badge && (
                  <span
                    className={`ml-auto text-[11px] font-bold px-2 py-0.5 rounded-full ${
                      item.alertColor
                        ? 'bg-rose-500 text-white animate-pulse'
                        : isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}

                {/* Collapsed Tooltip dot badge */}
                {isCollapsed && item.badge && (
                  <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-rose-500" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Live GNSS Engine Status Widget in Sidebar */}
        {!isCollapsed && (
          <div className="mx-3 mb-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
            <div className="flex items-center justify-between text-slate-400 mb-1.5 font-medium">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Fleet Telemetry
              </span>
              <span className="text-[10px] font-mono text-emerald-400">99.98%</span>
            </div>
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Moving: <strong className="text-white">{stats.movingVehicles}</strong></span>
              <span>Stopped: <strong className="text-white">{stats.stoppedVehicles}</strong></span>
              <span>Alerts: <strong className="text-rose-400">{stats.activeAlerts}</strong></span>
            </div>
          </div>
        )}

        {/* Bottom User / Logout */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-900/60">
          <button
            type="button"
            onClick={logout}
            className={`group flex items-center w-full px-3 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors ${
              isCollapsed ? 'justify-center' : ''
            }`}
            title="Logout of NFLEET"
          >
            <LogOut className="w-5 h-5 shrink-0 transition-transform group-hover:scale-110" />
            {!isCollapsed && <span className="ml-3 font-semibold">Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
};
