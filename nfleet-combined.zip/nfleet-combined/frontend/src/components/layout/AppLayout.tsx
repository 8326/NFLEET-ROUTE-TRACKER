import React, { useState } from 'react';
import { Sidebar, NavPage } from './Sidebar';
import { TopBar } from './TopBar';
import { ApiGatewayModal } from '../common/ApiGatewayModal';

interface AppLayoutProps {
  currentPage: NavPage;
  onNavigate: (page: NavPage) => void;
  children: React.ReactNode;
}

export const AppLayout: React.FC<AppLayoutProps> = ({
  currentPage,
  onNavigate,
  children,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isApiModalOpen, setIsApiModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Sidebar */}
      <Sidebar
        currentPage={currentPage}
        onSelectPage={onNavigate}
        isCollapsed={isCollapsed}
        onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      {/* Main Container */}
      <div
        className={`flex-1 flex flex-col transition-all duration-300 ${
          isCollapsed ? 'lg:pl-20' : 'lg:pl-64'
        }`}
      >
        {/* TopBar */}
        <TopBar
          onToggleMobileMenu={() => setMobileOpen(true)}
          onNavigate={onNavigate}
          onOpenApiModal={() => setIsApiModalOpen(true)}
        />

        {/* Page Content */}
        <main className="flex-1 w-full">{children}</main>
      </div>

      {/* Global API Gateway Configuration Modal */}
      <ApiGatewayModal
        isOpen={isApiModalOpen}
        onClose={() => setIsApiModalOpen(false)}
      />
    </div>
  );
};
