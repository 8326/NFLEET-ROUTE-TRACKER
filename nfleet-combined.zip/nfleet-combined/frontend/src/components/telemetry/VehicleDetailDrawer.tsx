import React, { useState } from 'react';
import { Vehicle } from '../../types';
import { Badge } from '../common/Badge';
import {
  Gauge,
  Fuel,
  BatteryCharging,
  Zap,
  Radio,
  MapPin,
  User,
  Phone,
  Power,
  History,
  AlertOctagon,
  Calendar,
  X,
  Compass,
  Cpu,
  CheckCircle2,
} from 'lucide-react';
import { useFleet } from '../../context/FleetContext';

interface VehicleDetailDrawerProps {
  vehicle: Vehicle | null;
  onClose: () => void;
  onNavigateHistory?: (vehicleId: string) => void;
}

export const VehicleDetailDrawer: React.FC<VehicleDetailDrawerProps> = ({
  vehicle,
  onClose,
  onNavigateHistory,
}) => {
  const { toggleRemoteCutoff } = useFleet();
  const [isConfirmingRelay, setIsConfirmingRelay] = useState(false);
  const [isProcessingRelay, setIsProcessingRelay] = useState(false);
  const [relayFeedback, setRelayFeedback] = useState<string | null>(null);

  if (!vehicle) return null;

  const handleCutoffClick = async () => {
    if (!isConfirmingRelay) {
      setIsConfirmingRelay(true);
      return;
    }

    setIsProcessingRelay(true);
    try {
      const newState = await toggleRemoteCutoff(vehicle.id);
      setRelayFeedback(
        newState
          ? 'Remote ignition immobilized successfully via satellite downlink.'
          : 'Remote immobilizer disengaged. Engine ignition authorized.'
      );
      setIsConfirmingRelay(false);
      setTimeout(() => setRelayFeedback(null), 4000);
    } finally {
      setIsProcessingRelay(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border-l border-slate-800 text-slate-100 shadow-2xl animate-in slide-in-from-right-10 duration-200 overflow-y-auto">
      {/* Header */}
      <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/50 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <Badge status={vehicle.status} />
            <span className="text-xs text-slate-400 font-mono">{vehicle.group}</span>
          </div>
          <h2 className="text-lg font-bold text-white tracking-tight">{vehicle.name}</h2>
          <p className="text-xs text-blue-400 font-mono font-semibold">{vehicle.plateNumber}</p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Telemetry Body */}
      <div className="p-4 sm:p-5 space-y-5 flex-1">
        {/* Relay feedback banner */}
        {relayFeedback && (
          <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{relayFeedback}</span>
          </div>
        )}

        {/* Speedometer & Primary Gauges */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {/* Speed Card */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col">
            <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
              <Gauge className="w-3.5 h-3.5 text-blue-400" /> Speed
            </span>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-2xl font-extrabold text-white font-mono">
                {vehicle.telemetry.speed}
              </span>
              <span className="text-[10px] text-slate-400">km/h</span>
            </div>
            <span className="text-[10px] text-slate-500 mt-auto pt-1">
              Limit: {vehicle.speedLimit} km/h
            </span>
          </div>

          {/* Fuel Level */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col">
            <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
              <Fuel className="w-3.5 h-3.5 text-amber-400" /> Fuel
            </span>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-2xl font-extrabold text-white font-mono">
                {vehicle.telemetry.fuelLevel}%
              </span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
              <div
                className={`h-full rounded-full ${
                  vehicle.telemetry.fuelLevel < 20 ? 'bg-rose-500' : 'bg-amber-400'
                }`}
                style={{ width: `${vehicle.telemetry.fuelLevel}%` }}
              />
            </div>
          </div>

          {/* Battery Voltage */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col col-span-2 sm:col-span-1">
            <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" /> Battery
            </span>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-2xl font-extrabold text-white font-mono">
                {vehicle.telemetry.batteryVoltage}
              </span>
              <span className="text-[10px] text-slate-400">V</span>
            </div>
            <span className="text-[10px] text-emerald-400 mt-auto pt-1">Optimal Charging</span>
          </div>
        </div>

        {/* Secondary Diagnostics Row */}
        <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800 space-y-2.5 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-yellow-400" /> Ignition Engine State
            </span>
            <span className={`font-semibold ${vehicle.telemetry.ignition ? 'text-emerald-400' : 'text-slate-400'}`}>
              {vehicle.telemetry.ignition ? 'IGNITION ON' : 'IGNITION OFF'}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" /> Engine RPM
            </span>
            <span className="font-mono text-white font-medium">{vehicle.telemetry.engineRpm} RPM</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-cyan-400" /> GNSS Satellites
            </span>
            <span className="font-mono text-white font-medium">
              {vehicle.telemetry.satellites} Sats (HDOP {vehicle.telemetry.accuracy || 1.1}m)
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-purple-400" /> Heading Vector
            </span>
            <span className="font-mono text-white font-medium">{vehicle.telemetry.heading}° Compass</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" /> Odometer
            </span>
            <span className="font-mono text-white font-medium">
              {vehicle.telemetry.odometer.toLocaleString()} km
            </span>
          </div>
        </div>

        {/* Current Location / Geocoded Address */}
        <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5 mb-1.5">
            <MapPin className="w-3.5 h-3.5 text-rose-400" /> Last Position Report
          </span>
          <p className="text-xs text-slate-200 leading-relaxed font-medium">
            {vehicle.telemetry.address}
          </p>
          <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 font-mono">
            <span>
              {vehicle.currentPosition.lat.toFixed(5)}, {vehicle.currentPosition.lng.toFixed(5)}
            </span>
            <span>{new Date(vehicle.telemetry.timestamp).toLocaleTimeString()}</span>
          </div>
        </div>

        {/* Assigned Driver Card */}
        <div className="p-3.5 rounded-xl bg-slate-950/40 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold text-xs">
              <User className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">{vehicle.driverName}</p>
              <p className="text-[11px] text-slate-400">Driver in Command</p>
            </div>
          </div>
          <a
            href={`tel:${vehicle.driverPhone}`}
            className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
            title={`Call ${vehicle.driverPhone}`}
          >
            <Phone className="w-4 h-4 text-emerald-400" />
          </a>
        </div>

        {/* Hardware Tracker Metadata */}
        <div className="text-[11px] text-slate-400 space-y-1 p-3 rounded-xl bg-slate-950/30 border border-slate-800/60 font-mono">
          <div className="flex justify-between">
            <span>Hardware Modem:</span>
            <span className="text-slate-200">{vehicle.deviceModel}</span>
          </div>
          <div className="flex justify-between">
            <span>IMEI Serial:</span>
            <span className="text-slate-200">{vehicle.imei}</span>
          </div>
          <div className="flex justify-between">
            <span>SIM MSISDN:</span>
            <span className="text-slate-200">{vehicle.simNumber}</span>
          </div>
        </div>
      </div>

      {/* Bottom Action Footer */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/80 space-y-2">
        {/* View Route History Playback Button */}
        {onNavigateHistory && (
          <button
            type="button"
            onClick={() => onNavigateHistory(vehicle.id)}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/20 transition-all cursor-pointer"
          >
            <History className="w-4 h-4" />
            <span>Launch Historical Route Playback</span>
          </button>
        )}

        {/* Remote Cutoff / Relay Button with safety modal trigger */}
        <div className="pt-1">
          {isConfirmingRelay ? (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-600 space-y-2 animate-in fade-in duration-150">
              <p className="text-xs text-rose-200 font-medium">
                {vehicle.telemetry.relayCutoff
                  ? 'Confirm disengaging remote immobilizer?'
                  : 'WARNING: This will cut off fuel relay and immobilize engine. Proceed?'}
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={isProcessingRelay}
                  onClick={handleCutoffClick}
                  className="flex-1 py-1.5 px-3 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-colors disabled:opacity-50"
                >
                  {isProcessingRelay ? 'Sending Downlink...' : 'Confirm Command'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsConfirmingRelay(false)}
                  className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setIsConfirmingRelay(true)}
              className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-xl border text-xs font-semibold transition-all ${
                vehicle.telemetry.relayCutoff
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25'
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-300 hover:bg-rose-500/20'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>
                {vehicle.telemetry.relayCutoff
                  ? 'Immobilizer ACTIVE (Click to Restore Engine)'
                  : 'Remote Engine Immobilizer Cutoff'}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
