import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { TripHistory, RoutePoint } from '../../types';
import {
  Play,
  Pause,
  RotateCcw,
  FastForward,
  MapPin,
  Clock,
  Gauge,
  Fuel,
  Maximize2,
  Flag,
  AlertTriangle,
} from 'lucide-react';

interface HistoryRouteMapProps {
  trip: TripHistory;
  className?: string;
}

export const HistoryRouteMap: React.FC<HistoryRouteMapProps> = ({ trip, className = '' }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);
  const playbackMarkerRef = useRef<L.Marker | null>(null);
  const routeLayersRef = useRef<L.LayerGroup | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1); // 0.5x, 1x, 2x, 4x, 8x
  const [activePoint, setActivePoint] = useState<RoutePoint>(trip.points[0] || null);

  const totalPoints = trip.points.length;

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstance.current) return;

    const startPoint = trip.points[0] || { lat: 37.7749, lng: -122.4194 };
    const map = L.map(mapContainerRef.current, {
      center: [startPoint.lat, startPoint.lng],
      zoom: 11,
      zoomControl: false,
    });

    L.control.zoom({ position: 'bottomright' }).addTo(map);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap &copy; CARTO',
    }).addTo(map);

    const layerGroup = L.layerGroup().addTo(map);
    routeLayersRef.current = layerGroup;

    mapInstance.current = map;

    return () => {
      map.remove();
      mapInstance.current = null;
    };
  }, []);

  // Draw Route Polyline & Key Event Markers
  useEffect(() => {
    if (!mapInstance.current || !routeLayersRef.current || trip.points.length === 0) return;
    const layerGroup = routeLayersRef.current;
    layerGroup.clearLayers();

    const latlngs = trip.points.map((p) => [p.lat, p.lng] as [number, number]);

    // Segmented Colored Route based on speed
    for (let i = 0; i < trip.points.length - 1; i++) {
      const p1 = trip.points[i];
      const p2 = trip.points[i + 1];
      const avgSpeed = (p1.speed + p2.speed) / 2;

      let color = '#10B981'; // green cruising
      if (avgSpeed > 80) color = '#EF4444'; // red violation
      else if (avgSpeed > 65) color = '#F59E0B'; // amber moderate

      const segment = L.polyline(
        [
          [p1.lat, p1.lng],
          [p2.lat, p2.lng],
        ],
        {
          color,
          weight: 5,
          opacity: 0.9,
          lineJoin: 'round',
        }
      );
      layerGroup.addLayer(segment);
    }

    // Start Marker (Green Flag)
    const startP = trip.points[0];
    const startIcon = L.divIcon({
      className: 'custom-flag-marker',
      html: `
        <div class="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-500 text-white shadow-xl ring-4 ring-emerald-500/25">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>
          </svg>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });
    const startMarker = L.marker([startP.lat, startP.lng], { icon: startIcon });
    startMarker.bindTooltip(`<strong>Start Point:</strong> ${trip.startTime}<br/>${trip.startAddress}`, {
      direction: 'top',
    });
    layerGroup.addLayer(startMarker);

    // End Marker (Checkered Flag)
    const endP = trip.points[trip.points.length - 1];
    const endIcon = L.divIcon({
      className: 'custom-flag-marker',
      html: `
        <div class="flex items-center justify-center w-8 h-8 rounded-full bg-blue-600 text-white shadow-xl ring-4 ring-blue-600/25">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>
          </svg>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });
    const endMarker = L.marker([endP.lat, endP.lng], { icon: endIcon });
    endMarker.bindTooltip(`<strong>Destination:</strong> ${trip.endTime}<br/>${trip.endAddress}`, {
      direction: 'top',
    });
    layerGroup.addLayer(endMarker);

    // Stop & Incident Markers
    trip.points.forEach((p, idx) => {
      if (p.event === 'stop') {
        const stopIcon = L.divIcon({
          className: 'custom-stop-marker',
          html: `
            <div class="flex items-center justify-center w-6 h-6 rounded-md bg-amber-500 text-slate-950 font-black text-xs shadow-lg ring-2 ring-white">
              P
            </div>
          `,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        });
        const marker = L.marker([p.lat, p.lng], { icon: stopIcon });
        marker.bindTooltip(
          `<strong>Vehicle Stop #${idx}</strong><br/>Duration: ${p.stopDuration || 20} mins<br/>${p.address || ''}`,
          { direction: 'top' }
        );
        layerGroup.addLayer(marker);
      } else if (p.event === 'speed_violation') {
        const alertIcon = L.divIcon({
          className: 'custom-alert-marker',
          html: `
            <div class="flex items-center justify-center w-6 h-6 rounded-full bg-rose-600 text-white shadow-lg ring-2 ring-white animate-bounce">
              !
            </div>
          `,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        });
        const marker = L.marker([p.lat, p.lng], { icon: alertIcon });
        marker.bindTooltip(
          `<strong>Speed Violation</strong><br/>Logged: ${p.speed} km/h (Limit exceeded)<br/>${p.timestamp}`,
          { direction: 'top' }
        );
        layerGroup.addLayer(marker);
      }
    });

    // Fit map bounds to entire route
    const poly = L.polyline(latlngs);
    mapInstance.current.fitBounds(poly.getBounds().pad(0.1));

    // Reset playback marker to start
    setCurrentIndex(0);
    setActivePoint(trip.points[0]);
  }, [trip]);

  // Animated Playback Loop
  useEffect(() => {
    if (!isPlaying) return;

    const baseInterval = 1000;
    const intervalTime = Math.max(100, baseInterval / playbackSpeed);

    const timer = setInterval(() => {
      setCurrentIndex((prev) => {
        if (prev >= totalPoints - 1) {
          setIsPlaying(false);
          return prev;
        }
        const next = prev + 1;
        setActivePoint(trip.points[next]);
        return next;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isPlaying, playbackSpeed, totalPoints, trip.points]);

  // Update Playback Vehicle Marker Position
  useEffect(() => {
    if (!mapInstance.current || trip.points.length === 0) return;
    const map = mapInstance.current;
    const pt = trip.points[currentIndex];
    if (!pt) return;

    const heading = pt.heading || 0;
    const iconHtml = `
      <div class="relative flex items-center justify-center w-10 h-10 rounded-full bg-blue-600 text-white shadow-2xl ring-4 ring-blue-400/40">
        <div style="transform: rotate(${heading}deg)" class="transition-transform duration-300">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <polygon points="12 2 19 21 12 17 5 21 12 2" fill="white"/>
          </svg>
        </div>
      </div>
    `;

    const icon = L.divIcon({
      className: 'playback-active-marker',
      html: iconHtml,
      iconSize: [40, 40],
      iconAnchor: [20, 20],
    });

    if (playbackMarkerRef.current) {
      playbackMarkerRef.current.setLatLng([pt.lat, pt.lng]);
      playbackMarkerRef.current.setIcon(icon);
    } else {
      const marker = L.marker([pt.lat, pt.lng], { icon, zIndexOffset: 1000 }).addTo(map);
      playbackMarkerRef.current = marker;
    }

    if (isPlaying) {
      map.panTo([pt.lat, pt.lng], { animate: true });
    }
  }, [currentIndex, isPlaying, trip.points]);

  const fitRouteBounds = () => {
    if (!mapInstance.current || trip.points.length === 0) return;
    const latlngs = trip.points.map((p) => [p.lat, p.lng] as [number, number]);
    const poly = L.polyline(latlngs);
    mapInstance.current.fitBounds(poly.getBounds().pad(0.12));
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10);
    setCurrentIndex(val);
    setActivePoint(trip.points[val]);
  };

  return (
    <div className={`relative flex flex-col h-full rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl ${className}`}>
      {/* Map DOM */}
      <div ref={mapContainerRef} className="flex-1 w-full min-h-[360px] z-0" />

      {/* Floating Active Playback HUD Overlay at Top */}
      {activePoint && (
        <div className="absolute top-4 left-4 z-20 p-3 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-700/80 shadow-2xl flex items-center gap-4 text-xs text-slate-200">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <div>
              <p className="text-[10px] text-slate-400 uppercase font-semibold">Route Timestamp</p>
              <p className="font-mono font-bold text-white">{activePoint.timestamp}</p>
            </div>
          </div>

          <div className="h-6 w-px bg-slate-800" />

          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-emerald-400" />
            <div>
              <p className="text-[10px] text-slate-400 uppercase font-semibold">Speed</p>
              <p className="font-mono font-bold text-white">{activePoint.speed} km/h</p>
            </div>
          </div>

          <div className="h-6 w-px bg-slate-800 hidden sm:block" />

          <div className="hidden sm:flex items-center gap-2">
            <Fuel className="w-4 h-4 text-amber-400" />
            <div>
              <p className="text-[10px] text-slate-400 uppercase font-semibold">Fuel Tank</p>
              <p className="font-mono font-bold text-white">{activePoint.fuelLevel || 78}%</p>
            </div>
          </div>

          <button
            type="button"
            onClick={fitRouteBounds}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors ml-auto"
            title="Fit Entire Route"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Playback Controls Footer Bar */}
      <div className="p-4 bg-slate-900 border-t border-slate-800 flex flex-col gap-3 z-10">
        {/* Timeline Slider with Progress */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-slate-400 w-12 text-left">
            {activePoint?.timestamp || trip.startTime}
          </span>

          <input
            type="range"
            min="0"
            max={totalPoints - 1}
            value={currentIndex}
            onChange={handleSliderChange}
            className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600 focus:outline-hidden"
          />

          <span className="text-xs font-mono text-slate-400 w-12 text-right">
            {trip.endTime}
          </span>
        </div>

        {/* Buttons & Multipliers */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {/* Reset / Rewind */}
            <button
              type="button"
              onClick={() => {
                setIsPlaying(false);
                setCurrentIndex(0);
                setActivePoint(trip.points[0]);
              }}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
              title="Rewind to start"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Play / Pause */}
            <button
              type="button"
              onClick={() => {
                if (currentIndex >= totalPoints - 1) {
                  setCurrentIndex(0);
                }
                setIsPlaying(!isPlaying);
              }}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
              <span>{isPlaying ? 'Pause Playback' : 'Start Playback'}</span>
            </button>
          </div>

          {/* Speed Multipliers (0.5x, 1x, 2x, 4x, 8x) */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            {[0.5, 1, 2, 4, 8].map((rate) => (
              <button
                key={rate}
                type="button"
                onClick={() => setPlaybackSpeed(rate)}
                className={`px-2 py-1 rounded-lg text-xs font-semibold font-mono transition-colors ${
                  playbackSpeed === rate
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
