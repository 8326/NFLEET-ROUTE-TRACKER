import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Vehicle, GeofenceZone, Coordinates } from '../../types';
import { Layers, Navigation, Maximize2, ShieldAlert, Crosshair } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

interface LiveFleetMapProps {
  vehicles: Vehicle[];
  selectedVehicle: Vehicle | null;
  onSelectVehicle: (vehicle: Vehicle) => void;
  geofences?: GeofenceZone[];
  centerTarget?: Coordinates | null;
  className?: string;
  showGeofencesToggle?: boolean;
}

export const LiveFleetMap: React.FC<LiveFleetMapProps> = ({
  vehicles,
  selectedVehicle,
  onSelectVehicle,
  geofences = [],
  centerTarget,
  className = '',
  showGeofencesToggle = true,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);
  const markersRef = useRef<Record<string, L.Marker>>({});
  const geofenceLayersRef = useRef<L.LayerGroup | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const { effectiveTheme } = useTheme();

  const [tileMode, setTileMode] = useState<'dark' | 'street' | 'satellite'>(
    effectiveTheme === 'dark' ? 'dark' : 'street'
  );
  const [showGeofences, setShowGeofences] = useState<boolean>(true);
  const [followSelected, setFollowSelected] = useState<boolean>(false);

  // Tile layer URLs
  const tileProviders = {
    dark: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    street: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    satellite: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstance.current) return;

    const initialCenter = selectedVehicle
      ? [selectedVehicle.currentPosition.lat, selectedVehicle.currentPosition.lng]
      : [37.7749, -122.4194];

    const map = L.map(mapContainerRef.current, {
      center: initialCenter as L.LatLngExpression,
      zoom: 12,
      zoomControl: false,
    });

    // Add custom zoom control in bottom right
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Initial Tile Layer
    const tileUrl = tileProviders[tileMode];
    const tiles = L.tileLayer(tileUrl, {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap &copy; CARTO',
    }).addTo(map);
    tileLayerRef.current = tiles;

    // Layer group for geofences
    const gfGroup = L.layerGroup().addTo(map);
    geofenceLayersRef.current = gfGroup;

    mapInstance.current = map;

    return () => {
      map.remove();
      mapInstance.current = null;
    };
  }, []);

  // Update tile provider when theme or mode changes
  useEffect(() => {
    if (!mapInstance.current || !tileLayerRef.current) return;
    mapInstance.current.removeLayer(tileLayerRef.current);
    const newTiles = L.tileLayer(tileProviders[tileMode], {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap',
    }).addTo(mapInstance.current);
    tileLayerRef.current = newTiles;
  }, [tileMode]);

  // Center target effect (when user clicks vehicle in list)
  useEffect(() => {
    if (!mapInstance.current || !centerTarget) return;
    mapInstance.current.flyTo([centerTarget.lat, centerTarget.lng], 14, {
      duration: 1.2,
      easeLinearity: 0.25,
    });
  }, [centerTarget]);

  // Render / Update Geofences
  useEffect(() => {
    if (!mapInstance.current || !geofenceLayersRef.current) return;
    geofenceLayersRef.current.clearLayers();

    if (!showGeofences) return;

    geofences.forEach((zone) => {
      if (zone.type === 'circle' && zone.center && zone.radiusMeters) {
        const circle = L.circle([zone.center.lat, zone.center.lng], {
          radius: zone.radiusMeters,
          color: zone.color,
          fillColor: zone.color,
          fillOpacity: 0.12,
          weight: 2,
          dashArray: '4, 6',
        });
        circle.bindTooltip(`<strong>${zone.name}</strong><br/>Limit: ${zone.speedLimitKmH || 40} km/h`, {
          direction: 'top',
          className: 'leaflet-tooltip-dark',
        });
        geofenceLayersRef.current?.addLayer(circle);
      } else if (zone.type === 'polygon' && zone.polygonCoordinates) {
        const latlngs = zone.polygonCoordinates.map((c) => [c.lat, c.lng] as [number, number]);
        const polygon = L.polygon(latlngs, {
          color: zone.color,
          fillColor: zone.color,
          fillOpacity: 0.14,
          weight: 2,
          dashArray: '5, 5',
        });
        polygon.bindTooltip(`<strong>${zone.name}</strong><br/>Restricted Zone`, {
          direction: 'top',
          className: 'leaflet-tooltip-dark',
        });
        geofenceLayersRef.current?.addLayer(polygon);
      }
    });
  }, [geofences, showGeofences]);

  // Render & Smoothly Update Vehicle Markers
  useEffect(() => {
    if (!mapInstance.current) return;
    const map = mapInstance.current;

    vehicles.forEach((vehicle) => {
      const isSelected = selectedVehicle?.id === vehicle.id;
      const statusColor = {
        moving: '#10B981', // emerald
        idle: '#F59E0B',   // amber
        stopped: '#64748B',// slate
        offline: '#71717A',// zinc
        alert: '#EF4444',  // red
      }[vehicle.status];

      const html = `
        <div class="relative group cursor-pointer transition-transform duration-300 transform -translate-x-1/2 -translate-y-1/2">
          ${
            isSelected
              ? `<div class="absolute -inset-2.5 rounded-full bg-blue-500/30 animate-ping-slow pointer-events-none"></div>`
              : ''
          }
          <div class="relative flex items-center justify-center w-10 h-10 rounded-xl shadow-xl transition-all ${
            isSelected ? 'ring-2 ring-white scale-110' : ''
          }" style="background: #0f172a; border: 2px solid ${statusColor}">
            <!-- Directional arrow -->
            <div style="transform: rotate(${vehicle.telemetry.heading}deg)" class="transition-transform duration-500">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${statusColor}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <polygon points="12 2 19 21 12 17 5 21 12 2" fill="${statusColor}" fill-opacity="0.85"/>
              </svg>
            </div>
            
            <!-- Speed Pill Badge -->
            <div class="absolute -bottom-2 px-1 py-0.2 rounded-sm text-[9px] font-bold text-white bg-slate-900 border border-slate-700 shadow-xs">
              ${vehicle.telemetry.speed}k
            </div>
          </div>
          
          <!-- Hover / Persistent Plate Tag -->
          <div class="absolute left-1/2 -translate-x-1/2 -top-6 whitespace-nowrap px-1.5 py-0.5 rounded-md bg-slate-900/90 text-slate-200 border border-slate-700 text-[10px] font-bold shadow-md pointer-events-none">
            ${vehicle.plateNumber}
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-vehicle-icon',
        html,
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      });

      if (markersRef.current[vehicle.id]) {
        // Update marker position and icon smoothly
        const marker = markersRef.current[vehicle.id];
        marker.setLatLng([vehicle.currentPosition.lat, vehicle.currentPosition.lng]);
        marker.setIcon(customIcon);

        if (isSelected && followSelected) {
          map.panTo([vehicle.currentPosition.lat, vehicle.currentPosition.lng], { animate: true });
        }
      } else {
        // Create new marker
        const marker = L.marker([vehicle.currentPosition.lat, vehicle.currentPosition.lng], {
          icon: customIcon,
        }).addTo(map);

        marker.on('click', () => {
          onSelectVehicle(vehicle);
        });

        markersRef.current[vehicle.id] = marker;
      }
    });

    // Cleanup markers that are no longer present
    Object.keys(markersRef.current).forEach((id) => {
      if (!vehicles.find((v) => v.id === id)) {
        markersRef.current[id].remove();
        delete markersRef.current[id];
      }
    });
  }, [vehicles, selectedVehicle, followSelected]);

  const fitAllVehicles = () => {
    if (!mapInstance.current || vehicles.length === 0) return;
    const group = L.featureGroup(Object.values(markersRef.current));
    mapInstance.current.fitBounds(group.getBounds().pad(0.15));
  };

  return (
    <div className={`relative w-full h-full rounded-2xl overflow-hidden shadow-xl border border-slate-800 ${className}`}>
      {/* Leaflet Map DOM Element */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Floating Map Controls Toolbar */}
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
        {/* Layer Tile Mode Switcher */}
        <div className="p-1 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-700/80 shadow-xl flex flex-col gap-1">
          <button
            type="button"
            onClick={() => setTileMode('dark')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg text-left transition-colors ${
              tileMode === 'dark' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
            title="Dark Carto Vector Layer"
          >
            Dark
          </button>
          <button
            type="button"
            onClick={() => setTileMode('street')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg text-left transition-colors ${
              tileMode === 'street' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
            title="OpenStreetMap Standard Layer"
          >
            Street
          </button>
          <button
            type="button"
            onClick={() => setTileMode('satellite')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg text-left transition-colors ${
              tileMode === 'satellite' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
            title="High Resolution Esri Satellite"
          >
            Satellite
          </button>
        </div>

        {/* Action buttons */}
        <button
          type="button"
          onClick={fitAllVehicles}
          className="p-2.5 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-700/80 shadow-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-all"
          title="Fit Entire Fleet in View"
        >
          <Maximize2 className="w-4 h-4" />
        </button>

        {showGeofencesToggle && (
          <button
            type="button"
            onClick={() => setShowGeofences(!showGeofences)}
            className={`p-2.5 rounded-xl backdrop-blur-md border shadow-xl transition-all ${
              showGeofences
                ? 'bg-blue-600 text-white border-blue-500'
                : 'bg-slate-900/90 text-slate-400 border-slate-700/80 hover:text-white'
            }`}
            title="Toggle Geofence Zones"
          >
            <ShieldAlert className="w-4 h-4" />
          </button>
        )}

        <button
          type="button"
          onClick={() => setFollowSelected(!followSelected)}
          className={`p-2.5 rounded-xl backdrop-blur-md border shadow-xl transition-all ${
            followSelected
              ? 'bg-emerald-600 text-white border-emerald-500 animate-pulse'
              : 'bg-slate-900/90 text-slate-400 border-slate-700/80 hover:text-white'
          }`}
          title="Auto Follow Selected Vehicle"
        >
          <Crosshair className="w-4 h-4" />
        </button>
      </div>

      {/* Floating Status Bar at Map Bottom Left */}
      <div className="absolute bottom-4 left-4 z-20 flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-800 text-xs text-slate-300 shadow-xl">
        <span className="flex h-2 w-2 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
        </span>
        <span className="font-semibold text-white">{vehicles.length} Units Online</span>
        <span className="text-slate-500">|</span>
        <span>Tile: {tileMode.toUpperCase()}</span>
      </div>
    </div>
  );
};
