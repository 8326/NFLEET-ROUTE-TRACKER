import React from 'react';
import { VehicleStatus, AlertSeverity } from '../../types';

interface BadgeProps {
  status?: VehicleStatus | AlertSeverity | string;
  variant?: 'status' | 'severity' | 'outline' | 'neutral';
  children?: React.ReactNode;
  className?: string;
  dot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  status,
  variant = 'status',
  children,
  className = '',
  dot = true,
}) => {
  const getColors = () => {
    switch (status) {
      case 'moving':
        return { bg: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', dot: 'bg-emerald-500' };
      case 'idle':
        return { bg: 'bg-amber-500/15 text-amber-400 border-amber-500/30', dot: 'bg-amber-400' };
      case 'stopped':
        return { bg: 'bg-slate-500/15 text-slate-400 border-slate-500/30', dot: 'bg-slate-400' };
      case 'offline':
        return { bg: 'bg-zinc-500/15 text-zinc-400 border-zinc-500/30', dot: 'bg-zinc-500' };
      case 'alert':
      case 'critical':
        return { bg: 'bg-rose-500/15 text-rose-400 border-rose-500/30', dot: 'bg-rose-500' };
      case 'warning':
        return { bg: 'bg-amber-500/15 text-amber-400 border-amber-500/30', dot: 'bg-amber-500' };
      case 'info':
        return { bg: 'bg-blue-500/15 text-blue-400 border-blue-500/30', dot: 'bg-blue-400' };
      default:
        return { bg: 'bg-slate-800 text-slate-300 border-slate-700', dot: 'bg-slate-400' };
    }
  };

  const colors = getColors();

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border uppercase tracking-wider ${colors.bg} ${className}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${colors.dot} ${status === 'moving' ? 'animate-pulse' : ''}`} />}
      <span>{children || status}</span>
    </span>
  );
};
