import React, { useState } from 'react';
import { Modal } from './Modal';
import { Radio, Wifi, Server, CheckCircle2, AlertCircle, Copy, Check, Info } from 'lucide-react';
import { getApiBaseUrl, getWsUrl, setApiEndpoints } from '../../services/apiConfig';
import { useFleet } from '../../context/FleetContext';
import { gpsService } from '../../services/gpsService';

interface ApiGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApiGatewayModal: React.FC<ApiGatewayModalProps> = ({ isOpen, onClose }) => {
  const { isDemoMode, connectionStatus } = useFleet();

  const [apiUrl, setApiUrl] = useState(getApiBaseUrl());
  const [wsUrl, setWsUrl] = useState(getWsUrl());
  const [testSuccess, setTestSuccess] = useState<boolean | null>(null);
  const [copied, setCopied] = useState(false);

  const handleSaveAndConnect = () => {
    setApiEndpoints(apiUrl.trim(), wsUrl.trim());

    if (wsUrl.trim()) {
      gpsService.connectWebSocket(wsUrl.trim());
    } else {
      gpsService.startDemoSimulation();
    }

    setTestSuccess(true);
    setTimeout(() => {
      onClose();
      setTestSuccess(null);
    }, 1200);
  };

  const handleResetToDemo = () => {
    setApiUrl('');
    setWsUrl('');
    setApiEndpoints('', '');
    gpsService.startDemoSimulation();
    setTestSuccess(true);
    setTimeout(() => {
      onClose();
      setTestSuccess(null);
    }, 800);
  };

  const sampleJsonPacket = JSON.stringify(
    {
      imei: '864201948271034',
      lat: 37.7749,
      lng: -122.4194,
      speed: 68,
      heading: 42,
      ignition: true,
      satellites: 14,
      batteryVoltage: 24.6,
      fuelLevel: 78,
      address: 'I-80 Corridor Mile 14',
      timestamp: new Date().toISOString(),
    },
    null,
    2
  );

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Telematics & GPS Gateway Connectivity"
      subtitle="Connect live tracking devices via REST API or real-time WebSocket protocol"
      maxWidth="xl"
    >
      <div className="space-y-5 text-sm">
        {/* Current State Status Banner */}
        <div
          className={`p-4 rounded-xl border flex items-start gap-3.5 ${
            isDemoMode
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
              : connectionStatus === 'connected'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-200'
          }`}
        >
          {isDemoMode ? (
            <Radio className="w-5 h-5 text-amber-400 shrink-0 mt-0.5 animate-pulse" />
          ) : (
            <Wifi className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          )}
          <div>
            <p className="font-bold text-white">
              {isDemoMode
                ? 'Active State: DEMO MODE (Simulated Telematics Engine)'
                : `Active State: ${connectionStatus.toUpperCase()}`}
            </p>
            <p className="text-xs mt-1 text-slate-300">
              {isDemoMode
                ? 'Displaying procedural simulated GPS beacons, highway movement curves, fuel depletion, and diagnostic sensors. No hardware trackers are currently streaming.'
                : 'Connected to live hardware broker. Receiving live NMEA/JT808/Teltonika telemetry packets.'}
            </p>
          </div>
        </div>

        {/* Input Endpoints */}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              REST API Base URL (VITE_API_BASE_URL)
            </label>
            <input
              type="text"
              value={apiUrl}
              onChange={(e) => setApiUrl(e.target.value)}
              placeholder="e.g. https://api.yourfleet.com or http://localhost:8080"
              className="w-full px-3.5 py-2.5 bg-slate-950 text-white rounded-xl border border-slate-700 font-mono text-xs focus:outline-hidden focus:border-blue-500"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              Used for vehicle management, trip history audits, user accounts, and report queries.
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Live WebSocket Stream URL (VITE_WS_URL)
            </label>
            <input
              type="text"
              value={wsUrl}
              onChange={(e) => setWsUrl(e.target.value)}
              placeholder="e.g. wss://stream.yourfleet.com/gps/ws or ws://localhost:8081"
              className="w-full px-3.5 py-2.5 bg-slate-950 text-white rounded-xl border border-slate-700 font-mono text-xs focus:outline-hidden focus:border-blue-500"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              Subscribes to live position pings, CAN-Bus diagnostics, speed breaches, and emergency alerts.
            </span>
          </div>
        </div>

        {/* Payload reference */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-400" /> Expected WebSocket Packet Format
            </span>
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(sampleJsonPacket);
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              }}
              className="flex items-center gap-1 text-[10px] text-blue-400 hover:text-blue-300"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'Copied' : 'Copy Sample'}</span>
            </button>
          </div>
          <pre className="text-[11px] font-mono text-slate-300 overflow-x-auto max-h-36 p-2 rounded-lg bg-slate-900 border border-slate-800">
            {sampleJsonPacket}
          </pre>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={handleResetToDemo}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Reset to High-Fidelity Demo
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveAndConnect}
              className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/20 transition-all flex items-center gap-1.5"
            >
              {testSuccess ? <CheckCircle2 className="w-4 h-4 text-white" /> : <Server className="w-4 h-4" />}
              <span>{testSuccess ? 'Applied Successfully' : 'Apply Configuration'}</span>
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
