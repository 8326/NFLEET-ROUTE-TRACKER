import React from 'react';

interface NfleetLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showTagline?: boolean;
  lightText?: boolean;
}

export const NfleetLogo: React.FC<NfleetLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
  showTagline = false,
  lightText = false,
}) => {
  const sizeMap = {
    sm: { icon: 28, text: 'text-lg', badge: 'w-7 h-7' },
    md: { icon: 38, text: 'text-2xl', badge: 'w-9 h-9' },
    lg: { icon: 48, text: 'text-3xl', badge: 'w-12 h-12' },
    xl: { icon: 64, text: 'text-4xl', badge: 'w-16 h-16' },
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Exact Vector Emblem based on user brand asset */}
      <div className={`relative flex items-center justify-center shrink-0 ${currentSize.badge}`}>
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow-sm"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Outer Royal Blue Ring */}
          <circle
            cx="50"
            cy="50"
            r="44"
            stroke="#2563EB"
            strokeWidth="7.5"
            className="transition-colors duration-200"
          />
          {/* Dynamic Italic Red N */}
          <path
            d="M32 68L39 30H47L58 54V30H67L60 70H52L41 46V68H32Z"
            fill="#EF4444"
          />
          {/* Red dynamic upward curved swoop / smile curve at base */}
          <path
            d="M33 73C44 76 60 75 70 63C65 71 50 78 33 73Z"
            fill="#EF4444"
          />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col leading-none">
          <div className={`font-extrabold tracking-tight flex items-baseline ${currentSize.text}`}>
            {/* Red 'N' */}
            <span className="text-[#EF4444]">N</span>
            {/* Blue 'fleet' */}
            <span className="text-[#2563EB]">fleet</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 ml-1 mb-1 animate-pulse" title="Live Telemetry Engine Online" />
          </div>
          {showTagline && (
            <span className={`text-[10px] font-semibold tracking-widest uppercase mt-0.5 ${lightText ? 'text-slate-400' : 'text-slate-500'}`}>
              GPS Fleet Telematics
            </span>
          )}
        </div>
      )}
    </div>
  );
};
