import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Vehicle, GeofenceZone, AlertIncident, Driver, DeviceTracker, FleetStats, Coordinates } from '../types';
import { INITIAL_VEHICLES, INITIAL_GEOFENCES, INITIAL_ALERTS, INITIAL_DRIVERS, INITIAL_DEVICES } from '../data/mockFleetData';
import { vehicleService } from '../services/vehicleService';
import { gpsService, ConnectionStatusCallback } from '../services/gpsService';
import { alertService } from '../services/alertService';

interface FleetContextType {
  vehicles: Vehicle[];
  selectedVehicle: Vehicle | null;
  setSelectedVehicle: (vehicle: Vehicle | null) => void;
  geofences: GeofenceZone[];
  alerts: AlertIncident[];
  drivers: Driver[];
  devices: DeviceTracker[];
  stats: FleetStats;
  connectionStatus: 'connected' | 'connecting' | 'demo_simulated' | 'disconnected';
  isDemoMode: boolean;
  activeFilter: string;
  setActiveFilter: (filter: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  mapCenterTarget: Coordinates | null;
  flyToVehicle: (vehicle: Vehicle) => void;
  toggleRemoteCutoff: (vehicleId: string) => Promise<boolean>;
  acknowledgeAlert: (alertId: string, notes?: string) => Promise<void>;
  addVehicle: (data: any) => Promise<Vehicle>;
  addGeofence: (zone: GeofenceZone) => void;
  addDriver: (driver: Driver) => void;
  addDevice: (device: DeviceTracker) => void;
  latestTelemetryPacket: any;
  livePacketCount: number;
}

const FleetContext = createContext<FleetContextType | undefined>(undefined);

export const FleetProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(INITIAL_VEHICLES);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(INITIAL_VEHICLES[0]);
  const [geofences, setGeofences] = useState<GeofenceZone[]>(INITIAL_GEOFENCES);
  const [alerts, setAlerts] = useState<AlertIncident[]>(INITIAL_ALERTS);
  const [drivers, setDrivers] = useState<Driver[]>(INITIAL_DRIVERS);
  const [devices, setDevices] = useState<DeviceTracker[]>(INITIAL_DEVICES);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [mapCenterTarget, setMapCenterTarget] = useState<Coordinates | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'connecting' | 'demo_simulated' | 'disconnected'>('demo_simulated');
  const [latestTelemetryPacket, setLatestTelemetryPacket] = useState<any>(null);
  const [livePacketCount, setLivePacketCount] = useState<number>(142);

  // Initialize GPS service with initial vehicles
  useEffect(() => {
    gpsService.init(INITIAL_VEHICLES);

    const unsubTelemetry = gpsService.subscribe((updatedVehicles, packet) => {
      setVehicles([...updatedVehicles]);
      if (packet) {
        setLatestTelemetryPacket(packet);
      }
      setLivePacketCount((prev) => prev + 1);

      // Keep selected vehicle data fresh
      setSelectedVehicle((prev) => {
        if (!prev) return null;
        const fresh = updatedVehicles.find((v) => v.id === prev.id);
        return fresh || prev;
      });
    });

    const unsubStatus = gpsService.subscribeStatus((status) => {
      setConnectionStatus(status);
    });

    return () => {
      unsubTelemetry();
      unsubStatus();
    };
  }, []);

  const flyToVehicle = useCallback((vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    setMapCenterTarget({ ...vehicle.currentPosition });
  }, []);

  const toggleRemoteCutoff = async (vehicleId: string): Promise<boolean> => {
    const target = vehicles.find((v) => v.id === vehicleId);
    if (!target) return false;
    const currentState = target.telemetry.relayCutoff;
    const newState = await vehicleService.toggleRemoteRelay(vehicleId, currentState);

    setVehicles((prev) =>
      prev.map((v) =>
        v.id === vehicleId
          ? {
              ...v,
              telemetry: { ...v.telemetry, relayCutoff: newState },
              status: newState ? 'stopped' : v.status,
            }
          : v
      )
    );

    if (selectedVehicle?.id === vehicleId) {
      setSelectedVehicle((prev) =>
        prev
          ? {
              ...prev,
              telemetry: { ...prev.telemetry, relayCutoff: newState },
              status: newState ? 'stopped' : prev.status,
            }
          : null
      );
    }

    return newState;
  };

  const acknowledgeAlert = async (alertId: string, notes?: string) => {
    await alertService.acknowledgeAlert(alertId, 'Operator Command', notes);
    setAlerts((prev) =>
      prev.map((a) =>
        a.id === alertId
          ? {
              ...a,
              acknowledged: true,
              acknowledgedBy: 'Commander Console',
              acknowledgedAt: new Date().toISOString(),
              resolutionNotes: notes || 'Incident acknowledged and logged.',
            }
          : a
      )
    );
  };

  const addVehicle = async (data: any): Promise<Vehicle> => {
    const newVeh = await vehicleService.addVehicle(data);
    setVehicles((prev) => [newVeh, ...prev]);
    return newVeh;
  };

  const addGeofence = (zone: GeofenceZone) => {
    setGeofences((prev) => [zone, ...prev]);
  };

  const addDriver = (driver: Driver) => {
    setDrivers((prev) => [driver, ...prev]);
  };

  const addDevice = (device: DeviceTracker) => {
    setDevices((prev) => [device, ...prev]);
  };

  // Dynamic Fleet Stats
  const totalVehicles = vehicles.length;
  const movingVehicles = vehicles.filter((v) => v.status === 'moving').length;
  const idleVehicles = vehicles.filter((v) => v.status === 'idle').length;
  const stoppedVehicles = vehicles.filter((v) => v.status === 'stopped').length;
  const offlineVehicles = vehicles.filter((v) => v.status === 'offline').length;
  const onlineVehicles = totalVehicles - offlineVehicles;
  const activeAlerts = alerts.filter((a) => !a.acknowledged).length;

  const totalDistanceTodayKm = vehicles.reduce((sum, v) => sum + (v.telemetry.odometer % 450), 1280);
  const fleetUtilizationPercent = Math.round(((movingVehicles + idleVehicles) / totalVehicles) * 100);
  const movingSpeeds = vehicles.filter((v) => v.status === 'moving').map((v) => v.telemetry.speed);
  const avgFleetSpeedKmH = movingSpeeds.length ? Math.round(movingSpeeds.reduce((a, b) => a + b, 0) / movingSpeeds.length) : 0;

  const stats: FleetStats = {
    totalVehicles,
    onlineVehicles,
    movingVehicles,
    idleVehicles,
    stoppedVehicles,
    offlineVehicles,
    activeAlerts,
    totalDistanceTodayKm,
    fleetUtilizationPercent,
    avgFleetSpeedKmH,
  };

  return (
    <FleetContext.Provider
      value={{
        vehicles,
        selectedVehicle,
        setSelectedVehicle,
        geofences,
        alerts,
        drivers,
        devices,
        stats,
        connectionStatus,
        isDemoMode: connectionStatus === 'demo_simulated',
        activeFilter,
        setActiveFilter,
        searchQuery,
        setSearchQuery,
        mapCenterTarget,
        flyToVehicle,
        toggleRemoteCutoff,
        acknowledgeAlert,
        addVehicle,
        addGeofence,
        addDriver,
        addDevice,
        latestTelemetryPacket,
        livePacketCount,
      }}
    >
      {children}
    </FleetContext.Provider>
  );
};

export const useFleet = () => {
  const context = useContext(FleetContext);
  if (!context) throw new Error('useFleet must be used within FleetProvider');
  return context;
};
