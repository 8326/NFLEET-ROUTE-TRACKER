import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { ThemeToggle } from '../components/common/ThemeToggle';
import {
  User,
  Lock,
  Bell,
  Map,
  Sliders,
  ShieldCheck,
  CheckCircle2,
  Save,
  Radio,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { user } = useAuth();
  const { theme, setTheme } = useTheme();

  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'notifications' | 'map'>('profile');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Profile Form State
  const [name, setName] = useState(user?.name || 'Alexander Sterling');
  const [email, setEmail] = useState(user?.email || 'admin@nfleet.io');
  const [organization, setOrganization] = useState(user?.organization || 'Global Fleet Logistics');
  const [timezone, setTimezone] = useState(user?.timezone || 'America/Los_Angeles (PST)');

  // Notifications State
  const [notifOverspeed, setNotifOverspeed] = useState(true);
  const [notifGeofence, setNotifGeofence] = useState(true);
  const [notifIgnition, setNotifIgnition] = useState(true);
  const [notifBattery, setNotifBattery] = useState(true);
  const [notifEmailDigest, setNotifEmailDigest] = useState(false);

  // Map Settings
  const [speedUnit, setSpeedUnit] = useState<'kmh' | 'mph'>('kmh');
  const [defaultZoom, setDefaultZoom] = useState(12);
  const [markerCluster, setMarkerCluster] = useState(true);

  // Password State
  const [currPassword, setCurrPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const tabs = [
    { id: 'profile', label: 'User Profile & Fleet Org', icon: User },
    { id: 'security', label: 'Security & Access Keys', icon: Lock },
    { id: 'notifications', label: 'Incident Notifications', icon: Bell },
    { id: 'map', label: 'Map & Unit Preferences', icon: Map },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          System & Account Settings
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Configure personal dispatch profile, security authentication, notification rules, and GIS preferences.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Configuration changes successfully committed and synced across sessions.</span>
        </div>
      )}

      {/* Main Settings Card */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden flex flex-col md:flex-row">
        {/* Settings Left Navigation */}
        <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-slate-800 p-3 space-y-1 bg-slate-950/40">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2.5 w-full px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all text-left ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Settings Content Area */}
        <main className="flex-1 p-6">
          {/* Profile Tab */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-3">
                Operator Profile Information
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Full Legal Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Organization / Enterprise Fleet</label>
                  <input
                    type="text"
                    value={organization}
                    onChange={(e) => setOrganization(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Dispatch Timezone</label>
                  <input
                    type="text"
                    value={timezone}
                    onChange={(e) => setTimezone(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500 font-mono"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Profile</span>
                </button>
              </div>
            </form>
          )}

          {/* Security Tab */}
          {activeTab === 'security' && (
            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-3">
                Security & Authentication
              </h2>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Current Password</label>
                <input
                  type="password"
                  value={currPassword}
                  onChange={(e) => setCurrPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full max-w-md px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-md">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">New Password</label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Confirm New Password</label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1 text-slate-400">
                <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" /> Multi-Factor Dispatch Authentication
                </span>
                <p className="text-[11px]">Two-Factor Hardware FIDO2 / Authenticator token active for super admin role.</p>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Update Password</span>
                </button>
              </div>
            </form>
          )}

          {/* Notifications Tab */}
          {activeTab === 'notifications' && (
            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-3">
                Fleet Incident Alert Triggers
              </h2>

              <div className="space-y-3">
                {[
                  {
                    id: 'overspeed',
                    label: 'Overspeed Violations',
                    desc: 'Instant broadcast when a unit exceeds the road or vehicle limit by >5 km/h',
                    val: notifOverspeed,
                    set: setNotifOverspeed,
                  },
                  {
                    id: 'geofence',
                    label: 'Geofence Perimeter Breaches',
                    desc: 'Notify when vehicles enter or depart authorized zone boundaries',
                    val: notifGeofence,
                    set: setNotifGeofence,
                  },
                  {
                    id: 'ignition',
                    label: 'Unauthorized Ignition & After-Hours Moving',
                    desc: 'Alert when engine starts during restricted curfew hours',
                    val: notifIgnition,
                    set: setNotifIgnition,
                  },
                  {
                    id: 'battery',
                    label: 'Critical Vehicle Battery Drain',
                    desc: 'Notify when starter battery drops under 11.5V',
                    val: notifBattery,
                    set: setNotifBattery,
                  },
                ].map((item) => (
                  <label
                    key={item.id}
                    className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors"
                  >
                    <input
                      type="checkbox"
                      checked={item.val}
                      onChange={(e) => item.set(e.target.checked)}
                      className="mt-0.5 w-4 h-4 rounded-sm bg-slate-900 border-slate-700 text-blue-600 focus:ring-blue-500"
                    />
                    <div>
                      <p className="font-bold text-white">{item.label}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{item.desc}</p>
                    </div>
                  </label>
                ))}
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Notification Rules</span>
                </button>
              </div>
            </form>
          )}

          {/* Map Preferences */}
          {activeTab === 'map' && (
            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-3">
                GIS Map & Telematics Unit Preferences
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Speed & Odometer Units</label>
                  <select
                    value={speedUnit}
                    onChange={(e) => setSpeedUnit(e.target.value as any)}
                    className="w-full px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700"
                  >
                    <option value="kmh">Metric (km/h & Kilometers)</option>
                    <option value="mph">Imperial (mph & Miles)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Default GIS Zoom Level</label>
                  <input
                    type="number"
                    min="3"
                    max="18"
                    value={defaultZoom}
                    onChange={(e) => setDefaultZoom(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 font-mono"
                  />
                </div>
              </div>

              <div className="pt-2">
                <label className="block text-slate-300 font-semibold mb-2">Platform Color Scheme</label>
                <ThemeToggle />
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Apply Map Settings</span>
                </button>
              </div>
            </form>
          )}
        </main>
      </div>
    </div>
  );
};
