import React, { useState, useMemo } from 'react';
import { useFleet } from '../context/FleetContext';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { AlertIncident, AlertType, AlertSeverity } from '../types';
import {
  AlertTriangle,
  AlertOctagon,
  ShieldAlert,
  Zap,
  WifiOff,
  BatteryWarning,
  Flame,
  CheckCircle2,
  Filter,
  Search,
  Check,
  MapPin,
  Clock,
  Truck,
  MessageSquare,
  Navigation,
} from 'lucide-react';

interface AlertsPageProps {
  onNavigateMap: (vehicleId: string) => void;
}

export const AlertsPage: React.FC<AlertsPageProps> = ({ onNavigateMap }) => {
  const { alerts, acknowledgeAlert, vehicles, flyToVehicle } = useFleet();

  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [search, setSearch] = useState<string>('');

  // Acknowledge Modal
  const [selectedAlert, setSelectedAlert] = useState<AlertIncident | null>(null);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const filteredAlerts = useMemo(() => {
    return alerts.filter((a) => {
      const matchesType = typeFilter === 'all' || a.type === typeFilter;
      const matchesSev = severityFilter === 'all' || a.severity === severityFilter;
      const q = search.toLowerCase().trim();
      const matchesSearch =
        !q ||
        a.title.toLowerCase().includes(q) ||
        a.vehicleName.toLowerCase().includes(q) ||
        a.plateNumber.toLowerCase().includes(q) ||
        a.address.toLowerCase().includes(q);

      return matchesType && matchesSev && matchesSearch;
    });
  }, [alerts, typeFilter, severityFilter, search]);

  const handleAcknowledgeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAlert) return;

    setIsSubmitting(true);
    try {
      await acknowledgeAlert(selectedAlert.id, notes);
      setSelectedAlert(null);
      setNotes('');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getAlertIcon = (type: AlertType) => {
    switch (type) {
      case 'overspeed':
        return <Flame className="w-4 h-4 text-rose-500" />;
      case 'geofence_breach':
        return <ShieldAlert className="w-4 h-4 text-amber-500" />;
      case 'ignition_unauthorized':
        return <Zap className="w-4 h-4 text-yellow-500" />;
      case 'offline':
        return <WifiOff className="w-4 h-4 text-zinc-400" />;
      case 'battery_low':
        return <BatteryWarning className="w-4 h-4 text-amber-400" />;
      case 'harsh_braking':
      case 'harsh_acceleration':
        return <AlertOctagon className="w-4 h-4 text-rose-400" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-rose-400" />;
    }
  };

  const unreadCount = alerts.filter((a) => !a.acknowledged).length;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Fleet Incident & Alert Center</span>
            {unreadCount > 0 && (
              <span className="text-xs bg-rose-500/20 text-rose-400 font-bold px-2.5 py-1 rounded-full border border-rose-500/30 animate-pulse">
                {unreadCount} Unresolved
              </span>
            )}
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Real-time threshold telemetry monitoring: overspeeding, geofence breaches, CAN diagnostics, and harsh events.
          </p>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search alerts, plates, locations..."
            className="w-full pl-9 pr-4 py-2 bg-slate-950 text-white placeholder-slate-500 rounded-xl border border-slate-700 text-xs focus:outline-hidden focus:border-blue-500"
          />
        </div>

        {/* Filter Dropdowns */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2 bg-slate-950 text-slate-200 rounded-xl border border-slate-700 text-xs font-medium focus:outline-hidden"
          >
            <option value="all">All Alert Types</option>
            <option value="overspeed">Overspeed</option>
            <option value="geofence_breach">Geofence Breach</option>
            <option value="ignition_unauthorized">Ignition Unauthorized</option>
            <option value="offline">Vehicle Offline</option>
            <option value="battery_low">Battery Critical</option>
            <option value="harsh_braking">Harsh Braking</option>
          </select>

          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="px-3 py-2 bg-slate-950 text-slate-200 rounded-xl border border-slate-700 text-xs font-medium focus:outline-hidden"
          >
            <option value="all">All Severities</option>
            <option value="critical">Critical</option>
            <option value="warning">Warning</option>
            <option value="info">Info</option>
          </select>
        </div>
      </div>

      {/* Alert Feed Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Severity / Type</th>
                <th className="py-3 px-4">Vehicle / Unit</th>
                <th className="py-3 px-4">Incident Details</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4">Time Logged</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredAlerts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500 text-xs">
                    No alert incidents found matching the filter criteria.
                  </td>
                </tr>
              ) : (
                filteredAlerts.map((alert) => {
                  const targetVeh = vehicles.find((v) => v.id === alert.vehicleId);
                  return (
                    <tr
                      key={alert.id}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        !alert.acknowledged ? 'bg-slate-800/20' : ''
                      }`}
                    >
                      {/* Severity / Icon */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-lg bg-slate-800 border border-slate-700">
                            {getAlertIcon(alert.type)}
                          </div>
                          <Badge status={alert.severity} variant="severity" />
                        </div>
                      </td>

                      {/* Vehicle */}
                      <td className="py-3.5 px-4">
                        <p className="font-bold text-white tracking-tight">{alert.vehicleName}</p>
                        <span className="text-[10px] font-mono text-blue-400 font-semibold">
                          {alert.plateNumber}
                        </span>
                      </td>

                      {/* Title & Description */}
                      <td className="py-3.5 px-4 max-w-sm">
                        <p className="font-semibold text-slate-100">{alert.title}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{alert.description}</p>
                        {alert.resolutionNotes && (
                          <p className="text-[10px] text-emerald-400 mt-1 italic">
                            Resolution: {alert.resolutionNotes}
                          </p>
                        )}
                      </td>

                      {/* Location */}
                      <td className="py-3.5 px-4 text-slate-400 max-w-xs truncate">
                        <span className="flex items-center gap-1 truncate" title={alert.address}>
                          <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                          <span className="truncate">{alert.address}</span>
                        </span>
                      </td>

                      {/* Time */}
                      <td className="py-3.5 px-4 font-mono text-slate-400 whitespace-nowrap">
                        <span className="block text-slate-200">
                          {new Date(alert.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        <span className="text-[10px] text-slate-500">
                          {new Date(alert.timestamp).toLocaleDateString()}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        {alert.acknowledged ? (
                          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Acknowledged</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] text-rose-400 font-semibold animate-pulse">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>Active / Pending</span>
                          </span>
                        )}
                      </td>

                      {/* Action */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {targetVeh && (
                            <button
                              type="button"
                              onClick={() => {
                                flyToVehicle(targetVeh);
                                onNavigateMap(targetVeh.id);
                              }}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white transition-colors"
                              title="Locate Vehicle on Map"
                            >
                              <Navigation className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {!alert.acknowledged ? (
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedAlert(alert);
                                setNotes('');
                              }}
                              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-sm"
                            >
                              Review & Acknowledge
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedAlert(alert);
                                setNotes(alert.resolutionNotes || '');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white text-xs transition-colors"
                            >
                              Audit Log
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Acknowledge Incident Modal */}
      <Modal
        isOpen={Boolean(selectedAlert)}
        onClose={() => setSelectedAlert(null)}
        title={selectedAlert?.acknowledged ? 'Incident Audit Trail' : 'Acknowledge Fleet Incident'}
        subtitle={selectedAlert ? `${selectedAlert.vehicleName} (${selectedAlert.plateNumber})` : ''}
        maxWidth="md"
      >
        {selectedAlert && (
          <form onSubmit={handleAcknowledgeSubmit} className="space-y-4 text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <p className="font-bold text-white text-sm">{selectedAlert.title}</p>
              <p className="text-slate-400">{selectedAlert.description}</p>
              <p className="text-[11px] text-slate-500 font-mono pt-1">
                Triggered at: {new Date(selectedAlert.timestamp).toLocaleString()}
              </p>
            </div>

            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1.5">
                Dispatch Resolution Notes & Action Taken
              </label>
              <textarea
                rows={3}
                required={!selectedAlert.acknowledged}
                disabled={selectedAlert.acknowledged}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Contacted driver, advised on maximum corridor speed limit, notified operations supervisor."
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500 disabled:opacity-60"
              />
            </div>

            {selectedAlert.acknowledged && (
              <div className="text-[11px] text-emerald-400 font-mono">
                Acknowledged by {selectedAlert.acknowledgedBy} at{' '}
                {new Date(selectedAlert.acknowledgedAt || '').toLocaleString()}
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedAlert(null)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-semibold"
              >
                Close
              </button>
              {!selectedAlert.acknowledged && (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : 'Confirm Acknowledgement'}
                </button>
              )}
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};
