import React, { useState, useMemo } from 'react';
import { useFleet } from '../context/FleetContext';
import { LiveFleetMap } from '../components/map/LiveFleetMap';
import { VehicleDetailDrawer } from '../components/telemetry/VehicleDetailDrawer';
import { Badge } from '../components/common/Badge';
import { Vehicle } from '../types';
import {
  Search,
  SlidersHorizontal,
  Navigation,
  Gauge,
  Fuel,
  User,
  PanelLeftClose,
  PanelLeftOpen,
  MapPin,
  RefreshCw,
} from 'lucide-react';
import { NavPage } from '../components/layout/Sidebar';

interface LiveMapPageProps {
  onNavigateHistory: (vehicleId: string) => void;
}

export const LiveMapPage: React.FC<LiveMapPageProps> = ({ onNavigateHistory }) => {
  const {
    vehicles,
    selectedVehicle,
    setSelectedVehicle,
    geofences,
    activeFilter,
    setActiveFilter,
    searchQuery,
    setSearchQuery,
    mapCenterTarget,
    flyToVehicle,
  } = useFleet();

  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Filter vehicles based on active tab and search query
  const filteredVehicles = useMemo(() => {
    return vehicles.filter((v) => {
      const matchesFilter =
        activeFilter === 'all'
          ? true
          : activeFilter === 'moving'
          ? v.status === 'moving'
          : activeFilter === 'idle'
          ? v.status === 'idle'
          : activeFilter === 'stopped'
          ? v.status === 'stopped'
          : activeFilter === 'offline'
          ? v.status === 'offline'
          : activeFilter === 'alert'
          ? v.status === 'alert'
          : true;

      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        v.name.toLowerCase().includes(q) ||
        v.plateNumber.toLowerCase().includes(q) ||
        v.driverName.toLowerCase().includes(q) ||
        v.imei.toLowerCase().includes(q) ||
        v.group.toLowerCase().includes(q) ||
        v.telemetry.address.toLowerCase().includes(q);

      return matchesFilter && matchesSearch;
    });
  }, [vehicles, activeFilter, searchQuery]);

  const filterTabs = [
    { id: 'all', label: 'All', count: vehicles.length },
    { id: 'moving', label: 'Moving', count: vehicles.filter((v) => v.status === 'moving').length },
    { id: 'idle', label: 'Idle', count: vehicles.filter((v) => v.status === 'idle').length },
    { id: 'stopped', label: 'Stopped', count: vehicles.filter((v) => v.status === 'stopped').length },
    { id: 'offline', label: 'Offline', count: vehicles.filter((v) => v.status === 'offline').length },
  ];

  return (
    <div className="relative flex h-[calc(100vh-4rem)] w-full overflow-hidden bg-slate-950">
      {/* Left Vehicle Panel */}
      <aside
        className={`absolute lg:relative z-20 flex flex-col h-full bg-slate-900 border-r border-slate-800 transition-all duration-300 ${
          sidebarOpen ? 'w-80 sm:w-96 translate-x-0' : '-translate-x-full lg:w-0 lg:overflow-hidden'
        }`}
      >
        {/* Panel Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/40 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Navigation className="w-4 h-4 text-blue-400" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">Fleet Units</h2>
              <span className="text-xs bg-slate-800 text-slate-300 font-mono px-2 py-0.5 rounded-full border border-slate-700">
                {filteredVehicles.length} of {vehicles.length}
              </span>
            </div>

            <button
              type="button"
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white"
            >
              <PanelLeftClose className="w-4 h-4" />
            </button>
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by plate, driver, group..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-950 text-slate-100 placeholder-slate-500 rounded-xl border border-slate-700/80 focus:outline-hidden focus:border-blue-500"
            />
          </div>

          {/* Filter Status Tabs */}
          <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveFilter(tab.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  activeFilter === tab.id
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-1 rounded-full ${
                    activeFilter === tab.id ? 'bg-white/20' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Vehicle List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 p-2 space-y-1.5">
          {filteredVehicles.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              No fleet vehicles matched the filter criteria.
            </div>
          ) : (
            filteredVehicles.map((vehicle) => {
              const isSelected = selectedVehicle?.id === vehicle.id;
              return (
                <div
                  key={vehicle.id}
                  onClick={() => flyToVehicle(vehicle)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600/15 border-blue-500/50 shadow-md ring-1 ring-blue-500/30'
                      : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-800/60 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div>
                      <h3 className="text-xs font-bold text-white tracking-tight">{vehicle.name}</h3>
                      <p className="text-[11px] font-mono text-blue-400 font-semibold">{vehicle.plateNumber}</p>
                    </div>
                    <Badge status={vehicle.status} />
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 my-2">
                    <span className="flex items-center gap-1">
                      <Gauge className="w-3 h-3 text-slate-500" />
                      <strong className="text-slate-200 font-mono">{vehicle.telemetry.speed} km/h</strong>
                    </span>
                    <span className="flex items-center gap-1">
                      <Fuel className="w-3 h-3 text-slate-500" />
                      <strong className="text-slate-200 font-mono">{vehicle.telemetry.fuelLevel}%</strong>
                    </span>
                  </div>

                  <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/60">
                    <span className="flex items-center gap-1 truncate max-w-[140px]">
                      <User className="w-3 h-3 text-slate-500" />
                      <span className="truncate">{vehicle.driverName}</span>
                    </span>
                    <span className="font-mono text-slate-500">
                      {new Date(vehicle.telemetry.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </aside>

      {/* Main Map Viewport */}
      <main className="relative flex-1 h-full w-full">
        {/* Toggle sidebar button when collapsed */}
        {!sidebarOpen && (
          <button
            type="button"
            onClick={() => setSidebarOpen(true)}
            className="absolute top-4 left-4 z-20 p-2.5 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-700/80 text-white shadow-xl hover:bg-slate-800 transition-all cursor-pointer"
            title="Open Vehicle List"
          >
            <PanelLeftOpen className="w-4 h-4" />
          </button>
        )}

        <LiveFleetMap
          vehicles={vehicles}
          selectedVehicle={selectedVehicle}
          onSelectVehicle={(v) => flyToVehicle(v)}
          geofences={geofences}
          centerTarget={mapCenterTarget}
        />

        {/* Right Sliding Telemetry Drawer */}
        {selectedVehicle && (
          <div className="absolute top-0 right-0 bottom-0 z-30 w-full sm:w-96 max-w-full">
            <VehicleDetailDrawer
              vehicle={selectedVehicle}
              onClose={() => setSelectedVehicle(null)}
              onNavigateHistory={onNavigateHistory}
            />
          </div>
        )}
      </main>
    </div>
  );
};
