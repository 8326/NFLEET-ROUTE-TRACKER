import React, { useState, useMemo } from 'react';
import { useFleet } from '../context/FleetContext';
import { Badge } from '../components/common/Badge';
import { Modal } from '../components/common/Modal';
import { Vehicle, VehicleStatus } from '../types';
import {
  LayoutGrid,
  List,
  Search,
  Plus,
  Download,
  Upload,
  Filter,
  ArrowUpDown,
  Truck,
  Gauge,
  Zap,
  MapPin,
  Clock,
  User,
  Power,
  History,
  Navigation,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';
import { NavPage } from '../components/layout/Sidebar';

interface VehiclesPageProps {
  onNavigateMap: (vehicleId: string) => void;
  onNavigateHistory: (vehicleId: string) => void;
}

export const VehiclesPage: React.FC<VehiclesPageProps> = ({
  onNavigateMap,
  onNavigateHistory,
}) => {
  const { vehicles, addVehicle, toggleRemoteCutoff, flyToVehicle } = useFleet();

  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [search, setSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [groupFilter, setGroupFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'plate' | 'speed' | 'status'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Add Vehicle Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);
  const [isExportSuccess, setIsExportSuccess] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    plateNumber: '',
    imei: '',
    simNumber: '',
    deviceModel: 'Teltonika FMB920 (4G Cat-M1)',
    vin: '',
    driverName: '',
    driverPhone: '',
    group: 'Metro Delivery',
    speedLimit: 85,
  });

  const uniqueGroups = useMemo(() => {
    return Array.from(new Set(vehicles.map((v) => v.group)));
  }, [vehicles]);

  const filteredVehicles = useMemo(() => {
    return vehicles
      .filter((v) => {
        const matchesStatus = statusFilter === 'all' || v.status === statusFilter;
        const matchesGroup = groupFilter === 'all' || v.group === groupFilter;
        const q = search.toLowerCase().trim();
        const matchesSearch =
          !q ||
          v.name.toLowerCase().includes(q) ||
          v.plateNumber.toLowerCase().includes(q) ||
          v.imei.toLowerCase().includes(q) ||
          v.driverName.toLowerCase().includes(q) ||
          v.telemetry.address.toLowerCase().includes(q);

        return matchesStatus && matchesGroup && matchesSearch;
      })
      .sort((a, b) => {
        let valA = a[sortBy];
        let valB = b[sortBy];
        if (sortBy === 'speed') {
          valA = a.telemetry.speed;
          valB = b.telemetry.speed;
        }
        if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
  }, [vehicles, statusFilter, groupFilter, search, sortBy, sortOrder]);

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.plateNumber || !formData.imei) return;

    await addVehicle(formData);
    setIsAddModalOpen(false);
    setFormData({
      name: '',
      plateNumber: '',
      imei: '',
      simNumber: '',
      deviceModel: 'Teltonika FMB920 (4G Cat-M1)',
      vin: '',
      driverName: '',
      driverPhone: '',
      group: 'Metro Delivery',
      speedLimit: 85,
    });
  };

  const handleExportCSV = () => {
    const headers = [
      'Vehicle ID',
      'Name',
      'Plate Number',
      'IMEI',
      'Status',
      'Driver',
      'Speed (km/h)',
      'Ignition',
      'Fuel (%)',
      'Battery (V)',
      'Odometer (km)',
      'Group',
      'Address',
      'Last Timestamp',
    ];

    const rows = vehicles.map((v) => [
      v.id,
      `"${v.name}"`,
      v.plateNumber,
      v.imei,
      v.status,
      `"${v.driverName}"`,
      v.telemetry.speed,
      v.telemetry.ignition ? 'ON' : 'OFF',
      v.telemetry.fuelLevel,
      v.telemetry.batteryVoltage,
      v.telemetry.odometer,
      `"${v.group}"`,
      `"${v.telemetry.address.replace(/"/g, '""')}"`,
      v.telemetry.timestamp,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `NFLEET_Telematics_Export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setIsExportSuccess(true);
    setTimeout(() => setIsExportSuccess(false), 3000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Page Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Vehicle Fleet Inventory</span>
            <span className="text-xs bg-slate-800 text-slate-300 font-mono px-2.5 py-1 rounded-full border border-slate-700">
              {vehicles.length} Units Enrolled
            </span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Configure vehicle hardware modems, assigned drivers, groups, and telematics health.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Export CSV */}
          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors"
          >
            {isExportSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Download className="w-4 h-4" />}
            <span>{isExportSuccess ? 'Exported CSV' : 'Export CSV'}</span>
          </button>

          {/* Bulk Import */}
          <button
            type="button"
            onClick={() => setIsBulkModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors"
          >
            <Upload className="w-4 h-4" />
            <span>Bulk Import</span>
          </button>

          {/* Add Vehicle Button */}
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Register Vehicle</span>
          </button>
        </div>
      </div>

      {/* Filter & Toolbar Row */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by plate, vehicle name, IMEI, driver, address..."
            className="w-full pl-9 pr-4 py-2 bg-slate-950 text-white placeholder-slate-500 rounded-xl border border-slate-700 text-xs focus:outline-hidden focus:border-blue-500"
          />
        </div>

        {/* Filter Dropdowns & View Toggle */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-950 text-slate-200 rounded-xl border border-slate-700 text-xs font-medium focus:outline-hidden"
          >
            <option value="all">All Statuses</option>
            <option value="moving">Moving</option>
            <option value="idle">Idle</option>
            <option value="stopped">Stopped</option>
            <option value="offline">Offline</option>
            <option value="alert">Alert</option>
          </select>

          {/* Group Filter */}
          <select
            value={groupFilter}
            onChange={(e) => setGroupFilter(e.target.value)}
            className="px-3 py-2 bg-slate-950 text-slate-200 rounded-xl border border-slate-700 text-xs font-medium focus:outline-hidden"
          >
            <option value="all">All Fleet Groups</option>
            {uniqueGroups.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>

          {/* View Mode Toggle */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'table' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
              title="Table View"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content: Table or Grid */}
      {viewMode === 'table' ? (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Vehicle / Model</th>
                  <th className="py-3 px-4">Plate / IMEI</th>
                  <th className="py-3 px-4">Driver</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Speed / Ignition</th>
                  <th className="py-3 px-4">Current Location</th>
                  <th className="py-3 px-4">Last Ping</th>
                  <th className="py-3 px-4 text-right">Commands</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredVehicles.map((v) => (
                  <tr key={v.id} className="hover:bg-slate-800/40 transition-colors">
                    {/* Name & Group */}
                    <td className="py-3 px-4">
                      <p className="font-bold text-white tracking-tight">{v.name}</p>
                      <span className="text-[10px] text-slate-500 font-mono">{v.group}</span>
                    </td>

                    {/* Plate & IMEI */}
                    <td className="py-3 px-4 font-mono">
                      <span className="text-blue-400 font-bold block">{v.plateNumber}</span>
                      <span className="text-[10px] text-slate-500">IMEI: {v.imei}</span>
                    </td>

                    {/* Driver */}
                    <td className="py-3 px-4">
                      <p className="font-semibold text-slate-200">{v.driverName}</p>
                      <p className="text-[10px] text-slate-500">{v.driverPhone}</p>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4">
                      <Badge status={v.status} />
                    </td>

                    {/* Speed & Ignition */}
                    <td className="py-3 px-4 font-mono">
                      <span className="font-bold text-white block">{v.telemetry.speed} km/h</span>
                      <span
                        className={`text-[10px] font-semibold ${
                          v.telemetry.ignition ? 'text-emerald-400' : 'text-slate-500'
                        }`}
                      >
                        {v.telemetry.ignition ? 'IGN ON' : 'IGN OFF'}
                      </span>
                    </td>

                    {/* Address */}
                    <td className="py-3 px-4 max-w-xs truncate">
                      <span className="truncate block" title={v.telemetry.address}>
                        {v.telemetry.address}
                      </span>
                    </td>

                    {/* Last Ping */}
                    <td className="py-3 px-4 font-mono text-slate-400">
                      {new Date(v.telemetry.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            flyToVehicle(v);
                            onNavigateMap(v.id);
                          }}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white transition-colors"
                          title="Locate on Live Map"
                        >
                          <Navigation className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onNavigateHistory(v.id)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-indigo-600 text-slate-300 hover:text-white transition-colors"
                          title="View Historical Route"
                        >
                          <History className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => toggleRemoteCutoff(v.id)}
                          className={`p-1.5 rounded-lg transition-colors ${
                            v.telemetry.relayCutoff
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : 'bg-slate-800 hover:bg-rose-600/30 text-slate-300 hover:text-rose-300'
                          }`}
                          title="Toggle Remote Immobilizer Relay"
                        >
                          <Power className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Grid View */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVehicles.map((v) => (
            <div
              key={v.id}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h3 className="text-sm font-bold text-white tracking-tight">{v.name}</h3>
                    <p className="text-xs font-mono font-semibold text-blue-400">{v.plateNumber}</p>
                  </div>
                  <Badge status={v.status} />
                </div>

                <p className="text-[11px] text-slate-500 font-mono mb-3">Group: {v.group}</p>

                {/* Telemetry Row */}
                <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Speed</span>
                    <strong className="text-white font-mono">{v.telemetry.speed} km/h</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Fuel</span>
                    <strong className="text-amber-300 font-mono">{v.telemetry.fuelLevel}%</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Ignition</span>
                    <strong className={v.telemetry.ignition ? 'text-emerald-400' : 'text-slate-500'}>
                      {v.telemetry.ignition ? 'ON' : 'OFF'}
                    </strong>
                  </div>
                </div>

                <div className="mt-3 text-xs text-slate-400 space-y-1">
                  <p className="flex items-center gap-1.5 truncate">
                    <User className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span>{v.driverName} ({v.driverPhone})</span>
                  </p>
                  <p className="flex items-center gap-1.5 truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span className="truncate">{v.telemetry.address}</span>
                  </p>
                </div>
              </div>

              {/* Grid Card Footer Actions */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    flyToVehicle(v);
                    onNavigateMap(v.id);
                  }}
                  className="flex-1 py-1.5 px-3 rounded-xl bg-blue-600/15 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/30 text-xs font-semibold transition-all flex items-center justify-center gap-1.5"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Locate</span>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigateHistory(v.id)}
                  className="flex-1 py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all flex items-center justify-center gap-1.5"
                >
                  <History className="w-3.5 h-3.5" />
                  <span>History</span>
                </button>

                <button
                  type="button"
                  onClick={() => toggleRemoteCutoff(v.id)}
                  className={`p-2 rounded-xl transition-colors ${
                    v.telemetry.relayCutoff
                      ? 'bg-rose-500 text-white'
                      : 'bg-slate-800 hover:bg-rose-500/20 text-slate-300 hover:text-rose-400'
                  }`}
                  title="Remote Relay"
                >
                  <Power className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Vehicle Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Register New Fleet Vehicle"
        subtitle="Provision GNSS tracker hardware modem and assign initial fleet dispatch parameters"
        maxWidth="lg"
      >
        <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Vehicle Name / Unit</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Ford Transit Delivery 09"
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">License Plate</label>
              <input
                type="text"
                required
                value={formData.plateNumber}
                onChange={(e) => setFormData({ ...formData, plateNumber: e.target.value })}
                placeholder="e.g. NF-8821-CA"
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500 uppercase font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Tracker IMEI (15 Digits)</label>
              <input
                type="text"
                required
                value={formData.imei}
                onChange={(e) => setFormData({ ...formData, imei: e.target.value })}
                placeholder="860124982740192"
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">SIM MSISDN</label>
              <input
                type="text"
                value={formData.simNumber}
                onChange={(e) => setFormData({ ...formData, simNumber: e.target.value })}
                placeholder="+1 (415) 555-0199"
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Assigned Driver Name</label>
              <input
                type="text"
                value={formData.driverName}
                onChange={(e) => setFormData({ ...formData, driverName: e.target.value })}
                placeholder="e.g. Jason Vance"
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Fleet Group</label>
              <select
                value={formData.group}
                onChange={(e) => setFormData({ ...formData, group: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
              >
                <option value="Metro Delivery">Metro Delivery</option>
                <option value="Long Haul Freight">Long Haul Freight</option>
                <option value="Refrigerated Pharma">Refrigerated Pharma</option>
                <option value="Field Service">Field Service</option>
                <option value="Heavy Equipment">Heavy Equipment</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md"
            >
              Enroll Vehicle
            </button>
          </div>
        </form>
      </Modal>

      {/* Bulk Import Modal */}
      <Modal
        isOpen={isBulkModalOpen}
        onClose={() => setIsBulkModalOpen(false)}
        title="Bulk Import Fleet Roster"
        subtitle="Upload CSV file with vehicle specifications and tracker IMEI numbers"
        maxWidth="md"
      >
        <div className="space-y-4 text-xs">
          <div className="p-8 border-2 border-dashed border-slate-700 rounded-2xl flex flex-col items-center justify-center text-center space-y-2 hover:border-blue-500 transition-colors bg-slate-950/40 cursor-pointer">
            <FileSpreadsheet className="w-8 h-8 text-blue-400" />
            <p className="font-bold text-white">Drag & drop CSV fleet spreadsheet</p>
            <p className="text-slate-400 text-[11px]">or click to browse your local files</p>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 font-mono">
            Format: name, plate, imei, driver, group, speedLimit
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsBulkModalOpen(false)}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-semibold"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => {
                alert('Simulated CSV bulk batch imported: 12 vehicles enrolled successfully.');
                setIsBulkModalOpen(false);
              }}
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md"
            >
              Process Batch Import
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
