import React, { useState } from 'react';
import { useFleet } from '../context/FleetContext';
import {
  BarChart3,
  Calendar,
  Download,
  Filter,
  Truck,
  FileSpreadsheet,
  FileText,
  Clock,
  Gauge,
  MapPin,
  Flame,
  CheckCircle2,
} from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const { vehicles, alerts, stats } = useFleet();

  const [reportType, setReportType] = useState<
    'distance' | 'trips' | 'speed' | 'activity' | 'alerts'
  >('distance');
  const [dateRange, setDateRange] = useState<string>('7d');
  const [selectedVehicle, setSelectedVehicle] = useState<string>('all');
  const [isExporting, setIsExporting] = useState<string | null>(null);

  const reportTabs = [
    { id: 'distance', label: 'Distance & Mileage', icon: MapPin },
    { id: 'trips', label: 'Trip & Stop Audit', icon: Clock },
    { id: 'speed', label: 'Speed & Safety Analysis', icon: Gauge },
    { id: 'activity', label: 'Vehicle Activity & Idle', icon: BarChart3 },
    { id: 'alerts', label: 'Incident & Alert Logs', icon: Flame },
  ];

  const handleDownload = (format: 'csv' | 'pdf' | 'excel') => {
    setIsExporting(format);
    setTimeout(() => {
      // Simulate real download trigger
      const element = document.createElement('a');
      const file = new Blob([`NFLEET ${reportType.toUpperCase()} REPORT\nGenerated: ${new Date().toISOString()}\nTotal Units: ${vehicles.length}`], {
        type: 'text/plain',
      });
      element.href = URL.createObjectURL(file);
      element.download = `NFLEET_Report_${reportType}_${new Date().toISOString().split('T')[0]}.${format === 'excel' ? 'xlsx' : format}`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      setIsExporting(null);
    }, 800);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Telematics Reports & Analytics</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Automated fleet reporting for fuel efficiency, driver safety scoring, and trip audits.
          </p>
        </div>

        {/* Download Buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={Boolean(isExporting)}
            onClick={() => handleDownload('csv')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors disabled:opacity-50"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>{isExporting === 'csv' ? 'Generating...' : 'Export CSV'}</span>
          </button>

          <button
            type="button"
            disabled={Boolean(isExporting)}
            onClick={() => handleDownload('pdf')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition-all cursor-pointer disabled:opacity-50"
          >
            <FileText className="w-4 h-4" />
            <span>{isExporting === 'pdf' ? 'Compiling PDF...' : 'Download PDF Audit'}</span>
          </button>
        </div>
      </div>

      {/* Filter / Selector Row */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex flex-wrap items-center justify-between gap-3">
        {/* Report Category Tabs */}
        <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
          {reportTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = reportType === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setReportType(tab.id as any)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/25'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Date Range & Vehicle Filters */}
        <div className="flex items-center gap-2">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-3 py-2 bg-slate-950 text-slate-200 rounded-xl border border-slate-700 text-xs font-medium focus:outline-hidden"
          >
            <option value="today">Today (Live 24h)</option>
            <option value="7d">Past 7 Days</option>
            <option value="30d">Past 30 Days</option>
            <option value="quarter">This Quarter</option>
          </select>

          <select
            value={selectedVehicle}
            onChange={(e) => setSelectedVehicle(e.target.value)}
            className="px-3 py-2 bg-slate-950 text-slate-200 rounded-xl border border-slate-700 text-xs font-medium focus:outline-hidden"
          >
            <option value="all">Entire Fleet (All Units)</option>
            {vehicles.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} ({v.plateNumber})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Summary KPI Highlights for Report */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <span className="text-[10px] uppercase font-semibold text-slate-400 block">Report Total Mileage</span>
          <p className="text-2xl font-extrabold text-white font-mono mt-1">
            {(stats.totalDistanceTodayKm * (dateRange === '7d' ? 6.2 : dateRange === '30d' ? 24.8 : 1)).toFixed(0)}{' '}
            <span className="text-xs font-normal text-slate-400">km</span>
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <span className="text-[10px] uppercase font-semibold text-slate-400 block">Total Fuel Burned</span>
          <p className="text-2xl font-extrabold text-amber-300 font-mono mt-1">
            {(stats.totalDistanceTodayKm * 0.28 * (dateRange === '7d' ? 6.2 : 1)).toFixed(1)}{' '}
            <span className="text-xs font-normal text-slate-400">Liters</span>
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <span className="text-[10px] uppercase font-semibold text-slate-400 block">Fleet Active Hours</span>
          <p className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">
            {dateRange === '7d' ? '312.4' : '48.5'} <span className="text-xs font-normal text-slate-400">hours</span>
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
          <span className="text-[10px] uppercase font-semibold text-slate-400 block">Logged Infractions</span>
          <p className="text-2xl font-extrabold text-rose-400 font-mono mt-1">
            {alerts.length * (dateRange === '7d' ? 4 : 1)}{' '}
            <span className="text-xs font-normal text-slate-400">events</span>
          </p>
        </div>
      </div>

      {/* Visual Activity Breakdown Graphic (Bar Distribution) */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center justify-between">
          <span>Weekly Mileage & Operating Load Trend</span>
          <span className="text-xs font-normal text-slate-400 font-mono">Metric: Distance in km per day</span>
        </h2>

        <div className="grid grid-cols-7 gap-2 items-end h-44 pt-6 pb-2 px-2 border-b border-slate-800">
          {[
            { day: 'Mon', dist: 420, active: 8 },
            { day: 'Tue', dist: 580, active: 9 },
            { day: 'Wed', dist: 510, active: 8 },
            { day: 'Thu', dist: 640, active: 10 },
            { day: 'Fri', dist: 710, active: 11 },
            { day: 'Sat', dist: 380, active: 5 },
            { day: 'Sun', dist: 240, active: 3 },
          ].map((bar) => {
            const heightPercent = Math.round((bar.dist / 750) * 100);
            return (
              <div key={bar.day} className="flex flex-col items-center gap-2 h-full justify-end group">
                <span className="text-[10px] font-mono text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  {bar.dist}k
                </span>
                <div
                  className="w-full max-w-[48px] rounded-t-lg bg-gradient-to-t from-blue-600 to-indigo-500 group-hover:from-blue-500 group-hover:to-indigo-400 transition-all"
                  style={{ height: `${heightPercent}%` }}
                />
                <span className="text-[11px] font-semibold text-slate-400">{bar.day}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Report Data Table */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            Detailed Unit Record Breakdown ({vehicles.length} Units Analyzed)
          </h3>
          <span className="text-xs text-slate-400 font-mono">Date Window: {dateRange}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 uppercase font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Vehicle Unit</th>
                <th className="py-3 px-4">Driver</th>
                <th className="py-3 px-4">Distance Logged</th>
                <th className="py-3 px-4">Est. Fuel Burn</th>
                <th className="py-3 px-4">Average Speed</th>
                <th className="py-3 px-4">Max Speed</th>
                <th className="py-3 px-4">Safety Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {vehicles.map((v, i) => {
                const estDistance = 140 + (i * 45) + (v.telemetry.odometer % 90);
                const estFuel = (estDistance * 0.26).toFixed(1);
                const score = 98 - (i * 3);
                return (
                  <tr key={v.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <p className="font-bold text-white">{v.name}</p>
                      <span className="text-[10px] font-mono text-blue-400">{v.plateNumber}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-200">{v.driverName}</td>
                    <td className="py-3 px-4 font-mono font-bold text-white">{estDistance} km</td>
                    <td className="py-3 px-4 font-mono text-amber-300">{estFuel} L</td>
                    <td className="py-3 px-4 font-mono text-slate-300">
                      {Math.max(35, v.telemetry.speed - 10)} km/h
                    </td>
                    <td className="py-3 px-4 font-mono text-rose-400 font-semibold">
                      {v.speedLimit} km/h
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-md font-mono font-bold text-xs ${
                          score > 90
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {score} / 100
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
