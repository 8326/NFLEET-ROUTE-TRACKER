import React, { useState } from 'react';
import { useFleet } from '../context/FleetContext';
import { DeviceTracker } from '../types';
import { Modal } from '../components/common/Modal';
import { Radio, Plus, Wifi, BatteryCharging, CheckCircle2, Cpu, Smartphone, Signal } from 'lucide-react';

export const DevicesPage: React.FC = () => {
  const { devices, addDevice } = useFleet();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [imei, setImei] = useState('');
  const [model, setModel] = useState('Teltonika FMB920');
  const [protocol, setProtocol] = useState('Teltonika Codec 8 / TCP');
  const [simIccid, setSimIccid] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newDev: DeviceTracker = {
      id: `dev-${Date.now().toString(36)}`,
      imei,
      model,
      protocol,
      simIccid,
      status: 'online',
      gsmSignalPercent: 92,
      backupBatteryVoltage: 4.15,
      lastPingTimestamp: new Date().toISOString(),
      firmwareVersion: 'v03.28.02.Rev.14',
    };
    addDevice(newDev);
    setIsAddModalOpen(false);
    setImei('');
    setSimIccid('');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Hardware GPS Tracker Inventory</span>
            <span className="text-xs bg-slate-800 text-slate-300 font-mono px-2.5 py-1 rounded-full border border-slate-700">
              {devices.length} Devices Provisioned
            </span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Modem telemetry diagnostics, SIM ICCIDs, cellular signal strength, and firmware versions.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Provision Tracker</span>
        </button>
      </div>

      {/* Devices Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {devices.map((device) => (
          <div
            key={device.id}
            className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4 hover:border-slate-700 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold">
                    <Radio className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white tracking-tight">{device.model}</h3>
                    <p className="text-[11px] font-mono text-slate-400">IMEI: {device.imei}</p>
                  </div>
                </div>

                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    device.status === 'online'
                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {device.status}
                </span>
              </div>

              {/* Hardware diagnostics */}
              <div className="grid grid-cols-2 gap-2 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs mb-3">
                <div>
                  <span className="text-[10px] text-slate-500 block flex items-center gap-1">
                    <Signal className="w-3 h-3 text-emerald-400" /> GSM Cellular
                  </span>
                  <strong className="text-white font-mono">{device.gsmSignalPercent}% Signal</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block flex items-center gap-1">
                    <BatteryCharging className="w-3 h-3 text-emerald-400" /> Internal LiPo
                  </span>
                  <strong className="text-white font-mono">{device.backupBatteryVoltage}V Backup</strong>
                </div>
              </div>

              <div className="space-y-1 text-xs text-slate-400 font-mono text-[11px]">
                <p className="flex justify-between">
                  <span className="text-slate-500">Protocol:</span>
                  <span className="text-slate-300">{device.protocol}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-slate-500">SIM ICCID:</span>
                  <span className="text-slate-300">{device.simIccid}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-slate-500">Firmware:</span>
                  <span className="text-slate-300">{device.firmwareVersion}</span>
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-500 font-mono text-[10px]">
              <span>Last Heartbeat:</span>
              <span>{new Date(device.lastPingTimestamp).toLocaleTimeString()}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Provision Tracker Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Provision Hardware Tracker Modem"
        subtitle="Register IMEI serial and configure network cellular APN parameters"
        maxWidth="md"
      >
        <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">Tracker IMEI (15 Digits)</label>
            <input
              type="text"
              required
              value={imei}
              onChange={(e) => setImei(e.target.value)}
              placeholder="869014029481023"
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">Hardware Brand & Model</label>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
            >
              <option value="Teltonika FMB920">Teltonika FMB920 (Bluetooth & 2G/4G Cat-M1)</option>
              <option value="Teltonika FMC130">Teltonika FMC130 (CAN-Bus Reader & 4G)</option>
              <option value="Queclink GV300W">Queclink GV300W (Wide Band 3G/4G)</option>
              <option value="Jimi IoT / Concox VL02">Jimi IoT VL02 (OBD-II Plug & Play)</option>
              <option value="Coban TK103">Coban TK103 / GPS103 (Standard TCP/IP)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">Telematics Parser Protocol</label>
            <select
              value={protocol}
              onChange={(e) => setProtocol(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
            >
              <option value="Teltonika Codec 8 / TCP">Teltonika Codec 8 / TCP</option>
              <option value="Teltonika Codec 8 Extended">Teltonika Codec 8 Extended (CAN-Bus)</option>
              <option value="Queclink @Track Protocol">Queclink @Track Protocol</option>
              <option value="JT808 / GT06 Binary">JT808 / GT06 Binary Protocol</option>
              <option value="Custom REST / JSON WebSocket">Custom REST / JSON WebSocket</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">M2M Cellular SIM ICCID</label>
            <input
              type="text"
              required
              value={simIccid}
              onChange={(e) => setSimIccid(e.target.value)}
              placeholder="8901410321111855019"
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500 font-mono"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md"
            >
              Authorize Tracker
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
