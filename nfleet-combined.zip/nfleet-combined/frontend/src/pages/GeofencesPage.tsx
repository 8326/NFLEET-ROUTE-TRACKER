import React, { useState } from 'react';
import { useFleet } from '../context/FleetContext';
import { GeofenceZone } from '../types';
import { Modal } from '../components/common/Modal';
import { LiveFleetMap } from '../components/map/LiveFleetMap';
import {
  ShieldAlert,
  Plus,
  MapPin,
  Clock,
  Gauge,
  CheckCircle2,
  Trash2,
  Navigation,
} from 'lucide-react';

export const GeofencesPage: React.FC = () => {
  const { geofences, addGeofence, vehicles } = useFleet();

  const [selectedZone, setSelectedZone] = useState<GeofenceZone>(geofences[0]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Create Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [radiusMeters, setRadiusMeters] = useState(600);
  const [color, setColor] = useState('#3B82F6');
  const [speedLimitKmH, setSpeedLimitKmH] = useState(40);
  const [lat, setLat] = useState(37.7749);
  const [lng, setLng] = useState(-122.4194);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newZone: GeofenceZone = {
      id: `geo-${Date.now().toString(36)}`,
      name,
      description,
      type: 'circle',
      color,
      radiusMeters,
      center: { lat: Number(lat), lng: Number(lng) },
      speedLimitKmH: Number(speedLimitKmH),
      alertOnEntry: true,
      alertOnExit: true,
      activeVehicleCount: 0,
    };
    addGeofence(newZone);
    setSelectedZone(newZone);
    setIsCreateModalOpen(false);
    setName('');
    setDescription('');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Geofence Boundary Security</span>
            <span className="text-xs bg-slate-800 text-slate-300 font-mono px-2.5 py-1 rounded-full border border-slate-700">
              {geofences.length} Perimeter Zones Active
            </span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Establish virtual boundary barriers for terminals, depots, customer staging sites, and restricted areas.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Define New Geofence</span>
        </button>
      </div>

      {/* Main Grid: Zones List (1 col) + Interactive Map (2 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Geofence List */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-xl space-y-3 flex flex-col h-[520px]">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-blue-400" />
            <span>Monitored Perimeter Zones</span>
          </h2>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {geofences.map((zone) => {
              const isSelected = selectedZone?.id === zone.id;
              return (
                <div
                  key={zone.id}
                  onClick={() => setSelectedZone(zone)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600/15 border-blue-500/50 shadow-md ring-1 ring-blue-500/30'
                      : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: zone.color }} />
                      <h3 className="text-xs font-bold text-white">{zone.name}</h3>
                    </div>
                    <span className="text-[10px] font-mono font-semibold uppercase px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                      {zone.type}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400 mb-2">{zone.description}</p>

                  <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 pt-2 border-t border-slate-800/60">
                    <span>Radius: <strong className="text-white font-mono">{zone.radiusMeters || 0}m</strong></span>
                    <span>Speed Cap: <strong className="text-white font-mono">{zone.speedLimitKmH || 40} km/h</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Map View of Geofences */}
        <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-xl flex flex-col h-[520px]">
          <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
            <span className="font-semibold text-white flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-400" />
              <span>Zone: {selectedZone?.name || 'All Zones'}</span>
            </span>
            <span className="font-mono">
              Center: {selectedZone?.center?.lat.toFixed(4)}, {selectedZone?.center?.lng.toFixed(4)}
            </span>
          </div>

          <div className="flex-1 w-full rounded-xl overflow-hidden">
            <LiveFleetMap
              vehicles={vehicles}
              selectedVehicle={null}
              onSelectVehicle={() => {}}
              geofences={geofences}
              centerTarget={selectedZone?.center}
            />
          </div>
        </div>
      </div>

      {/* Create Geofence Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Define New Geofence Perimeter"
        subtitle="Establish circular geographic containment trigger with entrance and exit alerts"
        maxWidth="lg"
      >
        <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">Zone Label Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. South Bay Distribution Hub"
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">Description / Purpose</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Primary cargo staging warehouse dock"
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Latitude</label>
              <input
                type="number"
                step="0.0001"
                required
                value={lat}
                onChange={(e) => setLat(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Longitude</label>
              <input
                type="number"
                step="0.0001"
                required
                value={lng}
                onChange={(e) => setLng(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Radius (Meters)</label>
              <input
                type="number"
                required
                value={radiusMeters}
                onChange={(e) => setRadiusMeters(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Speed Limit (km/h)</label>
              <input
                type="number"
                required
                value={speedLimitKmH}
                onChange={(e) => setSpeedLimitKmH(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Zone Border Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-9 h-9 rounded-lg bg-transparent border border-slate-700 cursor-pointer"
                />
                <span className="font-mono text-slate-300">{color}</span>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md"
            >
              Save Perimeter Zone
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
