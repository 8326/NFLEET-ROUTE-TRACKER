import React, { useState } from 'react';
import { useFleet } from '../context/FleetContext';
import { Driver } from '../types';
import { Modal } from '../components/common/Modal';
import { Users, Plus, Phone, Mail, Award, CheckCircle2, Truck, ShieldCheck } from 'lucide-react';

export const DriversPage: React.FC = () => {
  const { drivers, addDriver, vehicles } = useFleet();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [assignedVehicleId, setAssignedVehicleId] = useState(vehicles[0]?.id || '');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const assignedVeh = vehicles.find((v) => v.id === assignedVehicleId);
    const newDriver: Driver = {
      id: `drv-${Date.now().toString(36)}`,
      name,
      phone,
      email,
      licenseNumber,
      assignedVehicleId,
      assignedVehicleName: assignedVeh?.name || 'Unassigned Fleet Unit',
      safetyScore: 98,
      status: 'active',
      totalTrips: 1,
      totalHours: 8,
    };
    addDriver(newDriver);
    setIsAddModalOpen(false);
    setName('');
    setPhone('');
    setEmail('');
    setLicenseNumber('');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Drivers & Dispatch Personnel</span>
            <span className="text-xs bg-slate-800 text-slate-300 font-mono px-2.5 py-1 rounded-full border border-slate-700">
              {drivers.length} Certified Operators
            </span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Driver credentials, CDL commercial compliance, driving behavior scores, and duty hours.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Onboard Driver</span>
        </button>
      </div>

      {/* Drivers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {drivers.map((driver) => (
          <div
            key={driver.id}
            className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4 hover:border-slate-700 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold text-sm">
                    {driver.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white tracking-tight">{driver.name}</h3>
                    <p className="text-[11px] text-slate-400 font-mono">CDL: {driver.licenseNumber}</p>
                  </div>
                </div>

                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    driver.status === 'active'
                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {driver.status}
                </span>
              </div>

              {/* Stats Row */}
              <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs mb-3">
                <div>
                  <span className="text-[10px] text-slate-500 block">Safety Score</span>
                  <strong className="text-emerald-400 font-mono font-bold text-sm">
                    {driver.safetyScore} / 100
                  </strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Completed Trips</span>
                  <strong className="text-white font-mono font-bold text-sm">{driver.totalTrips}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Duty Hours</span>
                  <strong className="text-blue-400 font-mono font-bold text-sm">{driver.totalHours}h</strong>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-slate-400">
                <p className="flex items-center gap-2">
                  <Truck className="w-3.5 h-3.5 text-slate-500" />
                  <span className="truncate text-slate-200">{driver.assignedVehicleName}</span>
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-500" />
                  <a href={`tel:${driver.phone}`} className="hover:text-blue-400 font-mono">
                    {driver.phone}
                  </a>
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-500" />
                  <span className="truncate">{driver.email}</span>
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" /> CDL Verified
              </span>
              <button
                type="button"
                onClick={() => alert(`Showing detailed safety log for ${driver.name}`)}
                className="text-xs font-semibold text-blue-400 hover:text-blue-300"
              >
                Performance Report →
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Onboard Driver Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Onboard Fleet Driver"
        subtitle="Register driver license profile and assign to a tracked vehicle"
        maxWidth="md"
      >
        <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">Full Legal Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Rachel Adams"
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Phone Number</label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 (415) 555-0144"
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 uppercase font-semibold mb-1">Driver CDL License</label>
              <input
                type="text"
                required
                value={licenseNumber}
                onChange={(e) => setLicenseNumber(e.target.value)}
                placeholder="CDL-A992144"
                className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">Corporate Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="rachel.adams@fleet.com"
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 uppercase font-semibold mb-1">Assign to Vehicle</label>
            <select
              value={assignedVehicleId}
              onChange={(e) => setAssignedVehicleId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 focus:border-blue-500"
            >
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name} ({v.plateNumber})
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold shadow-md"
            >
              Complete Onboarding
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
