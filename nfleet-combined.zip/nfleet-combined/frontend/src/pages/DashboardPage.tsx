import React from 'react';
import { useFleet } from '../context/FleetContext';
import { Badge } from '../components/common/Badge';
import { LiveFleetMap } from '../components/map/LiveFleetMap';
import {
  Truck,
  Wifi,
  Navigation,
  PauseCircle,
  WifiOff,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  MapPin,
  Clock,
  ExternalLink,
  ShieldCheck,
  ChevronRight,
  Activity,
  PlusCircle,
  RotateCw,
} from 'lucide-react';
import { NavPage } from '../components/layout/Sidebar';

interface DashboardPageProps {
  onNavigate: (page: NavPage) => void;
  onSelectVehicle: (vehicleId: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate, onSelectVehicle }) => {
  const { vehicles, selectedVehicle, setSelectedVehicle, stats, alerts, geofences, isDemoMode, flyToVehicle } = useFleet();

  const unreadAlerts = alerts.filter((a) => !a.acknowledged);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner / Welcome Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Fleet Operations Command</span>
            {isDemoMode && (
              <span className="text-xs bg-amber-500/15 text-amber-300 font-semibold px-2.5 py-1 rounded-full border border-amber-500/30">
                Simulated Fleet Active
              </span>
            )}
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Real-time GNSS positioning, CAN diagnostics, and active dispatch telemetry.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => onNavigate('live-map')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition-all cursor-pointer"
          >
            <Navigation className="w-4 h-4" />
            <span>Open Full Live Map</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid (6 Metric Cards as specified) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Total Vehicles */}
        <div
          onClick={() => onNavigate('vehicles')}
          className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group shadow-md"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Units</span>
            <Truck className="w-4 h-4 text-blue-400 group-hover:scale-110 transition-transform" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-white font-mono">{stats.totalVehicles}</p>
          <span className="text-[10px] text-slate-400 mt-1 block">Registered in fleet</span>
        </div>

        {/* Online Vehicles */}
        <div
          onClick={() => onNavigate('vehicles')}
          className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group shadow-md"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Online</span>
            <Wifi className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono">{stats.onlineVehicles}</p>
          <span className="text-[10px] text-emerald-400/80 mt-1 block">Active beacon stream</span>
        </div>

        {/* Moving Vehicles */}
        <div
          onClick={() => onNavigate('live-map')}
          className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group shadow-md"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Moving</span>
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-white font-mono">{stats.movingVehicles}</p>
          <span className="text-[10px] text-slate-400 mt-1 block">Avg {stats.avgFleetSpeedKmH} km/h</span>
        </div>

        {/* Stopped / Idle Vehicles */}
        <div
          onClick={() => onNavigate('vehicles')}
          className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group shadow-md"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Stopped</span>
            <PauseCircle className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-amber-300 font-mono">
            {stats.stoppedVehicles + stats.idleVehicles}
          </p>
          <span className="text-[10px] text-slate-400 mt-1 block">{stats.idleVehicles} idling engines</span>
        </div>

        {/* Offline Vehicles */}
        <div
          onClick={() => onNavigate('vehicles')}
          className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group shadow-md"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Offline</span>
            <WifiOff className="w-4 h-4 text-zinc-500 group-hover:scale-110 transition-transform" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-zinc-400 font-mono">{stats.offlineVehicles}</p>
          <span className="text-[10px] text-slate-500 mt-1 block">No cellular signal</span>
        </div>

        {/* Active Alerts */}
        <div
          onClick={() => onNavigate('alerts')}
          className="p-4 rounded-2xl bg-slate-900 border border-slate-800 hover:border-rose-900/50 transition-all cursor-pointer group shadow-md"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Active Alerts</span>
            <AlertTriangle className="w-4 h-4 text-rose-500 group-hover:scale-110 transition-transform" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-rose-500 font-mono">{stats.activeAlerts}</p>
          <span className="text-[10px] text-rose-400/80 mt-1 block">{unreadAlerts.length} require review</span>
        </div>
      </div>

      {/* Main Row: Live Map Preview + Fleet Operations Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Preview Column (2 cols) */}
        <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-4 sm:p-5 flex flex-col shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Navigation className="w-4 h-4 text-blue-400" />
                <span>Live GPS Radar Preview</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Real-time positioning of {vehicles.length} tracking units
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('live-map')}
              className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
            >
              <span>Full Screen Interactive Map</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-[400px] w-full rounded-xl overflow-hidden">
            <LiveFleetMap
              vehicles={vehicles}
              selectedVehicle={selectedVehicle}
              onSelectVehicle={(v) => {
                flyToVehicle(v);
                onSelectVehicle(v.id);
              }}
              geofences={geofences}
            />
          </div>
        </div>

        {/* Fleet Distribution & Telematics Health */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 sm:p-5 flex flex-col justify-between shadow-xl space-y-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2 mb-1">
              <Activity className="w-4 h-4 text-emerald-400" />
              <span>Fleet Operational Health</span>
            </h2>
            <p className="text-xs text-slate-400">CAN telemetry & dispatch utilization</p>
          </div>

          {/* Utilization gauge */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300 font-semibold">Active Fleet Utilization</span>
              <span className="text-blue-400 font-mono font-bold">{stats.fleetUtilizationPercent}%</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-500 to-emerald-400 transition-all duration-500"
                style={{ width: `${stats.fleetUtilizationPercent}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>{stats.movingVehicles} In Transit</span>
              <span>{stats.totalVehicles} Total Fleet</span>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Today's Mileage</span>
              <span className="text-lg font-bold text-white font-mono mt-0.5 block">
                {stats.totalDistanceTodayKm.toLocaleString()} km
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
              <span className="text-slate-400 block text-[10px] uppercase font-semibold">Avg Cruising Speed</span>
              <span className="text-lg font-bold text-emerald-400 font-mono mt-0.5 block">
                {stats.avgFleetSpeedKmH} km/h
              </span>
            </div>
          </div>

          {/* Status Breakdown Bar */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-300 block">Status Breakdown</span>
            <div className="h-3 w-full rounded-full bg-slate-800 flex overflow-hidden">
              <div
                style={{ width: `${(stats.movingVehicles / stats.totalVehicles) * 100}%` }}
                className="bg-emerald-500"
                title={`Moving: ${stats.movingVehicles}`}
              />
              <div
                style={{ width: `${(stats.idleVehicles / stats.totalVehicles) * 100}%` }}
                className="bg-amber-400"
                title={`Idle: ${stats.idleVehicles}`}
              />
              <div
                style={{ width: `${(stats.stoppedVehicles / stats.totalVehicles) * 100}%` }}
                className="bg-slate-500"
                title={`Stopped: ${stats.stoppedVehicles}`}
              />
              <div
                style={{ width: `${(stats.offlineVehicles / stats.totalVehicles) * 100}%` }}
                className="bg-zinc-700"
                title={`Offline: ${stats.offlineVehicles}`}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500" /> Moving ({stats.movingVehicles})
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-400" /> Idle ({stats.idleVehicles})
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-slate-500" /> Stopped ({stats.stoppedVehicles})
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row: Recent Alerts + Recent Trips */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Alerts Feed */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-500" />
              <span>Critical Fleet Incidents</span>
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('alerts')}
              className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
            >
              <span>View All Alerts</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-800/80">
            {alerts.slice(0, 4).map((alert) => (
              <div
                key={alert.id}
                onClick={() => onNavigate('alerts')}
                className="py-3 flex items-start justify-between gap-3 cursor-pointer hover:bg-slate-800/40 rounded-xl px-2 transition-colors"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{alert.vehicleName}</span>
                    <span className="text-[10px] font-mono text-blue-400 font-semibold">{alert.plateNumber}</span>
                    <Badge status={alert.severity} variant="severity" />
                  </div>
                  <p className="text-xs text-slate-300">{alert.title}</p>
                  <p className="text-[11px] text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-500" />
                    <span className="truncate">{alert.address}</span>
                  </p>
                </div>
                <span className="text-[10px] text-slate-400 whitespace-nowrap">
                  {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Live Active Vehicle Roster Quick Access */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Truck className="w-4 h-4 text-blue-400" />
              <span>Active Dispatches & Drivers</span>
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('vehicles')}
              className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
            >
              <span>All Vehicles</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-800/80">
            {vehicles.slice(0, 4).map((veh) => (
              <div
                key={veh.id}
                onClick={() => {
                  flyToVehicle(veh);
                  onSelectVehicle(veh.id);
                  onNavigate('live-map');
                }}
                className="py-3 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-800/40 rounded-xl px-2 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
                    <Truck className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-white">{veh.name}</p>
                    <p className="text-[11px] text-slate-400">
                      {veh.driverName} • <span className="font-mono text-slate-300">{veh.plateNumber}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-right">
                  <div>
                    <span className="text-xs font-mono font-bold text-white block">
                      {veh.telemetry.speed} km/h
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {veh.telemetry.fuelLevel}% Fuel
                    </span>
                  </div>
                  <Badge status={veh.status} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
