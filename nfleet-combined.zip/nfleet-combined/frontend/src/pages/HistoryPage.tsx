import React, { useState, useEffect } from 'react';
import { useFleet } from '../context/FleetContext';
import { historyService } from '../services/historyService';
import { TripHistory } from '../types';
import { HistoryRouteMap } from '../components/map/HistoryRouteMap';
import {
  Calendar,
  Clock,
  Truck,
  Gauge,
  MapPin,
  Flame,
  PauseCircle,
  AlertTriangle,
  Search,
  Filter,
  Download,
  CheckCircle2,
} from 'lucide-react';

interface HistoryPageProps {
  initialVehicleId?: string;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({ initialVehicleId }) => {
  const { vehicles } = useFleet();

  const [selectedVehicleId, setSelectedVehicleId] = useState<string>(
    initialVehicleId || vehicles[0]?.id || 'veh-1'
  );
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [startTime, setStartTime] = useState<string>('06:00');
  const [endTime, setEndTime] = useState<string>('20:00');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [tripHistory, setTripHistory] = useState<TripHistory | null>(null);

  const loadTrip = async (vehId: string, date: string) => {
    setIsLoading(true);
    try {
      const history = await historyService.getTripHistory(vehId, date);
      setTripHistory(history);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTrip(selectedVehicleId, selectedDate);
  }, [selectedVehicleId, selectedDate]);

  const handleQuery = (e: React.FormEvent) => {
    e.preventDefault();
    loadTrip(selectedVehicleId, selectedDate);
  };

  const currentVehicle = vehicles.find((v) => v.id === selectedVehicleId);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Route Playback & Trip History</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Replay recorded telematics breadcrumbs, examine driving speed, and audit delivery stops.
          </p>
        </div>

        {tripHistory && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => alert(`Exporting GPX / KML audit route for ${tripHistory.vehicleName}`)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Export GPX / KML</span>
            </button>
          </div>
        )}
      </div>

      {/* Query Filter Bar */}
      <form
        onSubmit={handleQuery}
        className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end"
      >
        {/* Vehicle Picker */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
            Fleet Vehicle
          </label>
          <div className="relative">
            <Truck className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <select
              value={selectedVehicleId}
              onChange={(e) => setSelectedVehicleId(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 text-xs focus:outline-hidden focus:border-blue-500 font-medium"
            >
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name} ({v.plateNumber})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Date Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
            Audit Date
          </label>
          <div className="relative">
            <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 text-xs focus:outline-hidden focus:border-blue-500 font-medium"
            />
          </div>
        </div>

        {/* Start Time */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
            From Time
          </label>
          <div className="relative">
            <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 text-xs focus:outline-hidden focus:border-blue-500 font-medium"
            />
          </div>
        </div>

        {/* End Time */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
            To Time
          </label>
          <div className="relative">
            <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950 text-white rounded-xl border border-slate-700 text-xs focus:outline-hidden focus:border-blue-500 font-medium"
            />
          </div>
        </div>

        {/* Query Button */}
        <div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Search className="w-3.5 h-3.5" />
                <span>Fetch History</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Historical Telematics Key Performance Stats */}
      {tripHistory && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Distance */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
            <span className="text-[10px] uppercase font-semibold text-slate-400 flex items-center gap-1">
              <MapPin className="w-3 h-3 text-blue-400" /> Total Distance
            </span>
            <p className="text-xl font-extrabold text-white font-mono mt-1">
              {tripHistory.totalDistanceKm} <span className="text-xs text-slate-400 font-normal">km</span>
            </p>
          </div>

          {/* Moving Time */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
            <span className="text-[10px] uppercase font-semibold text-slate-400 flex items-center gap-1">
              <Clock className="w-3 h-3 text-emerald-400" /> Driving Time
            </span>
            <p className="text-xl font-extrabold text-emerald-400 font-mono mt-1">
              {Math.floor(tripHistory.movingDurationMinutes / 60)}h {tripHistory.movingDurationMinutes % 60}m
            </p>
          </div>

          {/* Idle / Stopped Time */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
            <span className="text-[10px] uppercase font-semibold text-slate-400 flex items-center gap-1">
              <PauseCircle className="w-3 h-3 text-amber-400" /> Stop Time
            </span>
            <p className="text-xl font-extrabold text-amber-300 font-mono mt-1">
              {tripHistory.idleDurationMinutes} <span className="text-xs text-slate-400 font-normal">min</span>
            </p>
          </div>

          {/* Average Speed */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
            <span className="text-[10px] uppercase font-semibold text-slate-400 flex items-center gap-1">
              <Gauge className="w-3 h-3 text-cyan-400" /> Average Speed
            </span>
            <p className="text-xl font-extrabold text-white font-mono mt-1">
              {tripHistory.avgSpeedKmH} <span className="text-xs text-slate-400 font-normal">km/h</span>
            </p>
          </div>

          {/* Max Speed */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
            <span className="text-[10px] uppercase font-semibold text-slate-400 flex items-center gap-1">
              <Gauge className="w-3 h-3 text-rose-400" /> Peak Speed
            </span>
            <p className="text-xl font-extrabold text-rose-400 font-mono mt-1">
              {tripHistory.maxSpeedKmH} <span className="text-xs text-slate-400 font-normal">km/h</span>
            </p>
          </div>

          {/* Stops / Violations */}
          <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-md">
            <span className="text-[10px] uppercase font-semibold text-slate-400 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3 text-yellow-400" /> Stops & Incidents
            </span>
            <p className="text-xl font-extrabold text-yellow-300 font-mono mt-1">
              {tripHistory.stopCount} <span className="text-xs text-slate-400 font-normal">stops / {tripHistory.alertCount} alerts</span>
            </p>
          </div>
        </div>
      )}

      {/* Main Map Playback Canvas */}
      {tripHistory ? (
        <div className="h-[520px] w-full">
          <HistoryRouteMap trip={tripHistory} />
        </div>
      ) : (
        <div className="p-12 text-center bg-slate-900 rounded-2xl border border-slate-800 text-slate-400">
          No historical route points recorded for the selected window.
        </div>
      )}

      {/* Stops & Waypoint Chronology Table */}
      {tripHistory && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <span>Trip Event Chronology & Delivery Stops</span>
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/60 text-slate-400 uppercase font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Event</th>
                  <th className="py-2.5 px-4">Timestamp</th>
                  <th className="py-2.5 px-4">Location / Address</th>
                  <th className="py-2.5 px-4">Speed</th>
                  <th className="py-2.5 px-4">Duration</th>
                  <th className="py-2.5 px-4">Fuel Remaining</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                <tr className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-4 font-bold text-emerald-400">Trip Departed</td>
                  <td className="py-2.5 px-4 font-mono">{tripHistory.startTime}</td>
                  <td className="py-2.5 px-4">{tripHistory.startAddress}</td>
                  <td className="py-2.5 px-4 font-mono">0 km/h</td>
                  <td className="py-2.5 px-4 text-slate-400">—</td>
                  <td className="py-2.5 px-4 font-mono text-emerald-400">92%</td>
                </tr>

                {tripHistory.points
                  .filter((p) => p.event === 'stop' || p.event === 'speed_violation')
                  .map((p, i) => (
                    <tr key={i} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-4 font-bold">
                        {p.event === 'stop' ? (
                          <span className="text-amber-400">Engine Stop (Ignition Off)</span>
                        ) : (
                          <span className="text-rose-400">Speed Threshold Alert</span>
                        )}
                      </td>
                      <td className="py-2.5 px-4 font-mono">{p.timestamp}</td>
                      <td className="py-2.5 px-4">{p.address}</td>
                      <td className="py-2.5 px-4 font-mono">{p.speed} km/h</td>
                      <td className="py-2.5 px-4 font-semibold text-slate-200">
                        {p.stopDuration ? `${p.stopDuration} mins` : 'Instantaneous'}
                      </td>
                      <td className="py-2.5 px-4 font-mono text-amber-300">{p.fuelLevel}%</td>
                    </tr>
                  ))}

                <tr className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-4 font-bold text-blue-400">Trip Terminated</td>
                  <td className="py-2.5 px-4 font-mono">{tripHistory.endTime}</td>
                  <td className="py-2.5 px-4">{tripHistory.endAddress}</td>
                  <td className="py-2.5 px-4 font-mono">0 km/h</td>
                  <td className="py-2.5 px-4 text-slate-400">—</td>
                  <td className="py-2.5 px-4 font-mono text-slate-200">
                    {tripHistory.points[tripHistory.points.length - 1]?.fuelLevel || 68}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
