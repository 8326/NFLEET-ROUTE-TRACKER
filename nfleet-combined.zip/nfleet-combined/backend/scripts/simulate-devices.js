/* eslint-disable no-console */
// Simulates real GPS trackers by POSTing telemetry packets to
// /api/v1/ingest/telemetry, exactly the way a physical device would.
// Useful for testing the full pipeline (DB write -> alert engine ->
// WebSocket broadcast -> frontend map) before hardware is on trucks.
//
// Usage:
//   npm run simulate
//   API_BASE=http://localhost:8080 npm run simulate

import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const API_BASE = process.env.API_BASE || 'http://localhost:8080';
const dbPath = path.resolve(__dirname, '../data/nfleet.db');

const db = new Database(dbPath, { readonly: true });
const devices = db
  .prepare(
    `SELECT d.imei, d.api_key, v.id AS vehicleId, v.lat, v.lng, v.speed_limit, v.status
     FROM devices d JOIN vehicles v ON v.id = d.vehicle_assigned`
  )
  .all();

if (devices.length === 0) {
  console.error('No devices with an assigned vehicle found. Run `npm run seed` first.');
  process.exit(1);
}

const state = new Map(
  devices.map((d) => [
    d.imei,
    { lat: d.lat, lng: d.lng, heading: Math.random() * 360, speedLimit: d.speed_limit },
  ])
);

console.log(`Simulating ${devices.length} GPS trackers against ${API_BASE} (Ctrl+C to stop)`);

setInterval(async () => {
  for (const device of devices) {
    const s = state.get(device.imei);

    // Random walk with occasional deliberate overspeed to exercise alerts.
    const speed = Math.max(0, Math.round(30 + Math.sin(Date.now() / 20000) * 40 + (Math.random() - 0.4) * 15));
    s.heading = (s.heading + (Math.random() - 0.5) * 20 + 360) % 360;
    const rad = (s.heading * Math.PI) / 180;
    s.lat += Math.cos(rad) * 0.0006;
    s.lng += Math.sin(rad) * 0.0006;

    const packet = {
      imei: device.imei,
      lat: s.lat,
      lng: s.lng,
      speed,
      heading: Math.round(s.heading),
      ignition: speed > 0,
      satellites: 10 + Math.floor(Math.random() * 4),
      batteryVoltage: 12.4 + Math.random() * 0.4,
      fuelLevel: 60 + Math.random() * 30,
      address: 'Simulated GPS fix (no reverse geocoding configured)',
      timestamp: new Date().toISOString(),
    };

    try {
      const res = await fetch(`${API_BASE}/api/v1/ingest/telemetry`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Device-Key': device.api_key },
        body: JSON.stringify(packet),
      });
      if (!res.ok) {
        console.warn(`[${device.imei}] ingest rejected: ${res.status} ${await res.text()}`);
      }
    } catch (err) {
      console.warn(`[${device.imei}] request failed: ${err.message}`);
    }
  }
}, 3000);
