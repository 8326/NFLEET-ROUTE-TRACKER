# NFLEET Backend

A production-ready REST + WebSocket backend for the NFLEET GPS fleet tracking
platform. It was built to match the API contract your frontend already
expects (`src/services/*.ts`), so wiring it up is just setting two env
variables in the frontend — no frontend code changes needed.

## What's inside

- **Express REST API** — auth, vehicles, drivers, devices, geofences,
  alerts, trip history, GPS ingestion. JWT auth, bcrypt password hashing,
  Zod request validation, rate limiting, Helmet security headers, CORS.
- **SQLite database** (via `better-sqlite3`) — a single-file database,
  zero external services to stand up. Schema in `src/db/schema.sql` is
  applied automatically on boot.
- **WebSocket server** (`/ws`) — broadcasts live GPS telemetry to every
  connected client in the exact packet shape the frontend's `gpsService`
  already parses.
- **Alert engine** — every ingested GPS packet is checked for overspeed and
  geofence enter/exit, and raises alerts automatically.
- **Trip history recorder** — each GPS packet is appended to that vehicle's
  trip for the day, with distance/speed/duration aggregates computed live.
- **Device simulator** (`npm run simulate`) — pushes realistic GPS packets
  through the exact same ingestion path a physical tracker would use, so you
  can see the whole pipeline working before hardware is installed in trucks.

## Quick start

```bash
npm install
cp .env.example .env        # edit JWT_SECRET etc. before deploying
npm run dev                 # starts on http://localhost:8080
```

On first boot (with `SEED_DEMO_DATA=true`, the default) it creates a demo
database with 7 vehicles, 4 drivers, geofences, and two login users:

| Email               | Password   | Role         |
|---------------------|------------|--------------|
| admin@nfleet.io      | nfleet123  | super_admin  |
| dispatch@nfleet.io   | nfleet123  | dispatcher   |

Change `SEED_ADMIN_PASSWORD` in `.env` before deploying anywhere public, and
set `SEED_DEMO_DATA=false` once you've onboarded real vehicles.

Try the full pipeline with fake trackers:

```bash
npm run simulate            # in a second terminal, once the server is running
```

This pushes GPS packets for every seeded vehicle straight into
`/api/v1/ingest/telemetry`, exactly like a real device would — watch alerts
and trip history populate as it runs.

## Connecting the frontend

In the frontend project's `.env` (or via the in-app API Gateway settings
modal, which writes to the same localStorage keys):

```bash
VITE_API_BASE_URL="http://localhost:8080"
VITE_WS_URL="ws://localhost:8080/ws?token=<JWT from login>"
```

The frontend's `authService`, `vehicleService`, `historyService`, and
`alertService` already call these exact routes and fall back to demo mode
automatically if the backend is unreachable — so nothing else needs to
change. Because the WS URL needs a live JWT, the cleanest approach is to
append the token after login rather than hardcoding it; see
`src/services/apiConfig.ts` — `setApiEndpoints()` is a natural place to do
that once the user is authenticated.

## API reference

All routes are prefixed with `/api/v1` and require `Authorization: Bearer
<token>` unless noted otherwise.

### Auth
| Method | Path | Body | Notes |
|---|---|---|---|
| POST | `/auth/login` | `{ email, password, rememberMe? }` | Public. Returns `{ user, token }`. Rate-limited to 20/15min. |
| GET | `/auth/me` | — | Returns the current user. |

### Vehicles
| Method | Path | Body | Notes |
|---|---|---|---|
| GET | `/vehicles` | — | List all vehicles. |
| GET | `/vehicles/:id` | — | |
| POST | `/vehicles` | `Vehicle` fields (minus telemetry) | Creates a vehicle at a default depot position. |
| PATCH | `/vehicles/:id` | partial fields | |
| DELETE | `/vehicles/:id` | — | |
| POST | `/vehicles/:id/relay` | `{ cutoff: boolean }` | Toggles the remote immobilizer; broadcasts the change over WS. |

### Trip history
| Method | Path | Notes |
|---|---|---|
| GET | `/history?vehicleId=&date=YYYY-MM-DD` | Full route + aggregates for one vehicle/day. |
| GET | `/history/dates?vehicleId=` | Dates that have recorded trips. |

### Alerts
| Method | Path | Body |
|---|---|---|
| GET | `/alerts` | — |
| POST | `/alerts/:id/acknowledge` | `{ acknowledgedBy?, notes? }` |
| POST | `/alerts/:id/resolve` | — (deletes the alert) |

### Drivers / Devices / Geofences
Full CRUD under `/drivers`, `/devices`, `/geofences` — see the route files
for exact schemas. Creating a device returns its `apiKey` **once**; store it
securely, it's what that tracker uses to authenticate ingestion.

### GPS ingestion (for physical trackers)
| Method | Path | Header | Body |
|---|---|---|---|
| POST | `/ingest/telemetry` | `X-Device-Key: <per-device api key>` | `{ lat, lng, speed, heading?, ignition, satellites?, batteryVoltage?, fuelLevel?, odometer?, engineRpm?, address?, timestamp? }` |

This is the one endpoint your GPS hardware (or a gateway service decoding
Teltonika/Queclink/GT06 protocol frames into JSON) needs to call. Each
packet updates the vehicle's live position, runs the alert engine, appends
to trip history, and broadcasts to every connected dashboard over
WebSocket — all in one request.

### Health check
`GET /healthz` — no auth required, useful for load balancer / uptime checks.

## Deployment

```bash
docker compose up -d --build
```

The compose file mounts a named volume for the SQLite file so data survives
container restarts, and requires `JWT_SECRET` to be set via your `.env`
file (it will refuse to start with the default dev secret in production).

For a fleet beyond a few hundred vehicles, SQLite will comfortably keep up
(it's WAL-mode and single-writer), but if you outgrow it the swap to
Postgres only touches `src/db/*` — the route/controller layer talks to `db`
through plain SQL, not an ORM, so the migration is mechanical.

## Security notes

- Rotate `JWT_SECRET` and every device's `apiKey` before going to production.
- Put this behind HTTPS (a reverse proxy like Caddy or an ALB) — the API
  itself doesn't terminate TLS.
- `CORS_ORIGINS` must be set to your real frontend origin(s) in production;
  the default only allows `localhost:3000`.
- Consider adding a per-organization scoping layer before this ever serves
  more than one company's fleet — currently every authenticated user sees
  every vehicle, which matches the current single-tenant frontend.
