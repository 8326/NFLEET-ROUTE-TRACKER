const EARTH_RADIUS_M = 6371000;

function toRad(deg) {
  return (deg * Math.PI) / 180;
}

/** Great-circle distance between two lat/lng points, in meters. */
export function distanceMeters(a, b) {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);

  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  return EARTH_RADIUS_M * c;
}

export function distanceKm(a, b) {
  return distanceMeters(a, b) / 1000;
}

/** Ray-casting point-in-polygon test. polygon is an array of {lat,lng}. */
export function isPointInPolygon(point, polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].lng;
    const yi = polygon[i].lat;
    const xj = polygon[j].lng;
    const yj = polygon[j].lat;

    const intersect =
      yi > point.lat !== yj > point.lat &&
      point.lng < ((xj - xi) * (point.lat - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

/** Returns true if `point` currently falls inside the given geofence zone. */
export function isInsideGeofence(point, geofence) {
  if (geofence.type === 'circle' && geofence.center && geofence.radiusMeters) {
    return distanceMeters(point, geofence.center) <= geofence.radiusMeters;
  }
  if (geofence.type === 'polygon' && geofence.polygonCoordinates?.length >= 3) {
    return isPointInPolygon(point, geofence.polygonCoordinates);
  }
  return false;
}
