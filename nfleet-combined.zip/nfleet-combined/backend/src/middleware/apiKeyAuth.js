import { db } from '../db/index.js';
import { config } from '../config.js';

/**
 * Authenticates a physical GPS tracker (or the device simulator) pushing
 * telemetry. Accepts either:
 *  - X-Device-Key header matching a device's per-device api_key, or
 *  - X-Device-Key matching the INGEST_MASTER_KEY fallback (dev/staging only)
 * Resolves req.device to the matching device row (or null when using the
 * master key without a specific device on file).
 */
export function requireDeviceKey(req, res, next) {
  const key = req.headers['x-device-key'];
  if (!key) {
    return res.status(401).json({ message: 'Missing X-Device-Key header' });
  }

  if (config.ingestMasterKey && key === config.ingestMasterKey) {
    req.device = null;
    return next();
  }

  const device = db.prepare('SELECT * FROM devices WHERE api_key = ?').get(key);
  if (!device) {
    return res.status(401).json({ message: 'Unrecognized device key' });
  }

  req.device = device;
  return next();
}
