/**
 * Validates req[part] against a zod schema, replacing it with the parsed
 * (and coerced/defaulted) value on success. Throws ZodError on failure,
 * which the central error handler turns into a 400 response.
 */
export function validate(schema, part = 'body') {
  return (req, res, next) => {
    req[part] = schema.parse(req[part]);
    next();
  };
}
