import { nanoid } from 'nanoid';
import { db } from '../db/index.js';
import { vehicleRowToJson, alertRowToJson } from '../db/mappers.js';
import { isInsideGeofence } from '../utils/geo.js';
import { broadcastTelemetry, broadcastAlert } from '../ws/broadcaster.js';
import { logger } from '../utils/logger.js';

const findVehicleByIdOrImei = db.prepare(
  'SELECT * FROM vehicles WHERE id = ? OR imei = ? LIMIT 1'
);

const updateVehicleStmt = db.prepare(`
  UPDATE vehicles SET
    lat = @lat, lng = @lng, speed = @speed, heading = @heading,
    ignition = @ignition, satellites = COALESCE(@satellites, satellites),
    battery_voltage = COALESCE(@batteryVoltage, battery_voltage),
    fuel_level = COALESCE(@fuelLevel, fuel_level),
    odometer = COALESCE(@odometer, odometer),
    engine_rpm = COALESCE(@engineRpm, engine_rpm),
    address = COALESCE(@address, address),
    status = @status,
    telemetry_timestamp = @timestamp,
    last_heartbeat = @timestamp
  WHERE id = @id
`);

const insertAlertStmt = db.prepare(`
  INSERT INTO alerts (id, vehicle_id, vehicle_name, plate_number, driver_name, type, severity, title, description, lat, lng, address, speed, speed_limit, timestamp, acknowledged)
  VALUES (@id, @vehicleId, @vehicleName, @plateNumber, @driverName, @type, @severity, @title, @description, @lat, @lng, @address, @speed, @speedLimit, @timestamp, 0)
`);

const getOrOpenTripStmt = db.prepare(
  `SELECT * FROM trips WHERE vehicle_id = ? AND trip_date = ? LIMIT 1`
);
const insertTripStmt = db.prepare(`
  INSERT INTO trips (id, vehicle_id, vehicle_name, plate_number, trip_date, start_time, start_address, is_open)
  VALUES (@id, @vehicleId, @vehicleName, @plateNumber, @tripDate, @startTime, @startAddress, 1)
`);
const insertTripPointStmt = db.prepare(`
  INSERT INTO trip_points (trip_id, lat, lng, timestamp, speed, heading, ignition, fuel_level, event, address)
  VALUES (@tripId, @lat, @lng, @timestamp, @speed, @heading, @ignition, @fuelLevel, @event, @address)
`);
const updateTripAggregatesStmt = db.prepare(`
  UPDATE trips SET
    end_time = @endTime,
    total_distance_km = total_distance_km + @deltaKm,
    max_speed_kmh = MAX(max_speed_kmh, @speed),
    avg_speed_kmh = ((avg_speed_kmh * (SELECT COUNT(*) FROM trip_points WHERE trip_id = @id) ) + @speed) / ((SELECT COUNT(*) FROM trip_points WHERE trip_id = @id) + 1),
    end_address = @endAddress,
    alert_count = alert_count + @alertDelta
  WHERE id = @id
`);

const getGeofencesStmt = db.prepare('SELECT * FROM geofences');
const getGeofenceStateStmt = db.prepare(
  'SELECT inside FROM vehicle_geofence_state WHERE vehicle_id = ? AND geofence_id = ?'
);
const upsertGeofenceStateStmt = db.prepare(`
  INSERT INTO vehicle_geofence_state (vehicle_id, geofence_id, inside, updated_at)
  VALUES (@vehicleId, @geofenceId, @inside, @now)
  ON CONFLICT(vehicle_id, geofence_id) DO UPDATE SET inside = @inside, updated_at = @now
`);

function haversineKm(a, b) {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s));
}

/**
 * Processes one inbound GPS/telemetry packet from a device (or the
 * simulator): persists the new position, evaluates overspeed + geofence
 * alerts, appends a trip point for today's open trip, and broadcasts the
 * update to every connected WebSocket client.
 */
export const telemetryService = {
  ingest(packet) {
    const lookupKey = packet.vehicleId || packet.imei;
    const vehicle = findVehicleByIdOrImei.get(lookupKey, lookupKey);
    if (!vehicle) {
      throw Object.assign(new Error(`No vehicle matches id/imei "${lookupKey}"`), { status: 404 });
    }

    const timestamp = packet.timestamp || new Date().toISOString();
    const status = packet.speed > 5 ? 'moving' : packet.ignition ? 'idle' : 'stopped';

    updateVehicleStmt.run({
      id: vehicle.id,
      lat: packet.lat,
      lng: packet.lng,
      speed: packet.speed,
      heading: packet.heading ?? vehicle.heading,
      ignition: packet.ignition ? 1 : 0,
      satellites: packet.satellites ?? null,
      batteryVoltage: packet.batteryVoltage ?? null,
      fuelLevel: packet.fuelLevel ?? null,
      odometer: packet.odometer ?? null,
      engineRpm: packet.engineRpm ?? null,
      address: packet.address ?? null,
      status,
      timestamp,
    });

    const newAlerts = [];

    // --- Overspeed detection ---
    if (vehicle.speed_limit && packet.speed > vehicle.speed_limit) {
      newAlerts.push(
        this._raiseAlert(vehicle, {
          type: 'overspeed',
          severity: packet.speed - vehicle.speed_limit > 20 ? 'critical' : 'warning',
          title: 'Speed limit exceeded',
          description: `Recorded ${Math.round(packet.speed)} km/h in a ${vehicle.speed_limit} km/h zone.`,
          lat: packet.lat,
          lng: packet.lng,
          address: packet.address,
          speed: packet.speed,
          speedLimit: vehicle.speed_limit,
          timestamp,
        })
      );
    }

    // --- Geofence enter/exit detection ---
    const geofences = getGeofencesStmt.all();
    for (const g of geofences) {
      const zone = {
        type: g.type,
        center: g.center_lat != null ? { lat: g.center_lat, lng: g.center_lng } : undefined,
        radiusMeters: g.radius_meters,
        polygonCoordinates: g.polygon_coordinates ? JSON.parse(g.polygon_coordinates) : undefined,
      };
      const nowInside = isInsideGeofence({ lat: packet.lat, lng: packet.lng }, zone);
      const prevRow = getGeofenceStateStmt.get(vehicle.id, g.id);
      const wasInside = Boolean(prevRow?.inside);

      if (nowInside !== wasInside) {
        upsertGeofenceStateStmt.run({
          vehicleId: vehicle.id,
          geofenceId: g.id,
          inside: nowInside ? 1 : 0,
          now: timestamp,
        });

        if (nowInside && g.alert_on_entry) {
          newAlerts.push(
            this._raiseAlert(vehicle, {
              type: 'geofence_enter',
              severity: 'info',
              title: `Entered ${g.name}`,
              description: `Vehicle entered geofence "${g.name}".`,
              lat: packet.lat,
              lng: packet.lng,
              address: packet.address,
              timestamp,
            })
          );
        } else if (!nowInside && wasInside && g.alert_on_exit) {
          newAlerts.push(
            this._raiseAlert(vehicle, {
              type: 'geofence_exit',
              severity: 'info',
              title: `Exited ${g.name}`,
              description: `Vehicle exited geofence "${g.name}".`,
              lat: packet.lat,
              lng: packet.lng,
              address: packet.address,
              timestamp,
            })
          );
        }
      }
    }

    this._appendTripPoint(vehicle, packet, timestamp, newAlerts.length);

    const updatedRow = findVehicleByIdOrImei.get(vehicle.id, vehicle.id);
    broadcastTelemetry({
      vehicleId: vehicle.id,
      imei: vehicle.imei,
      lat: packet.lat,
      lng: packet.lng,
      speed: packet.speed,
      heading: packet.heading ?? vehicle.heading,
      ignition: Boolean(packet.ignition),
      satellites: packet.satellites,
      batteryVoltage: packet.batteryVoltage,
      fuelLevel: packet.fuelLevel,
      address: packet.address,
      timestamp,
    });

    for (const alert of newAlerts) broadcastAlert(alert);

    return { vehicle: vehicleRowToJson(updatedRow), alerts: newAlerts };
  },

  _raiseAlert(vehicle, fields) {
    const row = {
      id: `alrt-${nanoid(10)}`,
      vehicleId: vehicle.id,
      vehicleName: vehicle.name,
      plateNumber: vehicle.plate_number,
      driverName: vehicle.driver_name,
      ...fields,
    };
    insertAlertStmt.run(row);
    logger.info({ vehicleId: vehicle.id, type: fields.type }, 'Alert raised');
    return alertRowToJson({
      ...row,
      vehicle_id: row.vehicleId,
      vehicle_name: row.vehicleName,
      plate_number: row.plateNumber,
      driver_name: row.driverName,
      speed_limit: row.speedLimit,
      acknowledged: 0,
    });
  },

  _appendTripPoint(vehicle, packet, timestamp, alertDelta) {
    const tripDate = timestamp.slice(0, 10);
    let trip = getOrOpenTripStmt.get(vehicle.id, tripDate);

    if (!trip) {
      const id = `trip-${vehicle.id}-${tripDate}`;
      insertTripStmt.run({
        id,
        vehicleId: vehicle.id,
        vehicleName: vehicle.name,
        plateNumber: vehicle.plate_number,
        tripDate,
        startTime: timestamp,
        startAddress: packet.address || vehicle.address,
      });
      trip = getOrOpenTripStmt.get(vehicle.id, tripDate);
    }

    const deltaKm =
      vehicle.lat && vehicle.lng
        ? haversineKm({ lat: vehicle.lat, lng: vehicle.lng }, { lat: packet.lat, lng: packet.lng })
        : 0;

    insertTripPointStmt.run({
      tripId: trip.id,
      lat: packet.lat,
      lng: packet.lng,
      timestamp,
      speed: packet.speed || 0,
      heading: packet.heading ?? 0,
      ignition: packet.ignition ? 1 : 0,
      fuelLevel: packet.fuelLevel ?? null,
      event: deltaKm === 0 && packet.speed === 0 ? 'stop' : null,
      address: packet.address ?? null,
    });

    updateTripAggregatesStmt.run({
      id: trip.id,
      endTime: timestamp,
      deltaKm,
      speed: packet.speed || 0,
      endAddress: packet.address || vehicle.address,
      alertDelta,
    });
  },
};
