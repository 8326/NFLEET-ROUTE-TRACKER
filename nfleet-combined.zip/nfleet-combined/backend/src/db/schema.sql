PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  email           TEXT NOT NULL UNIQUE,
  password_hash   TEXT NOT NULL,
  role            TEXT NOT NULL DEFAULT 'fleet_manager',
  organization    TEXT NOT NULL DEFAULT 'NFLEET',
  timezone        TEXT NOT NULL DEFAULT 'UTC',
  avatar_url      TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS drivers (
  id                    TEXT PRIMARY KEY,
  name                  TEXT NOT NULL,
  license_number        TEXT,
  phone                 TEXT,
  email                 TEXT,
  avatar_url            TEXT,
  status                TEXT NOT NULL DEFAULT 'off_duty',
  assigned_vehicle_id   TEXT,
  safety_score          REAL NOT NULL DEFAULT 100,
  rating                REAL,
  total_trips           INTEGER NOT NULL DEFAULT 0,
  total_distance_km     REAL NOT NULL DEFAULT 0,
  total_hours           REAL NOT NULL DEFAULT 0,
  shift_hours_today     REAL NOT NULL DEFAULT 0,
  violations_count      INTEGER NOT NULL DEFAULT 0,
  created_at            TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS vehicles (
  id                  TEXT PRIMARY KEY,
  name                TEXT NOT NULL,
  plate_number        TEXT NOT NULL,
  imei                TEXT UNIQUE,
  device_model        TEXT,
  sim_number          TEXT,
  driver_id           TEXT REFERENCES drivers(id) ON DELETE SET NULL,
  driver_name         TEXT,
  driver_phone        TEXT,
  group_name          TEXT DEFAULT 'Unassigned',
  type                TEXT NOT NULL DEFAULT 'truck',
  status              TEXT NOT NULL DEFAULT 'offline',
  speed_limit         REAL NOT NULL DEFAULT 100,
  icon_type           TEXT,

  lat                 REAL NOT NULL DEFAULT 0,
  lng                 REAL NOT NULL DEFAULT 0,

  speed               REAL NOT NULL DEFAULT 0,
  heading             REAL NOT NULL DEFAULT 0,
  altitude            REAL,
  accuracy            REAL,
  satellites          INTEGER NOT NULL DEFAULT 0,
  ignition            INTEGER NOT NULL DEFAULT 0,
  engine_rpm          REAL NOT NULL DEFAULT 0,
  fuel_level          REAL NOT NULL DEFAULT 0,
  battery_voltage     REAL NOT NULL DEFAULT 0,
  odometer            REAL NOT NULL DEFAULT 0,
  engine_temp         REAL,
  relay_cutoff        INTEGER NOT NULL DEFAULT 0,
  address             TEXT,
  telemetry_timestamp TEXT,

  last_heartbeat      TEXT,
  created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS devices (
  id                      TEXT PRIMARY KEY,
  imei                    TEXT NOT NULL UNIQUE,
  model                   TEXT,
  protocol                TEXT,
  firmware_version        TEXT,
  sim_number              TEXT,
  sim_iccid               TEXT,
  operator                TEXT,
  api_key                 TEXT NOT NULL UNIQUE,
  battery_status          REAL,
  backup_battery_voltage  REAL,
  gsm_signal_dbm          REAL,
  gsm_signal_percent      REAL,
  satellite_count         INTEGER,
  status                  TEXT NOT NULL DEFAULT 'unregistered',
  vehicle_assigned        TEXT REFERENCES vehicles(id) ON DELETE SET NULL,
  last_communication      TEXT,
  last_ping_timestamp     TEXT,
  created_at              TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS geofences (
  id                  TEXT PRIMARY KEY,
  name                TEXT NOT NULL,
  description         TEXT,
  type                TEXT NOT NULL DEFAULT 'circle',
  category            TEXT,
  center_lat          REAL,
  center_lng          REAL,
  radius_meters       REAL,
  polygon_coordinates TEXT,
  color               TEXT DEFAULT '#3b82f6',
  speed_limit_kmh     REAL,
  alert_on_entry      INTEGER NOT NULL DEFAULT 1,
  alert_on_exit       INTEGER NOT NULL DEFAULT 1,
  alert_on_overspeed  INTEGER NOT NULL DEFAULT 0,
  created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS geofence_vehicles (
  geofence_id TEXT NOT NULL REFERENCES geofences(id) ON DELETE CASCADE,
  vehicle_id  TEXT NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  PRIMARY KEY (geofence_id, vehicle_id)
);

-- Tracks whether a vehicle is currently inside a geofence, so we can detect
-- enter/exit transitions instead of firing an alert on every single ping.
CREATE TABLE IF NOT EXISTS vehicle_geofence_state (
  vehicle_id  TEXT NOT NULL,
  geofence_id TEXT NOT NULL,
  inside      INTEGER NOT NULL DEFAULT 0,
  updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (vehicle_id, geofence_id)
);

CREATE TABLE IF NOT EXISTS alerts (
  id                TEXT PRIMARY KEY,
  vehicle_id        TEXT REFERENCES vehicles(id) ON DELETE CASCADE,
  vehicle_name      TEXT,
  plate_number      TEXT,
  driver_name       TEXT,
  type              TEXT NOT NULL,
  severity          TEXT NOT NULL DEFAULT 'info',
  title             TEXT NOT NULL,
  description       TEXT,
  lat               REAL,
  lng               REAL,
  address           TEXT,
  speed             REAL,
  speed_limit       REAL,
  timestamp         TEXT NOT NULL DEFAULT (datetime('now')),
  acknowledged      INTEGER NOT NULL DEFAULT 0,
  acknowledged_by   TEXT,
  acknowledged_at   TEXT,
  resolution_notes  TEXT
);

CREATE TABLE IF NOT EXISTS trips (
  id                       TEXT PRIMARY KEY,
  vehicle_id               TEXT NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  vehicle_name             TEXT,
  plate_number             TEXT,
  trip_date                TEXT NOT NULL,
  start_time               TEXT,
  end_time                 TEXT,
  start_address            TEXT,
  end_address              TEXT,
  total_distance_km        REAL NOT NULL DEFAULT 0,
  moving_duration_minutes  REAL NOT NULL DEFAULT 0,
  idle_duration_minutes    REAL NOT NULL DEFAULT 0,
  avg_speed_kmh            REAL NOT NULL DEFAULT 0,
  max_speed_kmh            REAL NOT NULL DEFAULT 0,
  fuel_consumed_liters     REAL NOT NULL DEFAULT 0,
  stop_count               INTEGER NOT NULL DEFAULT 0,
  alert_count              INTEGER NOT NULL DEFAULT 0,
  is_open                  INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_trips_vehicle_date ON trips(vehicle_id, trip_date);

CREATE TABLE IF NOT EXISTS trip_points (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  trip_id       TEXT NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  lat           REAL NOT NULL,
  lng           REAL NOT NULL,
  timestamp     TEXT NOT NULL,
  speed         REAL NOT NULL DEFAULT 0,
  heading       REAL NOT NULL DEFAULT 0,
  ignition      INTEGER NOT NULL DEFAULT 0,
  altitude      REAL,
  fuel_level    REAL,
  event         TEXT,
  stop_duration REAL,
  address       TEXT
);

CREATE INDEX IF NOT EXISTS idx_trip_points_trip ON trip_points(trip_id);
