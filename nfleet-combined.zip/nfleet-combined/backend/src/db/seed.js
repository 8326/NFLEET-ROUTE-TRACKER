import bcrypt from 'bcryptjs';
import { nanoid } from 'nanoid';
import { db } from './index.js';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

function alreadySeeded() {
  const row = db.prepare('SELECT COUNT(*) AS n FROM vehicles').get();
  return row.n > 0;
}

export function seed({ force = false } = {}) {
  if (!force && alreadySeeded()) {
    logger.info('Seed skipped: vehicles table is not empty');
    return;
  }

  const insertUser = db.prepare(`
    INSERT OR IGNORE INTO users (id, name, email, password_hash, role, organization, timezone)
    VALUES (@id, @name, @email, @password_hash, @role, @organization, @timezone)
  `);

  const passwordHash = bcrypt.hashSync(config.seedAdminPassword, config.bcryptSaltRounds);
  insertUser.run({
    id: `usr-${nanoid(10)}`,
    name: 'Alexander Sterling',
    email: config.seedAdminEmail,
    password_hash: passwordHash,
    role: 'super_admin',
    organization: 'Global Logistics Operations',
    timezone: 'America/Los_Angeles',
  });
  insertUser.run({
    id: `usr-${nanoid(10)}`,
    name: 'Sarah Hall',
    email: 'dispatch@nfleet.io',
    password_hash: bcrypt.hashSync('nfleet123', config.bcryptSaltRounds),
    role: 'dispatcher',
    organization: 'West Coast Dispatch Division',
    timezone: 'America/Los_Angeles',
  });

  const drivers = [
    { id: 'drv-1', name: 'Marcus Webb', license_number: 'DL-88213-CA', phone: '+1-415-555-0142', email: 'marcus.webb@nfleet.io', status: 'active', safety_score: 94, rating: 4.8, total_trips: 312, total_distance_km: 48210 },
    { id: 'drv-2', name: 'Elena Vasquez', license_number: 'DL-77190-CA', phone: '+1-415-555-0187', email: 'elena.vasquez@nfleet.io', status: 'active', safety_score: 88, rating: 4.6, total_trips: 274, total_distance_km: 39880 },
    { id: 'drv-3', name: 'Ray Thompson', license_number: 'DL-66542-CA', phone: '+1-415-555-0119', email: 'ray.thompson@nfleet.io', status: 'on_break', safety_score: 91, rating: 4.7, total_trips: 298, total_distance_km: 44120 },
    { id: 'drv-4', name: 'Priya Nair', license_number: 'DL-90341-CA', phone: '+1-415-555-0164', email: 'priya.nair@nfleet.io', status: 'off_duty', safety_score: 97, rating: 4.9, total_trips: 356, total_distance_km: 52010 },
  ];
  const insertDriver = db.prepare(`
    INSERT OR IGNORE INTO drivers (id, name, license_number, phone, email, status, safety_score, rating, total_trips, total_distance_km, total_hours, shift_hours_today, violations_count)
    VALUES (@id, @name, @license_number, @phone, @email, @status, @safety_score, @rating, @total_trips, @total_distance_km, 0, 0, 0)
  `);
  for (const d of drivers) insertDriver.run(d);

  const vehicles = [
    { id: 'veh-1', name: 'Volvo FH16 - LongHaul 01', plate: 'NF-2201-VH', imei: '862345061234561', model: 'Teltonika FMB920', type: 'truck', driverId: 'drv-1', lat: 37.7749, lng: -122.4194, status: 'moving', speed: 62 },
    { id: 'veh-2', name: 'Mercedes Sprinter - Metro 04', plate: 'NF-3184-CA', imei: '862345061234562', model: 'Queclink GV75', type: 'van', driverId: 'drv-2', lat: 37.8044, lng: -122.2712, status: 'moving', speed: 38 },
    { id: 'veh-3', name: 'Scania R500 - ColdChain Reefer', plate: 'NF-6590-CL', imei: '862345061234563', model: 'Teltonika FMB920', type: 'trailer', driverId: 'drv-3', lat: 37.7249, lng: -122.1561, status: 'idle', speed: 0 },
    { id: 'veh-4', name: 'Ford F-550 - Heavy Recovery', plate: 'NF-1129-SV', imei: '862345061234564', model: 'Queclink GV350M', type: 'heavy', driverId: 'drv-4', lat: 37.8651, lng: -122.2585, status: 'moving', speed: 44 },
    { id: 'veh-5', name: 'Isuzu NPR - FreshSupply 09', plate: 'NF-7204-FD', imei: '862345061234565', model: 'Teltonika FMB920', type: 'truck', driverId: null, lat: 37.6879, lng: -122.4702, status: 'stopped', speed: 0 },
    { id: 'veh-6', name: 'Kenworth W990 - LongHaul 03', plate: 'NF-9021-KW', imei: '862345061234566', model: 'Queclink GV75', type: 'truck', driverId: null, lat: 37.5585, lng: -122.2711, status: 'offline', speed: 0 },
    { id: 'veh-7', name: 'Toyota Proace - QuickCourier 02', plate: 'NF-4491-QC', imei: '862345061234567', model: 'Teltonika FMB920', type: 'van', driverId: null, lat: 37.8272, lng: -122.2913, status: 'moving', speed: 51 },
  ];
  const insertVehicle = db.prepare(`
    INSERT OR IGNORE INTO vehicles (
      id, name, plate_number, imei, device_model, sim_number, driver_id, driver_name, driver_phone,
      group_name, type, status, speed_limit, lat, lng, speed, heading, altitude, accuracy, satellites,
      ignition, engine_rpm, fuel_level, battery_voltage, odometer, engine_temp, relay_cutoff, address,
      telemetry_timestamp, last_heartbeat
    ) VALUES (
      @id, @name, @plate, @imei, @model, @sim, @driverId, @driverName, @driverPhone,
      @group_name, @type, @status, @speedLimit, @lat, @lng, @speed, @heading, 25, 3.0, 11,
      @ignition, @engineRpm, @fuelLevel, @batteryVoltage, @odometer, 82, 0, @address,
      @ts, @ts
    )
  `);
  const driverById = new Map(drivers.map((d) => [d.id, d]));
  const now = new Date().toISOString();
  for (const v of vehicles) {
    const driver = v.driverId ? driverById.get(v.driverId) : null;
    insertVehicle.run({
      id: v.id,
      name: v.name,
      plate: v.plate,
      imei: v.imei,
      model: v.model,
      sim: `+1-650-555-${String(1000 + Math.floor(Math.random() * 8999)).slice(-4)}`,
      driverId: v.driverId,
      driverName: driver?.name ?? null,
      driverPhone: driver?.phone ?? null,
      group_name: 'West Coast Fleet',
      type: v.type,
      status: v.status,
      speedLimit: v.type === 'truck' || v.type === 'heavy' ? 90 : 110,
      lat: v.lat,
      lng: v.lng,
      speed: v.speed,
      heading: Math.floor(Math.random() * 360),
      ignition: v.status === 'moving' || v.status === 'idle' ? 1 : 0,
      engineRpm: v.status === 'moving' ? 1800 : 0,
      fuelLevel: 55 + Math.floor(Math.random() * 40),
      batteryVoltage: 12.6,
      odometer: 40000 + Math.floor(Math.random() * 90000),
      address: 'San Francisco Bay Area, CA',
      ts: now,
    });
  }

  // Assign vehicles back onto drivers for the reverse relation.
  const assignDriver = db.prepare(
    'UPDATE drivers SET assigned_vehicle_id = ? WHERE id = ?'
  );
  for (const v of vehicles) {
    if (v.driverId) assignDriver.run(v.id, v.driverId);
  }

  const devices = vehicles.map((v) => ({
    id: `dev-${v.id.split('-')[1]}`,
    imei: v.imei,
    model: v.model,
    protocol: 'TCP/GT06',
    firmware: '2.4.1',
    sim: `+1-650-555-${String(1000 + Math.floor(Math.random() * 8999)).slice(-4)}`,
    iccid: `8901${Math.floor(Math.random() * 1e14)}`,
    operator: 'Verizon IoT',
    battery: 90 + Math.floor(Math.random() * 10),
    backupV: 3.7,
    gsmDbm: -70,
    gsmPct: 78,
    sats: 11,
    status: v.status === 'offline' ? 'offline' : 'online',
    vehicleAssigned: v.id,
    apiKey: `nflk_${nanoid(32)}`,
  }));
  const insertDevice = db.prepare(`
    INSERT OR IGNORE INTO devices (
      id, imei, model, protocol, firmware_version, sim_number, sim_iccid, operator, api_key,
      battery_status, backup_battery_voltage, gsm_signal_dbm, gsm_signal_percent, satellite_count,
      status, vehicle_assigned, last_communication, last_ping_timestamp
    ) VALUES (
      @id, @imei, @model, @protocol, @firmware, @sim, @iccid, @operator, @apiKey,
      @battery, @backupV, @gsmDbm, @gsmPct, @sats,
      @status, @vehicleAssigned, @ts, @ts
    )
  `);
  for (const d of devices) insertDevice.run({ ...d, ts: now });

  const geofences = [
    { id: 'geo-1', name: 'Main Depot - SF', description: 'Primary staging yard and fuel depot', type: 'circle', category: 'depot', lat: 37.7749, lng: -122.4194, radius: 400, color: '#22c55e' },
    { id: 'geo-2', name: 'Oakland Restricted Zone', description: 'No unauthorized fleet access after hours', type: 'circle', category: 'restricted', lat: 37.8044, lng: -122.2712, radius: 600, color: '#ef4444' },
    { id: 'geo-3', name: 'Customer Site - Bay Commercial', description: 'Delivery drop-off zone', type: 'circle', category: 'customer', lat: 37.7249, lng: -122.1561, radius: 250, color: '#3b82f6' },
  ];
  const insertGeofence = db.prepare(`
    INSERT OR IGNORE INTO geofences (id, name, description, type, category, center_lat, center_lng, radius_meters, color, alert_on_entry, alert_on_exit)
    VALUES (@id, @name, @description, @type, @category, @lat, @lng, @radius, @color, 1, 1)
  `);
  for (const g of geofences) insertGeofence.run(g);

  const insertAlert = db.prepare(`
    INSERT OR IGNORE INTO alerts (id, vehicle_id, vehicle_name, plate_number, driver_name, type, severity, title, description, lat, lng, address, speed, speed_limit, timestamp, acknowledged)
    VALUES (@id, @vehicleId, @vehicleName, @plate, @driverName, @type, @severity, @title, @description, @lat, @lng, @address, @speed, @speedLimit, @timestamp, @acknowledged)
  `);
  insertAlert.run({
    id: `alrt-${nanoid(10)}`,
    vehicleId: 'veh-1',
    vehicleName: 'Volvo FH16 - LongHaul 01',
    plate: 'NF-2201-VH',
    driverName: 'Marcus Webb',
    type: 'overspeed',
    severity: 'warning',
    title: 'Speed limit exceeded',
    description: 'Vehicle recorded 108 km/h in a 90 km/h zone.',
    lat: 37.77,
    lng: -122.41,
    address: 'I-80 East, San Francisco, CA',
    speed: 108,
    speedLimit: 90,
    timestamp: now,
    acknowledged: 0,
  });
  insertAlert.run({
    id: `alrt-${nanoid(10)}`,
    vehicleId: 'veh-6',
    vehicleName: 'Kenworth W990 - LongHaul 03',
    plate: 'NF-9021-KW',
    driverName: null,
    type: 'offline',
    severity: 'critical',
    title: 'Vehicle offline',
    description: 'No heartbeat received for over 30 minutes.',
    lat: 37.5585,
    lng: -122.2711,
    address: 'Last known: Redwood City, CA',
    speed: null,
    speedLimit: null,
    timestamp: now,
    acknowledged: 0,
  });

  logger.info('Demo data seeded: 2 users, %d vehicles, %d drivers, %d devices, %d geofences', vehicles.length, drivers.length, devices.length, geofences.length);
  logger.info('Demo login -> email: %s  password: %s', config.seedAdminEmail, config.seedAdminPassword);
}

// Allow running directly: `npm run seed`
if (process.argv[1] && process.argv[1].endsWith('seed.js')) {
  seed({ force: process.argv.includes('--force') });
}
