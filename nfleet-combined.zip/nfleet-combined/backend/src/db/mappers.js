export function vehicleRowToJson(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    plateNumber: row.plate_number,
    imei: row.imei,
    deviceModel: row.device_model,
    simNumber: row.sim_number,
    driverId: row.driver_id,
    driverName: row.driver_name,
    driverPhone: row.driver_phone,
    group: row.group_name,
    type: row.type,
    status: row.status,
    speedLimit: row.speed_limit,
    iconType: row.icon_type,
    currentPosition: { lat: row.lat, lng: row.lng },
    telemetry: {
      speed: row.speed,
      heading: row.heading,
      altitude: row.altitude ?? undefined,
      accuracy: row.accuracy ?? undefined,
      satellites: row.satellites,
      ignition: Boolean(row.ignition),
      engineRpm: row.engine_rpm,
      fuelLevel: row.fuel_level,
      batteryVoltage: row.battery_voltage,
      odometer: row.odometer,
      engineTemp: row.engine_temp ?? undefined,
      relayCutoff: Boolean(row.relay_cutoff),
      address: row.address,
      timestamp: row.telemetry_timestamp,
    },
    lastHeartbeat: row.last_heartbeat,
  };
}

export function driverRowToJson(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    licenseNumber: row.license_number,
    phone: row.phone,
    email: row.email,
    avatarUrl: row.avatar_url ?? undefined,
    status: row.status,
    assignedVehicleId: row.assigned_vehicle_id ?? undefined,
    assignedVehiclePlate: row.assigned_vehicle_plate ?? undefined,
    assignedVehicleName: row.assigned_vehicle_name ?? undefined,
    safetyScore: row.safety_score,
    rating: row.rating ?? undefined,
    totalTrips: row.total_trips,
    totalDistanceKm: row.total_distance_km,
    totalHours: row.total_hours,
    shiftHoursToday: row.shift_hours_today,
    violationsCount: row.violations_count,
  };
}

export function deviceRowToJson(row) {
  if (!row) return null;
  return {
    id: row.id,
    imei: row.imei,
    model: row.model,
    protocol: row.protocol,
    firmwareVersion: row.firmware_version,
    simNumber: row.sim_number ?? undefined,
    simIccid: row.sim_iccid ?? undefined,
    operator: row.operator ?? undefined,
    batteryStatus: row.battery_status ?? undefined,
    backupBatteryVoltage: row.backup_battery_voltage ?? undefined,
    gsmSignalDbm: row.gsm_signal_dbm ?? undefined,
    gsmSignalPercent: row.gsm_signal_percent ?? undefined,
    satelliteCount: row.satellite_count ?? undefined,
    status: row.status,
    vehicleAssigned: row.vehicle_assigned ?? undefined,
    lastCommunication: row.last_communication ?? undefined,
    lastPingTimestamp: row.last_ping_timestamp ?? undefined,
    // apiKey is intentionally omitted here; only returned once on creation.
  };
}

export function geofenceRowToJson(row, assignedVehicleIds = []) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    type: row.type,
    category: row.category ?? undefined,
    center:
      row.type === 'circle' && row.center_lat != null
        ? { lat: row.center_lat, lng: row.center_lng }
        : undefined,
    radiusMeters: row.radius_meters ?? undefined,
    polygonCoordinates: row.polygon_coordinates ? JSON.parse(row.polygon_coordinates) : undefined,
    color: row.color,
    speedLimitKmH: row.speed_limit_kmh ?? undefined,
    activeVehiclesCount: assignedVehicleIds.length,
    activeVehicleCount: assignedVehicleIds.length,
    alertOnEntry: Boolean(row.alert_on_entry),
    alertOnExit: Boolean(row.alert_on_exit),
    triggers: {
      onEnter: Boolean(row.alert_on_entry),
      onExit: Boolean(row.alert_on_exit),
      onOverspeed: Boolean(row.alert_on_overspeed),
    },
    assignedVehicleIds,
    createdAt: row.created_at,
  };
}

export function alertRowToJson(row) {
  if (!row) return null;
  return {
    id: row.id,
    vehicleId: row.vehicle_id,
    vehicleName: row.vehicle_name,
    plateNumber: row.plate_number,
    driverName: row.driver_name,
    type: row.type,
    severity: row.severity,
    title: row.title,
    description: row.description,
    location: { lat: row.lat, lng: row.lng },
    address: row.address,
    speed: row.speed ?? undefined,
    speedLimit: row.speed_limit ?? undefined,
    timestamp: row.timestamp,
    acknowledged: Boolean(row.acknowledged),
    acknowledgedBy: row.acknowledged_by ?? undefined,
    acknowledgedAt: row.acknowledged_at ?? undefined,
    resolutionNotes: row.resolution_notes ?? undefined,
  };
}

export function tripPointRowToJson(row) {
  return {
    lat: row.lat,
    lng: row.lng,
    timestamp: row.timestamp,
    speed: row.speed,
    heading: row.heading,
    ignition: Boolean(row.ignition),
    altitude: row.altitude ?? undefined,
    fuelLevel: row.fuel_level ?? undefined,
    event: row.event ?? undefined,
    stopDuration: row.stop_duration ?? undefined,
    address: row.address ?? undefined,
  };
}

export function tripRowToJson(row, points = []) {
  if (!row) return null;
  return {
    id: row.id,
    vehicleId: row.vehicle_id,
    vehicleName: row.vehicle_name,
    plateNumber: row.plate_number,
    startTime: row.start_time,
    endTime: row.end_time,
    startAddress: row.start_address,
    endAddress: row.end_address,
    totalDistanceKm: row.total_distance_km,
    movingDurationMinutes: row.moving_duration_minutes,
    idleDurationMinutes: row.idle_duration_minutes,
    avgSpeedKmH: row.avg_speed_kmh,
    maxSpeedKmH: row.max_speed_kmh,
    fuelConsumedLiters: row.fuel_consumed_liters,
    stopCount: row.stop_count,
    alertCount: row.alert_count,
    points: points.map(tripPointRowToJson),
  };
}

export function userRowToJson(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    avatarUrl: row.avatar_url ?? undefined,
    organization: row.organization,
    timezone: row.timezone,
  };
}
