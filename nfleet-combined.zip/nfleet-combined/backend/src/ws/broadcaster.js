import { WebSocketServer } from 'ws';
import { URL } from 'node:url';
import { verifyToken } from '../utils/jwt.js';
import { logger } from '../utils/logger.js';

let wss = null;
const clients = new Set();

/**
 * Attaches a WebSocket server to the given HTTP server on path /ws.
 * Clients authenticate with a JWT passed as ?token=... in the connection
 * URL (matching how the frontend's gpsService opens `getWsUrl()` directly).
 */
export function initWebSocketServer(httpServer) {
  wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws, req) => {
    const url = new URL(req.url, 'http://localhost');
    const token = url.searchParams.get('token');

    if (token) {
      try {
        ws.user = verifyToken(token);
      } catch {
        ws.close(4001, 'Invalid token');
        return;
      }
    }
    // Connections without a token are still allowed as read-only demo
    // viewers; tighten this by returning early here if you require auth
    // on every socket.

    clients.add(ws);
    logger.info({ clients: clients.size }, 'WS client connected');

    ws.isAlive = true;
    ws.on('pong', () => {
      ws.isAlive = true;
    });

    ws.on('close', () => {
      clients.delete(ws);
      logger.info({ clients: clients.size }, 'WS client disconnected');
    });

    ws.send(JSON.stringify({ type: 'connected', message: 'NFLEET telematics stream online' }));
  });

  // Heartbeat to prune dead connections.
  const interval = setInterval(() => {
    for (const ws of clients) {
      if (!ws.isAlive) {
        ws.terminate();
        clients.delete(ws);
        continue;
      }
      ws.isAlive = false;
      ws.ping();
    }
  }, 30_000);

  wss.on('close', () => clearInterval(interval));

  return wss;
}

/**
 * Broadcasts a raw GPS/telemetry packet to every connected client, in the
 * exact shape the frontend's gpsService.handleLiveGpsPacket expects:
 * { vehicleId, imei, lat, lng, speed, heading, ignition, ... }
 */
export function broadcastTelemetry(packet) {
  broadcast({ type: 'telemetry', ...packet });
}

export function broadcastAlert(alert) {
  broadcast({ type: 'alert', alert });
}

function broadcast(payload) {
  const data = JSON.stringify(payload);
  for (const ws of clients) {
    if (ws.readyState === ws.OPEN) {
      ws.send(data);
    }
  }
}

export function getConnectedClientCount() {
  return clients.size;
}
