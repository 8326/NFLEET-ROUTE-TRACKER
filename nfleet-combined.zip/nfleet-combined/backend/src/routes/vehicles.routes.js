import { Router } from 'express';
import { z } from 'zod';
import { nanoid } from 'nanoid';
import { db } from '../db/index.js';
import { vehicleRowToJson } from '../db/mappers.js';
import { asyncHandler, ApiError } from '../middleware/errorHandler.js';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';
import { broadcastTelemetry } from '../ws/broadcaster.js';

const router = Router();
router.use(requireAuth);

const coordSchema = z.object({ lat: z.number(), lng: z.number() });

const createVehicleSchema = z.object({
  name: z.string().min(1),
  plateNumber: z.string().min(1),
  imei: z.string().optional(),
  deviceModel: z.string().optional(),
  simNumber: z.string().optional(),
  driverId: z.string().optional(),
  driverName: z.string().optional(),
  driverPhone: z.string().optional(),
  group: z.string().optional(),
  type: z.enum(['truck', 'van', 'car', 'trailer', 'heavy']).default('truck'),
  speedLimit: z.number().default(100),
  iconType: z.string().optional(),
  currentPosition: coordSchema.optional(),
});

const relaySchema = z.object({ cutoff: z.boolean() });

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const rows = db.prepare('SELECT * FROM vehicles ORDER BY name').all();
    res.json(rows.map(vehicleRowToJson));
  })
);

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const row = db.prepare('SELECT * FROM vehicles WHERE id = ?').get(req.params.id);
    if (!row) throw new ApiError(404, 'Vehicle not found');
    res.json(vehicleRowToJson(row));
  })
);

router.post(
  '/',
  validate(createVehicleSchema),
  asyncHandler(async (req, res) => {
    const b = req.body;
    const id = `veh-${nanoid(10)}`;
    const pos = b.currentPosition || {
      lat: 37.7749 + (Math.random() - 0.5) * 0.08,
      lng: -122.4194 + (Math.random() - 0.5) * 0.08,
    };
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO vehicles (
        id, name, plate_number, imei, device_model, sim_number, driver_id, driver_name, driver_phone,
        group_name, type, status, speed_limit, icon_type, lat, lng, speed, heading, satellites,
        ignition, engine_rpm, fuel_level, battery_voltage, odometer, relay_cutoff, address,
        telemetry_timestamp, last_heartbeat
      ) VALUES (
        @id, @name, @plateNumber, @imei, @deviceModel, @simNumber, @driverId, @driverName, @driverPhone,
        @group, @type, 'stopped', @speedLimit, @iconType, @lat, @lng, 0, 0, 12,
        0, 0, 90, 12.6, 10500, 0, 'NFLEET Depot Staging Bay 3',
        @now, @now
      )`
    ).run({
      id,
      name: b.name,
      plateNumber: b.plateNumber,
      imei: b.imei || null,
      deviceModel: b.deviceModel || null,
      simNumber: b.simNumber || null,
      driverId: b.driverId || null,
      driverName: b.driverName || null,
      driverPhone: b.driverPhone || null,
      group: b.group || 'Unassigned',
      type: b.type,
      speedLimit: b.speedLimit,
      iconType: b.iconType || null,
      lat: pos.lat,
      lng: pos.lng,
      now,
    });

    const row = db.prepare('SELECT * FROM vehicles WHERE id = ?').get(id);
    res.status(201).json(vehicleRowToJson(row));
  })
);

router.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const existing = db.prepare('SELECT * FROM vehicles WHERE id = ?').get(req.params.id);
    if (!existing) throw new ApiError(404, 'Vehicle not found');

    const fields = {
      name: req.body.name ?? existing.name,
      plate_number: req.body.plateNumber ?? existing.plate_number,
      driver_id: req.body.driverId ?? existing.driver_id,
      driver_name: req.body.driverName ?? existing.driver_name,
      driver_phone: req.body.driverPhone ?? existing.driver_phone,
      group_name: req.body.group ?? existing.group_name,
      type: req.body.type ?? existing.type,
      speed_limit: req.body.speedLimit ?? existing.speed_limit,
    };

    db.prepare(
      `UPDATE vehicles SET name=@name, plate_number=@plate_number, driver_id=@driver_id,
       driver_name=@driver_name, driver_phone=@driver_phone, group_name=@group_name,
       type=@type, speed_limit=@speed_limit WHERE id=@id`
    ).run({ ...fields, id: req.params.id });

    const row = db.prepare('SELECT * FROM vehicles WHERE id = ?').get(req.params.id);
    res.json(vehicleRowToJson(row));
  })
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const result = db.prepare('DELETE FROM vehicles WHERE id = ?').run(req.params.id);
    if (result.changes === 0) throw new ApiError(404, 'Vehicle not found');
    res.status(204).send();
  })
);

// Remote immobilizer / relay cutoff toggle - simulates sending a downlink
// command to the tracker; in a real deployment this would enqueue a
// command for the device to acknowledge on its next check-in.
router.post(
  '/:id/relay',
  validate(relaySchema),
  asyncHandler(async (req, res) => {
    const existing = db.prepare('SELECT * FROM vehicles WHERE id = ?').get(req.params.id);
    if (!existing) throw new ApiError(404, 'Vehicle not found');

    const cutoff = req.body.cutoff;
    db.prepare(
      `UPDATE vehicles SET relay_cutoff = ?, status = CASE WHEN ? = 1 THEN 'stopped' ELSE status END WHERE id = ?`
    ).run(cutoff ? 1 : 0, cutoff ? 1 : 0, req.params.id);

    broadcastTelemetry({
      vehicleId: existing.id,
      imei: existing.imei,
      lat: existing.lat,
      lng: existing.lng,
      speed: cutoff ? 0 : existing.speed,
      heading: existing.heading,
      ignition: cutoff ? false : Boolean(existing.ignition),
      timestamp: new Date().toISOString(),
    });

    res.json({ cutoff });
  })
);

export default router;
