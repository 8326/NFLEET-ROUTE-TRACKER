import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import rateLimit from 'express-rate-limit';
import { db } from '../db/index.js';
import { userRowToJson } from '../db/mappers.js';
import { signToken } from '../utils/jwt.js';
import { asyncHandler, ApiError } from '../middleware/errorHandler.js';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many login attempts. Please try again later.' },
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  rememberMe: z.boolean().optional(),
});

router.post(
  '/login',
  loginLimiter,
  validate(loginSchema),
  asyncHandler(async (req, res) => {
    const { email, password } = req.body;

    const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
    if (!row) throw new ApiError(401, 'Invalid email or password');

    const ok = bcrypt.compareSync(password, row.password_hash);
    if (!ok) throw new ApiError(401, 'Invalid email or password');

    const user = userRowToJson(row);
    const token = signToken({ sub: user.id, email: user.email, role: user.role });

    res.json({ user, token });
  })
);

router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.sub);
    if (!row) throw new ApiError(404, 'User not found');
    res.json(userRowToJson(row));
  })
);

export default router;
