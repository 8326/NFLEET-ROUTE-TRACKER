import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/index.js';
import { alertRowToJson } from '../db/mappers.js';
import { asyncHandler, ApiError } from '../middleware/errorHandler.js';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const ackSchema = z.object({
  acknowledgedBy: z.string().min(1).default('Operator Console'),
  notes: z.string().optional(),
});

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const rows = db.prepare('SELECT * FROM alerts ORDER BY timestamp DESC').all();
    res.json(rows.map(alertRowToJson));
  })
);

router.post(
  '/:id/acknowledge',
  validate(ackSchema),
  asyncHandler(async (req, res) => {
    const existing = db.prepare('SELECT * FROM alerts WHERE id = ?').get(req.params.id);
    if (!existing) throw new ApiError(404, 'Alert not found');

    const now = new Date().toISOString();
    db.prepare(
      `UPDATE alerts SET acknowledged = 1, acknowledged_by = ?, acknowledged_at = ?, resolution_notes = ? WHERE id = ?`
    ).run(
      req.body.acknowledgedBy,
      now,
      req.body.notes || 'Incident acknowledged and logged by operator.',
      req.params.id
    );

    const row = db.prepare('SELECT * FROM alerts WHERE id = ?').get(req.params.id);
    res.json(alertRowToJson(row));
  })
);

router.post(
  '/:id/resolve',
  asyncHandler(async (req, res) => {
    const result = db.prepare('DELETE FROM alerts WHERE id = ?').run(req.params.id);
    if (result.changes === 0) throw new ApiError(404, 'Alert not found');
    res.json({ resolved: true });
  })
);

export default router;
