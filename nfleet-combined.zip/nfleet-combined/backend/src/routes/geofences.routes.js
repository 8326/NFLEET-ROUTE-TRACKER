import { Router } from 'express';
import { z } from 'zod';
import { nanoid } from 'nanoid';
import { db } from '../db/index.js';
import { geofenceRowToJson } from '../db/mappers.js';
import { asyncHandler, ApiError } from '../middleware/errorHandler.js';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const coord = z.object({ lat: z.number(), lng: z.number() });

const geofenceSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  type: z.enum(['circle', 'polygon']),
  category: z.enum(['depot', 'customer', 'restricted', 'service_center']).optional(),
  center: coord.optional(),
  radiusMeters: z.number().optional(),
  polygonCoordinates: z.array(coord).optional(),
  color: z.string().default('#3b82f6'),
  speedLimitKmH: z.number().optional(),
  alertOnEntry: z.boolean().default(true),
  alertOnExit: z.boolean().default(true),
  alertOnOverspeed: z.boolean().default(false),
  assignedVehicleIds: z.array(z.string()).default([]),
});

function assignedVehicleIdsFor(geofenceId) {
  return db
    .prepare('SELECT vehicle_id FROM geofence_vehicles WHERE geofence_id = ?')
    .all(geofenceId)
    .map((r) => r.vehicle_id);
}

function setAssignments(geofenceId, vehicleIds) {
  db.prepare('DELETE FROM geofence_vehicles WHERE geofence_id = ?').run(geofenceId);
  const stmt = db.prepare('INSERT INTO geofence_vehicles (geofence_id, vehicle_id) VALUES (?, ?)');
  for (const vId of vehicleIds) stmt.run(geofenceId, vId);
}

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const rows = db.prepare('SELECT * FROM geofences ORDER BY name').all();
    res.json(rows.map((r) => geofenceRowToJson(r, assignedVehicleIdsFor(r.id))));
  })
);

router.post(
  '/',
  validate(geofenceSchema),
  asyncHandler(async (req, res) => {
    const b = req.body;
    const id = `geo-${nanoid(10)}`;

    db.prepare(
      `INSERT INTO geofences (id, name, description, type, category, center_lat, center_lng, radius_meters, polygon_coordinates, color, speed_limit_kmh, alert_on_entry, alert_on_exit, alert_on_overspeed)
       VALUES (@id, @name, @description, @type, @category, @lat, @lng, @radiusMeters, @polygon, @color, @speedLimitKmH, @alertOnEntry, @alertOnExit, @alertOnOverspeed)`
    ).run({
      id,
      name: b.name,
      description: b.description || null,
      type: b.type,
      category: b.category || null,
      lat: b.center?.lat ?? null,
      lng: b.center?.lng ?? null,
      radiusMeters: b.radiusMeters ?? null,
      polygon: b.polygonCoordinates ? JSON.stringify(b.polygonCoordinates) : null,
      color: b.color,
      speedLimitKmH: b.speedLimitKmH ?? null,
      alertOnEntry: b.alertOnEntry ? 1 : 0,
      alertOnExit: b.alertOnExit ? 1 : 0,
      alertOnOverspeed: b.alertOnOverspeed ? 1 : 0,
    });

    setAssignments(id, b.assignedVehicleIds);

    const row = db.prepare('SELECT * FROM geofences WHERE id = ?').get(id);
    res.status(201).json(geofenceRowToJson(row, assignedVehicleIdsFor(id)));
  })
);

router.put(
  '/:id',
  validate(geofenceSchema),
  asyncHandler(async (req, res) => {
    const existing = db.prepare('SELECT * FROM geofences WHERE id = ?').get(req.params.id);
    if (!existing) throw new ApiError(404, 'Geofence not found');
    const b = req.body;

    db.prepare(
      `UPDATE geofences SET name=@name, description=@description, type=@type, category=@category,
       center_lat=@lat, center_lng=@lng, radius_meters=@radiusMeters, polygon_coordinates=@polygon,
       color=@color, speed_limit_kmh=@speedLimitKmH, alert_on_entry=@alertOnEntry,
       alert_on_exit=@alertOnExit, alert_on_overspeed=@alertOnOverspeed WHERE id=@id`
    ).run({
      id: req.params.id,
      name: b.name,
      description: b.description || null,
      type: b.type,
      category: b.category || null,
      lat: b.center?.lat ?? null,
      lng: b.center?.lng ?? null,
      radiusMeters: b.radiusMeters ?? null,
      polygon: b.polygonCoordinates ? JSON.stringify(b.polygonCoordinates) : null,
      color: b.color,
      speedLimitKmH: b.speedLimitKmH ?? null,
      alertOnEntry: b.alertOnEntry ? 1 : 0,
      alertOnExit: b.alertOnExit ? 1 : 0,
      alertOnOverspeed: b.alertOnOverspeed ? 1 : 0,
    });

    setAssignments(req.params.id, b.assignedVehicleIds);

    const row = db.prepare('SELECT * FROM geofences WHERE id = ?').get(req.params.id);
    res.json(geofenceRowToJson(row, assignedVehicleIdsFor(req.params.id)));
  })
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const result = db.prepare('DELETE FROM geofences WHERE id = ?').run(req.params.id);
    if (result.changes === 0) throw new ApiError(404, 'Geofence not found');
    res.status(204).send();
  })
);

export default router;
