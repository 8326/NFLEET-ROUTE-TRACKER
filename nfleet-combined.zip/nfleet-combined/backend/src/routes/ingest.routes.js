import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/index.js';
import { requireDeviceKey } from '../middleware/apiKeyAuth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { validate } from '../middleware/validate.js';
import { telemetryService } from '../services/telemetryService.js';

const router = Router();

const packetSchema = z.object({
  vehicleId: z.string().optional(),
  imei: z.string().optional(),
  lat: z.number(),
  lng: z.number(),
  speed: z.number().min(0),
  heading: z.number().min(0).max(360).optional(),
  ignition: z.boolean().default(false),
  satellites: z.number().optional(),
  batteryVoltage: z.number().optional(),
  fuelLevel: z.number().optional(),
  odometer: z.number().optional(),
  engineRpm: z.number().optional(),
  address: z.string().optional(),
  timestamp: z.string().optional(),
});

/**
 * POST /api/v1/ingest/telemetry
 * Header: X-Device-Key: <per-device api key>
 * Body: one GPS packet from a physical tracker (Teltonika / Queclink /
 * generic GT06 gateway forwards decoded JSON here).
 */
router.post(
  '/telemetry',
  requireDeviceKey,
  validate(packetSchema),
  asyncHandler(async (req, res) => {
    const packet = { ...req.body };

    // If authenticated with a specific device key, pin the packet to that
    // device's IMEI so a spoofed vehicleId in the body can't redirect it.
    if (req.device) {
      packet.imei = req.device.imei;
      db.prepare('UPDATE devices SET last_communication = ?, last_ping_timestamp = ?, status = ? WHERE id = ?').run(
        new Date().toISOString(),
        new Date().toISOString(),
        'online',
        req.device.id
      );
    }

    const result = telemetryService.ingest(packet);
    res.status(202).json(result);
  })
);

export default router;
