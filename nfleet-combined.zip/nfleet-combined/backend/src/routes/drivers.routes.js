import { Router } from 'express';
import { z } from 'zod';
import { nanoid } from 'nanoid';
import { db } from '../db/index.js';
import { driverRowToJson } from '../db/mappers.js';
import { asyncHandler, ApiError } from '../middleware/errorHandler.js';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const driverSchema = z.object({
  name: z.string().min(1),
  licenseNumber: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  status: z.enum(['active', 'on_break', 'off_duty']).default('off_duty'),
  assignedVehicleId: z.string().optional(),
});

function withVehicleInfo(row) {
  if (row.assigned_vehicle_id) {
    const v = db
      .prepare('SELECT plate_number, name FROM vehicles WHERE id = ?')
      .get(row.assigned_vehicle_id);
    if (v) {
      row.assigned_vehicle_plate = v.plate_number;
      row.assigned_vehicle_name = v.name;
    }
  }
  return row;
}

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const rows = db.prepare('SELECT * FROM drivers ORDER BY name').all();
    res.json(rows.map((r) => driverRowToJson(withVehicleInfo(r))));
  })
);

router.post(
  '/',
  validate(driverSchema),
  asyncHandler(async (req, res) => {
    const b = req.body;
    const id = `drv-${nanoid(10)}`;
    db.prepare(
      `INSERT INTO drivers (id, name, license_number, phone, email, status, assigned_vehicle_id, safety_score, total_trips, total_distance_km, total_hours, shift_hours_today, violations_count)
       VALUES (@id, @name, @licenseNumber, @phone, @email, @status, @assignedVehicleId, 100, 0, 0, 0, 0, 0)`
    ).run({
      id,
      name: b.name,
      licenseNumber: b.licenseNumber || null,
      phone: b.phone || null,
      email: b.email || null,
      status: b.status,
      assignedVehicleId: b.assignedVehicleId || null,
    });
    const row = db.prepare('SELECT * FROM drivers WHERE id = ?').get(id);
    res.status(201).json(driverRowToJson(withVehicleInfo(row)));
  })
);

router.put(
  '/:id',
  validate(driverSchema),
  asyncHandler(async (req, res) => {
    const existing = db.prepare('SELECT * FROM drivers WHERE id = ?').get(req.params.id);
    if (!existing) throw new ApiError(404, 'Driver not found');
    const b = req.body;
    db.prepare(
      `UPDATE drivers SET name=@name, license_number=@licenseNumber, phone=@phone, email=@email,
       status=@status, assigned_vehicle_id=@assignedVehicleId WHERE id=@id`
    ).run({
      id: req.params.id,
      name: b.name,
      licenseNumber: b.licenseNumber || null,
      phone: b.phone || null,
      email: b.email || null,
      status: b.status,
      assignedVehicleId: b.assignedVehicleId || null,
    });
    const row = db.prepare('SELECT * FROM drivers WHERE id = ?').get(req.params.id);
    res.json(driverRowToJson(withVehicleInfo(row)));
  })
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const result = db.prepare('DELETE FROM drivers WHERE id = ?').run(req.params.id);
    if (result.changes === 0) throw new ApiError(404, 'Driver not found');
    res.status(204).send();
  })
);

export default router;
