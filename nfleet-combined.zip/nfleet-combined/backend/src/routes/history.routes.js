import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db/index.js';
import { tripRowToJson } from '../db/mappers.js';
import { asyncHandler, ApiError } from '../middleware/errorHandler.js';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const querySchema = z.object({
  vehicleId: z.string().min(1),
  date: z.string().min(1), // YYYY-MM-DD
});

// GET /api/v1/history?vehicleId=veh-1&date=2026-09-08
router.get(
  '/',
  validate(querySchema, 'query'),
  asyncHandler(async (req, res) => {
    const { vehicleId, date } = req.query;

    const trip = db
      .prepare('SELECT * FROM trips WHERE vehicle_id = ? AND trip_date = ?')
      .get(vehicleId, date);

    if (!trip) {
      throw new ApiError(404, `No trip history recorded for ${vehicleId} on ${date}`);
    }

    const points = db
      .prepare('SELECT * FROM trip_points WHERE trip_id = ? ORDER BY id ASC')
      .all(trip.id);

    res.json(tripRowToJson(trip, points));
  })
);

// GET /api/v1/history/dates?vehicleId=veh-1 -> list of dates with recorded trips
router.get(
  '/dates',
  asyncHandler(async (req, res) => {
    const vehicleId = req.query.vehicleId;
    if (!vehicleId) throw new ApiError(400, 'vehicleId query param is required');
    const rows = db
      .prepare('SELECT trip_date FROM trips WHERE vehicle_id = ? ORDER BY trip_date DESC')
      .all(vehicleId);
    res.json(rows.map((r) => r.trip_date));
  })
);

export default router;
