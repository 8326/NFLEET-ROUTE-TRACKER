import { Router } from 'express';
import { z } from 'zod';
import { nanoid } from 'nanoid';
import { db } from '../db/index.js';
import { deviceRowToJson } from '../db/mappers.js';
import { asyncHandler, ApiError } from '../middleware/errorHandler.js';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const deviceSchema = z.object({
  imei: z.string().min(1),
  model: z.string().optional(),
  protocol: z.string().optional(),
  firmwareVersion: z.string().optional(),
  simNumber: z.string().optional(),
  simIccid: z.string().optional(),
  operator: z.string().optional(),
  vehicleAssigned: z.string().optional(),
});

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const rows = db.prepare('SELECT * FROM devices ORDER BY imei').all();
    res.json(rows.map(deviceRowToJson));
  })
);

// Creating a device returns its api_key ONCE - store it securely, it's
// what the physical tracker (or the simulator) uses to authenticate
// against POST /api/v1/ingest/telemetry via the X-Device-Key header.
router.post(
  '/',
  validate(deviceSchema),
  asyncHandler(async (req, res) => {
    const b = req.body;
    const id = `dev-${nanoid(10)}`;
    const apiKey = `nflk_${nanoid(32)}`;

    db.prepare(
      `INSERT INTO devices (id, imei, model, protocol, firmware_version, sim_number, sim_iccid, operator, api_key, status, vehicle_assigned)
       VALUES (@id, @imei, @model, @protocol, @firmwareVersion, @simNumber, @simIccid, @operator, @apiKey, 'unregistered', @vehicleAssigned)`
    ).run({
      id,
      imei: b.imei,
      model: b.model || null,
      protocol: b.protocol || null,
      firmwareVersion: b.firmwareVersion || null,
      simNumber: b.simNumber || null,
      simIccid: b.simIccid || null,
      operator: b.operator || null,
      apiKey,
      vehicleAssigned: b.vehicleAssigned || null,
    });

    const row = db.prepare('SELECT * FROM devices WHERE id = ?').get(id);
    res.status(201).json({ ...deviceRowToJson(row), apiKey });
  })
);

router.post(
  '/:id/rotate-key',
  asyncHandler(async (req, res) => {
    const existing = db.prepare('SELECT * FROM devices WHERE id = ?').get(req.params.id);
    if (!existing) throw new ApiError(404, 'Device not found');
    const apiKey = `nflk_${nanoid(32)}`;
    db.prepare('UPDATE devices SET api_key = ? WHERE id = ?').run(apiKey, req.params.id);
    res.json({ apiKey });
  })
);

router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const result = db.prepare('DELETE FROM devices WHERE id = ?').run(req.params.id);
    if (result.changes === 0) throw new ApiError(404, 'Device not found');
    res.status(204).send();
  })
);

export default router;
