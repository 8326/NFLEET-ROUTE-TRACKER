import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

function bool(val, fallback) {
  if (val === undefined || val === '') return fallback;
  return val === 'true' || val === '1';
}

export const config = {
  env: process.env.NODE_ENV || 'development',
  isProd: process.env.NODE_ENV === 'production',
  port: Number(process.env.PORT) || 8080,
  root: ROOT,

  corsOrigins: (process.env.CORS_ORIGINS || 'http://localhost:3000')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),

  databaseFile: path.resolve(ROOT, process.env.DATABASE_FILE || './data/nfleet.db'),

  jwtSecret: process.env.JWT_SECRET || 'dev_only_insecure_secret_change_me',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '12h',
  bcryptSaltRounds: Number(process.env.BCRYPT_SALT_ROUNDS) || 12,

  ingestMasterKey: process.env.INGEST_MASTER_KEY || '',

  rateLimitWindowMs: Number(process.env.RATE_LIMIT_WINDOW_MS) || 60_000,
  rateLimitMax: Number(process.env.RATE_LIMIT_MAX) || 300,

  seedDemoData: bool(process.env.SEED_DEMO_DATA, true),
  seedAdminEmail: process.env.SEED_ADMIN_EMAIL || 'admin@nfleet.io',
  seedAdminPassword: process.env.SEED_ADMIN_PASSWORD || 'nfleet123',
};

if (config.isProd && config.jwtSecret === 'dev_only_insecure_secret_change_me') {
  // eslint-disable-next-line no-console
  console.error('FATAL: JWT_SECRET must be set to a strong random value in production.');
  process.exit(1);
}
