import http from 'node:http';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';

import { config } from './config.js';
import { logger } from './utils/logger.js';
import './db/index.js';
import { seed } from './db/seed.js';

import authRoutes from './routes/auth.routes.js';
import vehicleRoutes from './routes/vehicles.routes.js';
import historyRoutes from './routes/history.routes.js';
import alertRoutes from './routes/alerts.routes.js';
import geofenceRoutes from './routes/geofences.routes.js';
import driverRoutes from './routes/drivers.routes.js';
import deviceRoutes from './routes/devices.routes.js';
import ingestRoutes from './routes/ingest.routes.js';

import { notFoundHandler, errorHandler } from './middleware/errorHandler.js';
import { initWebSocketServer, getConnectedClientCount } from './ws/broadcaster.js';

if (config.seedDemoData) {
  seed();
}

const app = express();

app.disable('x-powered-by');
app.set('trust proxy', 1);

app.use(helmet());
app.use(
  cors({
    origin: config.corsOrigins,
    credentials: true,
  })
);
app.use(compression());
app.use(express.json({ limit: '1mb' }));
app.use(morgan(config.isProd ? 'combined' : 'dev'));

const apiLimiter = rateLimit({
  windowMs: config.rateLimitWindowMs,
  max: config.rateLimitMax,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', apiLimiter);

app.get('/healthz', (req, res) => {
  res.json({
    status: 'ok',
    env: config.env,
    uptimeSeconds: Math.round(process.uptime()),
    wsClients: getConnectedClientCount(),
  });
});

app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/vehicles', vehicleRoutes);
app.use('/api/v1/history', historyRoutes);
app.use('/api/v1/alerts', alertRoutes);
app.use('/api/v1/geofences', geofenceRoutes);
app.use('/api/v1/drivers', driverRoutes);
app.use('/api/v1/devices', deviceRoutes);
app.use('/api/v1/ingest', ingestRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const server = http.createServer(app);
initWebSocketServer(server);

server.listen(config.port, () => {
  logger.info(`NFLEET backend listening on port ${config.port} [${config.env}]`);
  logger.info(`WebSocket telemetry stream available at ws://localhost:${config.port}/ws`);
});

function shutdown(signal) {
  logger.info(`${signal} received, shutting down gracefully...`);
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (reason) => {
  logger.error({ reason }, 'Unhandled promise rejection');
});
