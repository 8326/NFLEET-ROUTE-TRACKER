# NFLEET — Combined Frontend + Backend

This folder combines the supplied NFLEET connected frontend and NFLEET backend.

## Frontend
```powershell
cd frontend
npm.cmd install
copy .env.local.example .env.local
npm.cmd run dev
```

## Backend
```powershell
cd backend
npm.cmd install
copy .env.example .env
npm.cmd run dev
```

Run the frontend and backend in separate terminals. Check the backend README and `.env.example` for database requirements and configuration.
